/*
* @filename TErrorConfig.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package message.db.configs;


import java.util.Date;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.text.SimpleDateFormat;

import rmi.Serializer;
import rmi.MessageBlock;


public class TErrorConfig
{
    // class TErrorConfigC
    public static class TErrorConfigC extends MessageBlock.MessageBase
    {
        public static class AutoRegist extends MessageBlock.AutoRegist
        {
            @Override
            public MessageBlock.MessageBase create()
            {
                return new TErrorConfigC();
            }
        }

        public static void __regist(){
            MessageBlock.regist("TErrorConfigC", new AutoRegist());
        }

        public int errorCode;
        public String errorName;
        public String errorStr;

        public TErrorConfigC()
        {
            errorCode = 0;
            errorName = "";
            errorStr = "";
        }

        @Override
        public void __read(Serializer __is)
        {
            errorCode = __is.read(errorCode);
            errorName = __is.read(errorName);
            errorStr = __is.read(errorStr);
        }

        @Override
        public void __write(Serializer __os)
        {
            __os.write(errorCode);
            __os.write(errorName);
            __os.write(errorStr);
        }
    } // end of class TErrorConfigC

    // List SeqTErrorConfig
    public static class SeqTErrorConfig
    {
        private TErrorConfigC[] __array;

        public SeqTErrorConfig()
        {
            __array = new TErrorConfigC[0];
        }

        public SeqTErrorConfig(TErrorConfigC[] initArray)
        {
            __array = initArray;
        }

        public SeqTErrorConfig(int arraySize)
        {
            arraySize = (arraySize >= 0 ? arraySize : 0);

            __array = new TErrorConfigC[arraySize];
            for (int i = 0; i < arraySize; i++)
            {
                __array[i] = new TErrorConfigC();
            }
        }

        public TErrorConfigC[] getArray()
        {
            return __array;
        }

        public int getSize()
        {
            return (__array != null) ? __array.length : 0;
        }

        public boolean isEmpty()
        {
            return (getSize() == 0);
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            __array = new TErrorConfigC[__dataSize];
            for (int i = 0; i < __dataSize; ++i)
            {
                TErrorConfigC __val = new TErrorConfigC();
                __val.__read(__is);
                __array[i] = __val;
            }
        }

        public void __write(Serializer __os)
        {
            int __dataSize = (__array != null) ? __array.length : 0;
            __os.write(__dataSize);
            for (int i = 0; i < __dataSize; ++i)
            {
                __array[i].__write(__os);
            }
        }

        public void fromJsonArray(String jsonArrayStr) throws JSONException
        {
            JSONArray jsonArray = new JSONArray(jsonArrayStr);
            int arraySize = jsonArray.length();
            __array = new TErrorConfigC[arraySize];

            for (int i = 0; i < arraySize; i++)
            {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                TErrorConfigC newObj = new TErrorConfigC();

                newObj.errorCode = jsonObject.optInt("errorCode", 0);

                newObj.errorName = jsonObject.optString("errorName", "");

                newObj.errorStr = jsonObject.optString("errorStr", "");

                __array[i] = newObj;
            }
        }

    } // end of SeqTErrorConfig

}

