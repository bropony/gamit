package message;

public class TErrorConfigEnum{
    static public final int ErrorGate_fatalError = 10000; // 服务器异常
    static public final int ErrorDb_DbError = 10001; // 数据库异常
    static public final int ErrorDb_TableNotFound = 10010; // 找不到表
    static public final int ErrorCommon_Deprecated = 20000; // 禁用的功能
    static public final int ErrorLogin_InvalidValidationCode = 20001; // 手机验证码无效
    static public final int ErrorLogin_InvalidLoginInfo = 20002; // 账号或者密码不正确
    static public final int ErrorLogin_EmptyPassword = 20003; // 密码不能为空
    static public final int ErrorLogin_loginOperTimeout = 20004; // 登录超时
    static public final int ErrorLogin_signupOperTimeout = 20005; // 操作超时，请重试
    static public final int ErrorLogin_AccountExists = 20006; // 账号已存在
    static public final int ErrorGate_serverBusy = 20007; // 系统繁忙，请稍后再试
    static public final int ErrorSignup_invalidAccount = 20010; // 无效的账号
    static public final int ErrorSignup_invalidPassword = 20011; // 无效的密码
    static public final int ErrorSignup_invalidLoginType = 20012; // 无效的登录方式
    static public final int ErrorGate_notLoggedInYet = 20020; // 请先登录
    static public final int ErrorGate_invalidNickname = 20021; // 非法的昵称
    static public final int ErrorGate_invalidAvatar = 20022; // 无效的头像
    static public final int ErrorGate_operTimeout = 20023; // 操作超时
    static public final int ErrorGate_avatarSizeTooLarge = 20024; // 头像图片尺寸超过限制
    static public final int ErrorGate_noSuchPost = 20030; // 帖子不存在
    static public final int ErrorGate_hasUpvotedUserPost = 20031; // 已经为该贴点过赞
    static public final int ErrorGate_mentionedUserNotExist = 20032; // 被提及的用户不存在
    static public final int ErrorGate_dstCommentNotExisted = 20033; // 被提及的评论不存在
    static public final int ErrorGate_hasFollowedThisUser = 20034; // 已经关注过该用户
    static public final int ErrorGate_noSuchUser = 20035; // 用户不存在
    static public final int ErrorGate_didNotFollowThisUser = 20036; // 未关注该用户
    static public final int ErrorGate_invalidGender = 20040; // 性别选择有误
    static public final int ErrorGate_invalidBirthday = 20041; // 生日大于当前时间
    static public final int ErrorGate_noSuchSysTopic = 20050; // 话题不存在
    static public final int ErrorGate_noSuchUpvote = 20051; // 未点赞
    static public final int ErrorGate_addressRecipentNameEmpty = 20060; // 收件人姓名不能为空
    static public final int ErrorGate_addressRecipentPhoneNumEmpty = 20061; // 收件人电话不能为空
    static public final int ErrorGate_addressCityEmpty = 20062; // 请选择城市
    static public final int ErrorGate_addressDetailsEmpty = 20063; // 请填写详地址信息
    static public final int ErrorGate_addressNotExisted = 20064; // 无该联系地址
}
