/*
* @filename TMessageConfig.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package message.db.configs;


import java.util.Date;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.text.SimpleDateFormat;

import rmi.Serializer;
import rmi.MessageBlock;


public class TMessageConfig
{
    // class TMessageConfigC
    public static class TMessageConfigC extends MessageBlock.MessageBase
    {
        public static class AutoRegist extends MessageBlock.AutoRegist
        {
            @Override
            public MessageBlock.MessageBase create()
            {
                return new TMessageConfigC();
            }
        }

        public static void __regist(){
            MessageBlock.regist("TMessageConfigC", new AutoRegist());
        }

        public int msgId;
        public String msgKey;
        public String msgContent;
        public String shortDesc;

        public TMessageConfigC()
        {
            msgId = 0;
            msgKey = "";
            msgContent = "";
            shortDesc = "";
        }

        @Override
        public void __read(Serializer __is)
        {
            msgId = __is.read(msgId);
            msgKey = __is.read(msgKey);
            msgContent = __is.read(msgContent);
            shortDesc = __is.read(shortDesc);
        }

        @Override
        public void __write(Serializer __os)
        {
            __os.write(msgId);
            __os.write(msgKey);
            __os.write(msgContent);
            __os.write(shortDesc);
        }
    } // end of class TMessageConfigC

    // List SeqTMessageConfig
    public static class SeqTMessageConfig
    {
        private TMessageConfigC[] __array;

        public SeqTMessageConfig()
        {
            __array = new TMessageConfigC[0];
        }

        public SeqTMessageConfig(TMessageConfigC[] initArray)
        {
            __array = initArray;
        }

        public SeqTMessageConfig(int arraySize)
        {
            arraySize = (arraySize >= 0 ? arraySize : 0);

            __array = new TMessageConfigC[arraySize];
            for (int i = 0; i < arraySize; i++)
            {
                __array[i] = new TMessageConfigC();
            }
        }

        public TMessageConfigC[] getArray()
        {
            return __array;
        }

        public int getSize()
        {
            return (__array != null) ? __array.length : 0;
        }

        public boolean isEmpty()
        {
            return (getSize() == 0);
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            __array = new TMessageConfigC[__dataSize];
            for (int i = 0; i < __dataSize; ++i)
            {
                TMessageConfigC __val = new TMessageConfigC();
                __val.__read(__is);
                __array[i] = __val;
            }
        }

        public void __write(Serializer __os)
        {
            int __dataSize = (__array != null) ? __array.length : 0;
            __os.write(__dataSize);
            for (int i = 0; i < __dataSize; ++i)
            {
                __array[i].__write(__os);
            }
        }

        public void fromJsonArray(String jsonArrayStr) throws JSONException
        {
            JSONArray jsonArray = new JSONArray(jsonArrayStr);
            int arraySize = jsonArray.length();
            __array = new TMessageConfigC[arraySize];

            for (int i = 0; i < arraySize; i++)
            {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                TMessageConfigC newObj = new TMessageConfigC();

                newObj.msgId = jsonObject.optInt("msgId", 0);

                newObj.msgKey = jsonObject.optString("msgKey", "");

                newObj.msgContent = jsonObject.optString("msgContent", "");

                newObj.shortDesc = jsonObject.optString("shortDesc", "");

                __array[i] = newObj;
            }
        }

    } // end of SeqTMessageConfig

}

