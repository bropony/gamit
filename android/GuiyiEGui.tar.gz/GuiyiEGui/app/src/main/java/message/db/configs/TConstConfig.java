/*
* @filename TConstConfig.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package message.db.configs;


import java.util.Date;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.text.SimpleDateFormat;

import rmi.Serializer;
import rmi.MessageBlock;


public class TConstConfig
{
    // class TConstConfigC
    public static class TConstConfigC extends MessageBlock.MessageBase
    {
        public static class AutoRegist extends MessageBlock.AutoRegist
        {
            @Override
            public MessageBlock.MessageBase create()
            {
                return new TConstConfigC();
            }
        }

        public static void __regist(){
            MessageBlock.regist("TConstConfigC", new AutoRegist());
        }

        public String constName;
        public int intValue;
        public String strValue;
        public String shortDesc;

        public TConstConfigC()
        {
            constName = "";
            intValue = 0;
            strValue = "";
            shortDesc = "";
        }

        @Override
        public void __read(Serializer __is)
        {
            constName = __is.read(constName);
            intValue = __is.read(intValue);
            strValue = __is.read(strValue);
            shortDesc = __is.read(shortDesc);
        }

        @Override
        public void __write(Serializer __os)
        {
            __os.write(constName);
            __os.write(intValue);
            __os.write(strValue);
            __os.write(shortDesc);
        }
    } // end of class TConstConfigC

    // List SeqTConstConfig
    public static class SeqTConstConfig
    {
        private TConstConfigC[] __array;

        public SeqTConstConfig()
        {
            __array = new TConstConfigC[0];
        }

        public SeqTConstConfig(TConstConfigC[] initArray)
        {
            __array = initArray;
        }

        public SeqTConstConfig(int arraySize)
        {
            arraySize = (arraySize >= 0 ? arraySize : 0);

            __array = new TConstConfigC[arraySize];
            for (int i = 0; i < arraySize; i++)
            {
                __array[i] = new TConstConfigC();
            }
        }

        public TConstConfigC[] getArray()
        {
            return __array;
        }

        public int getSize()
        {
            return (__array != null) ? __array.length : 0;
        }

        public boolean isEmpty()
        {
            return (getSize() == 0);
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            __array = new TConstConfigC[__dataSize];
            for (int i = 0; i < __dataSize; ++i)
            {
                TConstConfigC __val = new TConstConfigC();
                __val.__read(__is);
                __array[i] = __val;
            }
        }

        public void __write(Serializer __os)
        {
            int __dataSize = (__array != null) ? __array.length : 0;
            __os.write(__dataSize);
            for (int i = 0; i < __dataSize; ++i)
            {
                __array[i].__write(__os);
            }
        }

        public void fromJsonArray(String jsonArrayStr) throws JSONException
        {
            JSONArray jsonArray = new JSONArray(jsonArrayStr);
            int arraySize = jsonArray.length();
            __array = new TConstConfigC[arraySize];

            for (int i = 0; i < arraySize; i++)
            {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                TConstConfigC newObj = new TConstConfigC();

                newObj.constName = jsonObject.optString("constName", "");

                newObj.intValue = jsonObject.optInt("intValue", 0);

                newObj.strValue = jsonObject.optString("strValue", "");

                newObj.shortDesc = jsonObject.optString("shortDesc", "");

                __array[i] = newObj;
            }
        }

    } // end of SeqTConstConfig

}

