/*
* @filename itest.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package message.gate;


import java.util.Date;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;

import rmi.Serializer;
import rmi.MessageBlock;
import rmi.RmiCore;
import rmi.ProxyManager;
import rmi.RmiManager;
import rmi.RmiErrorDefaultHandler;
import message.common.publicdef;
import message.common.publicmsg;
import message.gate.gateconst;
import message.gate.gatemsg;


public class itest
{
    // Reponse ITest_addSysTopic_response
    public static abstract class ITest_addSysTopic_response extends RmiCore.RmiResponseBase
    {
        /*
        * RmiErrorDefaultHandler.onError() will be called before onError()
        * when useDefaultErrorHandler is true;
        */
        protected boolean useDefaultErrorHandler = true;

        public ITest_addSysTopic_response()
        {
            super();
        }

        @Override
        public void __onResponse(Serializer __is)
        {
            onResponse();
        }

        @Override
        public void __onError(String what, int code)
        {
            onError(what, code);

            if (useDefaultErrorHandler)
            {
                RmiErrorDefaultHandler.onError(what, code);
            }
        }

        @Override
        public void __onTimeout()
        {
            onTimeout();
        }

        public abstract void onResponse();
        public abstract void onError(String what, int code);
        public abstract void onTimeout();
    }

    // Proxy ITestProxy
    public static class ITestProxy extends RmiCore.RmiProxyBase
    {
        public static void __regist(){
            // regist proxy at startup...
            ProxyManager.instance().addProxy(new ITestProxy());
        }

        public ITestProxy()
        {
            super("ITest");
        }

        public void addSysTopic(ITest_addSysTopic_response __response, gatemsg.SSysTopic newSysTopic)
        {
            Serializer __os = new Serializer();
            __os.startToWrite();
            __os.write(Serializer.RmiDataCall);
            __os.write(getName());
            __os.write(new String("addSysTopic"));

            if (__response != null)
            {
                int __msgId = MessageBlock.getMsgId();
                __response.setMsgId(__msgId);
                __os.write(__msgId);
            }
            else
            {
                __os.write(0);
            }

            newSysTopic.__write(__os);

            this.call(__os, __response);
        }

    }

}

