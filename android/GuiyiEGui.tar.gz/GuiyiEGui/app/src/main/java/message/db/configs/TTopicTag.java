/*
* @filename TTopicTag.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package message.db.configs;


import java.util.Date;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.text.SimpleDateFormat;

import rmi.Serializer;
import rmi.MessageBlock;


public class TTopicTag
{
    // class TTopicTagC
    public static class TTopicTagC extends MessageBlock.MessageBase
    {
        public static class AutoRegist extends MessageBlock.AutoRegist
        {
            @Override
            public MessageBlock.MessageBase create()
            {
                return new TTopicTagC();
            }
        }

        public static void __regist(){
            MessageBlock.regist("TTopicTagC", new AutoRegist());
        }

        public int tagId;
        public int tagType;
        public String tagName;
        public int isDefualt;
        public String shortDesc;

        public TTopicTagC()
        {
            tagId = 0;
            tagType = 0;
            tagName = "";
            isDefualt = 0;
            shortDesc = "";
        }

        @Override
        public void __read(Serializer __is)
        {
            tagId = __is.read(tagId);
            tagType = __is.read(tagType);
            tagName = __is.read(tagName);
            isDefualt = __is.read(isDefualt);
            shortDesc = __is.read(shortDesc);
        }

        @Override
        public void __write(Serializer __os)
        {
            __os.write(tagId);
            __os.write(tagType);
            __os.write(tagName);
            __os.write(isDefualt);
            __os.write(shortDesc);
        }
    } // end of class TTopicTagC

    // List SeqTTopicTag
    public static class SeqTTopicTag
    {
        private TTopicTagC[] __array;

        public SeqTTopicTag()
        {
            __array = new TTopicTagC[0];
        }

        public SeqTTopicTag(TTopicTagC[] initArray)
        {
            __array = initArray;
        }

        public SeqTTopicTag(int arraySize)
        {
            arraySize = (arraySize >= 0 ? arraySize : 0);

            __array = new TTopicTagC[arraySize];
            for (int i = 0; i < arraySize; i++)
            {
                __array[i] = new TTopicTagC();
            }
        }

        public TTopicTagC[] getArray()
        {
            return __array;
        }

        public int getSize()
        {
            return (__array != null) ? __array.length : 0;
        }

        public boolean isEmpty()
        {
            return (getSize() == 0);
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            __array = new TTopicTagC[__dataSize];
            for (int i = 0; i < __dataSize; ++i)
            {
                TTopicTagC __val = new TTopicTagC();
                __val.__read(__is);
                __array[i] = __val;
            }
        }

        public void __write(Serializer __os)
        {
            int __dataSize = (__array != null) ? __array.length : 0;
            __os.write(__dataSize);
            for (int i = 0; i < __dataSize; ++i)
            {
                __array[i].__write(__os);
            }
        }

        public void fromJsonArray(String jsonArrayStr) throws JSONException
        {
            JSONArray jsonArray = new JSONArray(jsonArrayStr);
            int arraySize = jsonArray.length();
            __array = new TTopicTagC[arraySize];

            for (int i = 0; i < arraySize; i++)
            {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                TTopicTagC newObj = new TTopicTagC();

                newObj.tagId = jsonObject.optInt("tagId", 0);

                newObj.tagType = jsonObject.optInt("tagType", 0);

                newObj.tagName = jsonObject.optString("tagName", "");

                newObj.isDefualt = jsonObject.optInt("isDefualt", 0);

                newObj.shortDesc = jsonObject.optString("shortDesc", "");

                __array[i] = newObj;
            }
        }

    } // end of SeqTTopicTag

}

