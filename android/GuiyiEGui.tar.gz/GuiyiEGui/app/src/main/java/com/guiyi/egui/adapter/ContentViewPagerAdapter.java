package com.guiyi.egui.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.guiyi.egui.bean.TopicTag;
import com.guiyi.egui.fragment.HomeItemFragment;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/8/26.
 */
public class ContentViewPagerAdapter extends FragmentPagerAdapter {
    private ArrayList<TopicTag> mTopicTags = null;

    public ContentViewPagerAdapter(FragmentManager fm, ArrayList<TopicTag> list) {
        super(fm);
        mTopicTags = list;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return mTopicTags.get(position).getTagName();
    }

    @Override
    public Fragment getItem(int position) {
        return HomeItemFragment.newInstance(position);
    }

    @Override
    public int getCount() {
        return mTopicTags.size();
    }
}
