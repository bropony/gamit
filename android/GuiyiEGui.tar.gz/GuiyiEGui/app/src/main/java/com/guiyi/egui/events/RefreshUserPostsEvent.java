package com.guiyi.egui.events;

import java.util.ArrayList;

import message.gate.gatemsg;

/**
 * Created by ForOne on 15/8/28.
 */
public class RefreshUserPostsEvent {
    public ArrayList<gatemsg.SUserPost> UserPosts;
}
