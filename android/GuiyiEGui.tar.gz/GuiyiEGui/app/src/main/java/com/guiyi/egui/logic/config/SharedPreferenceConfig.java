package com.guiyi.egui.logic.config;

/**
 * Created by Administrator on 2015/8/31.
 */
public class SharedPreferenceConfig {
    public static String nickName="NICK_NAME";
    public static String sessionKey="SESSION_KEY";
    public static String userId="USER_ID";
    public static String avatarUrl="AVATAR_URL";
    public static String birthday="BIRTHDAY";
    public static String gender="GENDER";
    public static String account="ACCOUNT";

}
