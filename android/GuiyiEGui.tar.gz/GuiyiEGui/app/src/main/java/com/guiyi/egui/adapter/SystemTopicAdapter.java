package com.guiyi.egui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.guiyi.egui.util.DateUtil;
import com.guiyi.egui.util.ImageLoaderUtil;

import java.util.ArrayList;

import message.gate.gatemsg;

/**
 * Created by Administrator on 2015/9/3.
 */
public class SystemTopicAdapter extends BaseAdapter {
    private Context mContent;
    private ArrayList<gatemsg.SSysTopic> mList = new ArrayList<>();
    private LayoutInflater mLayoutInflater;
    final int VIEW_TYPE = 2;
    final int TYPE_1 = 0;//为一张图片的item
    final int TYPE_2 = 1;//为三张图片的item
    private final int MAX_IMAGE_COUNT = 3;
    public SystemTopicAdapter(Context context){
        mContent=context;
        mLayoutInflater=LayoutInflater.from(mContent);
    }

    public void setSystemTopics(ArrayList<gatemsg.SSysTopic> list){
        mList=list;
    }

    @Override
    public int getItemViewType(int position) {
        //TODO if判断两个item类型的条件需完善
        if(mList.get(position).images.getArray().length<=2){
            return TYPE_1;
        }else{
            return TYPE_2;
        }
    }

    @Override
    public int getViewTypeCount() {
        return VIEW_TYPE;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        viewHolder holder = null;
        viewHolder1 holder1 = null;
        final gatemsg.SSysTopic sSysTopic = mList.get(position);
        gatemsg.SImageInfo[] imageInfos = sSysTopic.images.getArray();
        int type = getItemViewType(position);
        if (view==null){
            switch (type){
                case TYPE_1:
                    view=mLayoutInflater.inflate(R.layout.item_home_list_view,viewGroup,false);
                    holder=new viewHolder();
                    holder.topicPicImageView= (ImageView) view.findViewById(R.id.topic_pic_image_view);
                    holder.topicTitleTextView= (TextView) view.findViewById(R.id.topic_title_text_view);
                    holder.topicTagImageView= (ImageView) view.findViewById(R.id.topic_tag_image_view);
                    holder.topicContentTextView= (TextView) view.findViewById(R.id.topic_content_text_view);
                    holder.topicPublishTimeTextView= (TextView) view.findViewById(R.id.topic_publish_time_textview);
                    holder.topicShareTextView= (TextView) view.findViewById(R.id.share_num_text_view);
                    holder.topicCommentTextView= (TextView) view.findViewById(R.id.comment_num_text_view);
                    holder.topicUpvoteTextView= (TextView) view.findViewById(R.id.upvote_text_view);
                    view.setTag(holder);
                    break;
                case TYPE_2:
                    view=mLayoutInflater.inflate(R.layout.item_home_list_view_3pic,viewGroup,false);
                    holder1=new viewHolder1();
                    holder1.topicPicImageView1= (ImageView) view.findViewById(R.id.topic_pic_image_view1);
                    holder1.topicPicImageView2= (ImageView) view.findViewById(R.id.topic_pic_image_view2);
                    holder1.topicPicImageView3= (ImageView) view.findViewById(R.id.topic_pic_image_view3);
                    holder1.topicTitleTextView1= (TextView) view.findViewById(R.id.topic_title_text_view1);
                    holder1.topicTagImageView1= (ImageView) view.findViewById(R.id.topic_tag_image_view1);
                    holder1.topicPublishTimeTextView1= (TextView) view.findViewById(R.id.topic_publish_time_textview1);
                    holder1.topicShareTextView1= (TextView) view.findViewById(R.id.share_num_text_view1);
                    holder1.topicCommentTextView1= (TextView) view.findViewById(R.id.comment_num_text_view1);
                    holder1.topicUpvoteTextView1= (TextView) view.findViewById(R.id.upvote_text_view1);
                    view.setTag(holder1);
                    break;
            }
        }else {
            switch (type){
                case TYPE_1:
                    holder = (viewHolder) view.getTag();
                    break;
                case TYPE_2:
                    holder1= (viewHolder1) view.getTag();
                    break;
            }
        }
        switch (type){
            case TYPE_1:
                //TODO 设置数据
                if(imageInfos != null && imageInfos.length > 0) {
                    ImageLoaderUtil.displayImage(imageInfos[0].formatedDownloadUrl, holder.topicPicImageView);
                }
                holder.topicTitleTextView.setText(sSysTopic.title);
//                holder.topicTagImageView
                holder.topicContentTextView.setText(sSysTopic.content);
                holder.topicPublishTimeTextView.setText(DateUtil.getDateIntervelTimeStringToNow(sSysTopic.createDt));
                holder.topicShareTextView.setText(sSysTopic.sharedTimes+"");
                holder.topicCommentTextView.setText(sSysTopic.commentedTimes+"");
                holder.topicUpvoteTextView.setText(sSysTopic.upvotedTimes+"");
                break;
            case TYPE_2:
                //TODO 设置数据
                holder1.topicTitleTextView1.setText(sSysTopic.title);
//                holder1.topicTagImageView1
                holder1.topicPublishTimeTextView1.setText(DateUtil.getDateIntervelTimeStringToNow(sSysTopic.createDt));
                holder1.topicShareTextView1.setText(sSysTopic.sharedTimes+"");
                holder1.topicCommentTextView1.setText(sSysTopic.commentedTimes+"");
                holder1.topicUpvoteTextView1.setText(sSysTopic.upvotedTimes+"");

                if(imageInfos.length >= 3){
                    holder1.topicPicImageView1.setVisibility(View.VISIBLE);
                    holder1.topicPicImageView2.setVisibility(View.VISIBLE);
                    holder1.topicPicImageView3.setVisibility(View.VISIBLE);
                }
//                else {
//                    holder1.topicPicImageView1.setVisibility(View.VISIBLE);
//                    holder1.topicPicImageView2.setVisibility(View.VISIBLE);
//                    holder1.topicPicImageView3.setVisibility(View.GONE);
//                }
                if(imageInfos != null && imageInfos.length > 0){
                ArrayList<String> urlList = new ArrayList<>();
                //微说列表预览时只下载指定数量的图片，目前下载3张,图片为缩略图
                int count = 0;
                for (gatemsg.SImageInfo imageInfo:imageInfos) {
                    ImageView image = null;
                    switch (count){
                        case 0:
                            image = holder1.topicPicImageView1;
                            break;
                        case 1:
                            image = holder1.topicPicImageView2;
                            break;
                        case 2:
                            image = holder1.topicPicImageView3;
                            break;
                    }
                    ImageLoaderUtil.displayImage(imageInfo.formatedDownloadUrl, image);
                    count ++ ;
                    if(count == MAX_IMAGE_COUNT){
                        break;
                    }

                }
            }
                break;
        }
        return view;
    }
    class viewHolder {
        ImageView topicPicImageView;
        TextView topicTitleTextView;
        TextView topicPublishTimeTextView;
        TextView topicContentTextView;
        TextView topicShareTextView;
        TextView topicCommentTextView;
        TextView topicUpvoteTextView;
        ImageView topicTagImageView;

    }

    class viewHolder1{
        ImageView topicPicImageView1;
        ImageView topicPicImageView2;
        ImageView topicPicImageView3;
        TextView topicTitleTextView1;
        TextView topicPublishTimeTextView1;
        TextView topicShareTextView1;
        TextView topicCommentTextView1;
        TextView topicUpvoteTextView1;
        ImageView topicTagImageView1;
    }
    public static String ToSBC(String input) {
        char c[] = input.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (c[i] == ' ') {
                c[i] = '\u3000';
            } else if (c[i] < '\177') {
                c[i] = (char) (c[i] + 65248);
            }
        }
        return new String(c);
    }
}
