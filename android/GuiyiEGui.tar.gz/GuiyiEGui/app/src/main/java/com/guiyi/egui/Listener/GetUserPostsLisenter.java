package com.guiyi.egui.Listener;

import java.util.ArrayList;

import message.gate.gatemsg;

/**
 * Created by ForOne on 15/8/19.
 */
public interface GetUserPostsLisenter {
    void getUserPostsCallback(ArrayList<gatemsg.SUserPost> userPosts);
}
