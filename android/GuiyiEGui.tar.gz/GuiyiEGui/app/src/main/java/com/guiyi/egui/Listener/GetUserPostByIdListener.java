package com.guiyi.egui.Listener;

import message.gate.gatemsg;

/**
 * Created by ForOne on 15/8/24.
 */
public interface GetUserPostByIdListener {
    void getUserPostResponse(gatemsg.SUserPost userPost);
}
