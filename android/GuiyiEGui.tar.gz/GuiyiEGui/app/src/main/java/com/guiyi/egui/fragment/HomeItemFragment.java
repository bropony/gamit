package com.guiyi.egui.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.guiyi.egui.Listener.GetSystemTopicListener;
import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.Managers.SystemTopicManager;
import com.guiyi.egui.Managers.TopicTagsManager;
import com.guiyi.egui.R;
import com.guiyi.egui.activity.home.SystemTopicDetialsActivity;
import com.guiyi.egui.activity.home.citylist.ActivityCityList;
import com.guiyi.egui.adapter.SystemTopicAdapter;
import com.guiyi.egui.bean.TopicTag;
import com.guiyi.egui.customwidget.XListView.XListView;
import com.guiyi.egui.events.LocationChangedEvent;
import com.guiyi.egui.events.SystemTopicStatusChangedEvent;
import com.guiyi.egui.util.BaiduMapUtils;
import com.guiyi.egui.util.SaveGetFileUtil;
import com.jenwis.android.base.base.util.LogUtils;

import java.io.File;
import java.util.ArrayList;

import de.greenrobot.event.EventBus;
import message.gate.gatemsg;

public class HomeItemFragment extends Fragment implements XListView.IXListViewListener,AdapterView.OnItemClickListener,View.OnClickListener{

	private static final String ARG_POSITION = "position";

	private int position;
	private ArrayList<gatemsg.SSysTopic> mSystemTopics;
	private XListView mListView;
	private SystemTopicAdapter mAdapter;
	private TextView mSelectCityTextView;
	private TextView mPositionTextView;
	private ArrayList<TopicTag> mTopicTags = new ArrayList<>();
	private String mCurrentCity = "广州";

	public static HomeItemFragment newInstance(int position) {
		HomeItemFragment f = new HomeItemFragment();
		Bundle b = new Bundle();
		b.putInt(ARG_POSITION, position);
		f.setArguments(b);
		return f;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		position = getArguments().getInt(ARG_POSITION);
		EventBus.getDefault().register(this);
		mAdapter = new SystemTopicAdapter(getActivity());
		mCurrentCity = LocalInfoManager.getInstance(getActivity()).getLocalCity();
		if (mCurrentCity == null || mCurrentCity.length() == 0) {
			mCurrentCity = "广州";
		}
		mTopicTags = TopicTagsManager.getInstance(getActivity()).getSelectedTopicTags();
		onRefresh();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view=inflater.inflate(R.layout.home_view_pager_item_fragment, container, false);
		LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.position_ll);
		mTopicTags = TopicTagsManager.getInstance(getActivity()).getSelectedTopicTags();
		FrameLayout framelayout = (FrameLayout) view.findViewById(R.id.frame_content);
		mSelectCityTextView= (TextView) view.findViewById(R.id.select_city_text_view);
		mPositionTextView= (TextView) view.findViewById(R.id.position_text_view);

		mPositionTextView.setOnClickListener(this);
		if (isSameCity()){
			linearLayout.setVisibility(View.VISIBLE);
			mSelectCityTextView.setOnClickListener(this);
			mSelectCityTextView.setText(mCurrentCity);
		}else {
			linearLayout.setVisibility(View.GONE);
		}
		LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		framelayout.setBackgroundResource(R.color.background_gray);

		final int margin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 8, getResources()
				.getDisplayMetrics());

		mListView = new XListView(getActivity());
		params.setMargins(margin, 0, margin, 0);
		mListView.setLayoutParams(params);
		mListView.setPullLoadEnable(true);
		mListView.setXListViewListener(this);
		mListView.setOnItemClickListener(this);

		mListView.setVerticalScrollBarEnabled(false);
		mListView.setDivider(new ColorDrawable(0xffebebeb));
		mListView.setDividerHeight(15);
		mListView.setAdapter(mAdapter);
		framelayout.addView(mListView);
		return view;
	}

	@Override
	public void onRefresh() {
		if (isSameCity()){
			getLatestSystemTopicsByTag(mCurrentCity);
		}else {
			getLatestSystemTopicsByTag(mTopicTags.get(position).getTagId());
		}
	}



	@Override
	public void onLoadMore() {
		if (isSameCity()){
			getOldestSystemTopicsByTag(mCurrentCity);
		}else {
			getOldestSystemTopicsByTag(mTopicTags.get(position).getTagId());
		}
	}

	private void getLatestSystemTopicsByTag(String tag){
		SystemTopicManager.getInstance(getActivity()).getLatestSystemTopics(getSystemTopicListener, tag, 20);
	}

	private void getOldestSystemTopicsByTag(String tag){
		SystemTopicManager.getInstance(getActivity()).getOldestSystemTopics(getSystemTopicListener, tag, 20);
	}

	GetSystemTopicListener getSystemTopicListener = new GetSystemTopicListener() {
		@Override
		public void getSystemTopicsCallback(ArrayList<gatemsg.SSysTopic> systemTopics) {
			mSystemTopics=systemTopics;
			updateTopic();
			onLoad();
		}

		@Override
		public void failed(String message) {

		}
	};
	private void onLoad() {
		mListView.stopRefresh();
		mListView.stopLoadMore();
		mListView.setRefreshTime("刚刚");
	}
	private void updateTopic(){
		mAdapter.setSystemTopics(mSystemTopics);
		mAdapter.notifyDataSetChanged();
	}

	private boolean  isSameCity(){
		return mTopicTags.get(position).getTagType() != null && mTopicTags.get(position).getTagType().equals("1");
	}

	/**
	 * 此函数会由EventBus调用，用于更新话题状态
	 * @param systemTopicStatusChangedEvent
	 *
	 */
	public void onEventMainThread(SystemTopicStatusChangedEvent systemTopicStatusChangedEvent){
		if(mSystemTopics != null){
			for (gatemsg.SSysTopic topic:mSystemTopics
				 ) {
				if(topic.topicId.equals(systemTopicStatusChangedEvent.SystemTopicId)){
					topic.upvotedTimes = systemTopicStatusChangedEvent.UpvoteCount;
					topic.viewTimes = systemTopicStatusChangedEvent.VisitCount;
					topic.sharedTimes = systemTopicStatusChangedEvent.ShareCount;
					topic.commentedTimes = systemTopicStatusChangedEvent.CommentCount;
				}
			}
		}
		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
		String id = mSystemTopics.get(position-1).topicId;
		Intent intent = new Intent(getActivity(), SystemTopicDetialsActivity.class);
		intent.putExtra(SystemTopicDetialsActivity.SYSTEM_TOPIC_ID, id);
		startActivity(intent);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		EventBus.getDefault().unregister(this);
	}


	private void selectCurrentCity(){
		Intent intent = new Intent(getActivity(),ActivityCityList.class);
		startActivity(intent);
	}

	private void setCurrentCity(String cityName){
		mCurrentCity = cityName;
		mSelectCityTextView.setText(cityName);
		LocalInfoManager.getInstance(getActivity()).setLocalCity(mCurrentCity);
		mSystemTopics.clear();
		updateTopic();
		getLatestSystemTopicsByTag(cityName);
	}

	public void getLocationCity(){
		Log.v("location", "getLocationCity");
		BaiduMapUtils.getInstance(getActivity()).setLocationChangedListener(mLocationChangedListener);
		BaiduMapUtils.getInstance(getActivity()).start();
		Log.v("location", "start");
	}

	BaiduMapUtils.LocationChangedListener mLocationChangedListener = new BaiduMapUtils.LocationChangedListener() {
		@Override
		public void locationChanged(String city, String cityCode) {
			setCurrentCity(city);
			BaiduMapUtils.getInstance(getActivity()).stop();
		}

		@Override
		public void locationFailed(int errorCode) {

		}
	};

	//当通过城市列表选择城市时，会由EventBus调用此函数
	public void onEventMainThread(LocationChangedEvent locationChangedEvent){
		if(isSameCity()){
			setCurrentCity(locationChangedEvent.CityName);
		}
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()){
			case R.id.select_city_text_view:
				selectCurrentCity();
				break;
			case R.id.position_text_view:
				getLocationCity();
				break;
		}
	}
}