package com.guiyi.egui.activity.customize;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.guiyi.egui.util.T;
import com.guiyi.egui.view.OrangeTextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by rentianlong on 2015/9/10.16:10
 * <p/>
 * company GDGY
 */
public class AddChooseClothActivity extends BackNavActivity {

    private LinearLayout natural_ll;
    private LinearLayout artificial_fiber;
    public static final int RESULT_CODE = 0x124;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_add_choose_cloth);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        super.findActionBarView(this);
        //
        natural_ll = (LinearLayout) findViewById(R.id.id_ll_natural);
        artificial_fiber = (LinearLayout) findViewById(R.id.id_artificial_fiber);
    }

    @Override
    public void setView() {
        mTitleTextView.setText(R.string.choose_cloth);
    }

    @Override
    public void setViewListener() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.tv_cotton:

                break;
            default:
                break;
        }
    }

    @Override
    public void onBackPressed() {
        HashMap<Integer, String> map = new HashMap<>();

        int childCount = natural_ll.getChildCount();
        for (int i = 0; i < childCount; i++) {
            OrangeTextView childAt = (OrangeTextView) natural_ll.getChildAt(i);
            Log.i("TAG", "onBackPressed " + childAt.isSelected());
            if (childAt.isSelected()) {
                String s = childAt.getText().toString();
                map.put(childAt.getId(), s);
            }
        }
        childCount = artificial_fiber.getChildCount();
        for (int i = 0; i < childCount; i++) {
            OrangeTextView childAt = (OrangeTextView) artificial_fiber.getChildAt(i);
            Log.i("TAG", "onBackPressed " + childAt.isSelected());
            if (childAt.isSelected()) {
                String s = childAt.getText().toString();
                map.put(childAt.getId(), s);
            }
        }
        Bundle bundle = new Bundle();
        bundle.putSerializable("selectedData", map);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(RESULT_CODE, intent);
        super.onBackPressed();
    }
}
