package com.guiyi.egui.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by C on 2015/8/10.
 */
public class CommonUtil {

    public static boolean IsLogined = false;

    /**
     * 判断当前是否有可用的网络以及网络类型 0：无网络 1：WIFI 2：CMWAP 3：CMNET
     *
     * @param context
     * @return
     */
    public static int isNetworkAvailable(Context context) {
        ConnectivityManager connectivity = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity == null) {
            return 0;
        } else {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null) {
                for (int i = 0; i < info.length; i++) {
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        NetworkInfo netWorkInfo = info[i];
                        if (netWorkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                            return 1;
                        } else if (netWorkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                            String extraInfo = netWorkInfo.getExtraInfo();
                            if ("cmwap".equalsIgnoreCase(extraInfo)
                                    || "cmwap:gsm".equalsIgnoreCase(extraInfo)) {
                                return 2;
                            }
                            return 3;
                        }
                    }
                }
            }
        }
        return 0;
    }
    /**
     * 获取手机唯一标识码
     * @param context
     * @return
     */
    public static String getDeviceCode(Context context){
        TelephonyManager telephonyManage=(TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
        String deviceCode=telephonyManage.getDeviceId();
        return deviceCode;
    }

        public static String getCurrentTime(String format) {
            Date date = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.getDefault());
            String currentTime = sdf.format(date);
            return currentTime;
        }

        public static String getCurrentTime() {
            return getCurrentTime("yyyy-MM-dd  HH:mm:ss");
        }
}

