package com.guiyi.egui.activity.personal;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.R;
import com.guiyi.egui.logic.config.SharedPreferenceConfig;
import com.guiyi.egui.util.ImageLoaderUtil;
import com.guiyi.egui.util.SharePrefUtil;
import com.guiyi.egui.websocket.RequestWS;
import com.jenwis.android.base.base.util.LogUtils;
import com.jenwis.android.base.ui.BaseActionBarActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import message.gate.iuserinfo;


/**
 * Created by C on 2015/8/12.
 */
public class PersonalInfoActivity extends BaseActionBarActivity implements View.OnClickListener{
    private TextView mTitle;
    private TextView mNickNameTextView;
    private TextView mAccountTextView;
    private TextView mSexTextView;
    private TextView mBirthdayTextView;
    private TextView mBack;
    private TextView mCityTextView;
    private RelativeLayout mAddressRelativeLayout;
    private RelativeLayout mNickNameRelativeLayout;
    private RelativeLayout mAccountRelativeLayout;
    private RelativeLayout mSexRelativeLayout;
    private RelativeLayout mBirthdayRelativeLayout;
    private RelativeLayout mCityRelativeLayout;
    private RelativeLayout mIconRelativeLayout;
    private ImageView mIconImageView;
    private String mPhotoSavePath;//保存路径
    private String mPhotoSaveName;//图pian名
    private PopupWindow mPopWindow;
    private LayoutInflater mLayoutInflater;
    private TextView mPhotograph, mAlbums;
    private LinearLayout mCancel;
    private String mPath;

    public static final int PHOTOZOOM = 0; // 相册/拍照
    public static final int PHOTOTAKE = 1; // 相册/拍照
    public static final int IMAGE_COMPLETE = 2; // 结果
    public static final int CROPREQCODE = 3; // 截取
    public static final int MODIFYNICKNAME=5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_personal_info);
        super.onCreate(savedInstanceState);


    }

    @Override
    public void init() {
        mLayoutInflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        File file = new File(getExternalFilesDir(null)+ "/com.guiyi.egui/cache/");
        if (!file.exists())
            file.mkdirs();
        mPhotoSavePath = getExternalFilesDir(null)+ "/com.guiyi.egui/cache/";
        mPhotoSaveName = LocalInfoManager.getInstance(this).getUserId()+ ".png";
    }


    @Override
    public void findView() {
        mTitle =(TextView)findViewById(R.id.title_tv);
        mBack = (TextView) findViewById(R.id.back_tv);
        mIconRelativeLayout = (RelativeLayout) findViewById(R.id.icon_rl);
        mIconImageView= (ImageView) findViewById(R.id.icon_iv);
        mNickNameRelativeLayout = (RelativeLayout) findViewById(R.id.nickName_rl);
        mNickNameTextView = (TextView) findViewById(R.id.nickName_tv);
        mAccountRelativeLayout = (RelativeLayout) findViewById(R.id.account_rl);
        mAccountTextView = (TextView) findViewById(R.id.account_tv);
        mSexRelativeLayout = (RelativeLayout) findViewById(R.id.sex_rl);
        mSexTextView = (TextView) findViewById(R.id.sex_tv);
        mBirthdayRelativeLayout = (RelativeLayout) findViewById(R.id.birthday_rl);
        mBirthdayTextView = (TextView) findViewById(R.id.birthday_tv);
        mCityRelativeLayout = (RelativeLayout) findViewById(R.id.city_rl);
        mCityTextView = (TextView) findViewById(R.id.city_tv);
        mAddressRelativeLayout = (RelativeLayout) findViewById(R.id.address_rl);
    }

    @Override
    public void setView() {
        mTitle.setText("个人信息");
        mAccountTextView.setText(LocalInfoManager.getInstance(this).getAccount());
    }

    @Override
    public void setViewListener() {

        mBack.setOnClickListener(this);
        mIconRelativeLayout.setOnClickListener(this);
        mNickNameRelativeLayout.setOnClickListener(this);
        mAccountRelativeLayout.setOnClickListener(this);
        mSexRelativeLayout.setOnClickListener(this);
        mBirthdayRelativeLayout.setOnClickListener(this);
        mCityRelativeLayout.setOnClickListener(this);
        mAddressRelativeLayout.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        renewInfon();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_tv:
                finish();
                break;
            case R.id.icon_rl:
                showPopupWindow(mIconRelativeLayout);
                break;
            case R.id.nickName_rl:
                Intent intent = new Intent(this,ModifyNickNameActivity.class);
                intent.putExtra("NickName",mNickNameTextView.getText().toString().trim());
                startActivityForResult(intent, MODIFYNICKNAME);
                break;
            case R.id.account_rl:

                break;
            case R.id.sex_rl:
                selectGender();
                break;
            case R.id.birthday_rl:
                fillInBirthday();
                break;
            case R.id.city_rl:
                break;
            case R.id.address_rl:
                Intent address = new Intent(this, AddressManageActivity.class);
                startActivity(address);
                break;
            default:
                break;
        }
    }
    private void renewInfon(){
        mNickNameTextView.setText(LocalInfoManager.getInstance(this).getNickName());
        String avatarUrl = LocalInfoManager.getInstance(this).getAvatarUrl();
        if (avatarUrl != null && !avatarUrl.equals("")){
            ImageLoaderUtil.displayImage(avatarUrl, mIconImageView);
        }else{
            mIconImageView.setImageResource(R.drawable.head);
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date birthday = LocalInfoManager.getInstance(this).getBirthday();
        if (birthday != null){
            String birthdayStr = dateFormat.format(birthday);
            mBirthdayTextView.setText(birthdayStr);
        }else {
            mBirthdayTextView.setText(R.string.not_write);
        }

        int gender = LocalInfoManager.getInstance(this).getGender();
        if (gender==1) {
            mSexTextView.setText(R.string.male);
        }else if(gender==2){
            mSexTextView.setText(R.string.female);
        }else {
            mSexTextView.setText(R.string.not_write);
        }
    }

    private void selectGender() {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("性别");
        final ChoiceOnClickListener choiceListener =
                new ChoiceOnClickListener();
        builder.setSingleChoiceItems(R.array.gender, 0, choiceListener);

        DialogInterface.OnClickListener btnListener =
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {

                        int choiceWhich = choiceListener.getWhich();
                        String genderStr = getResources().getStringArray(R.array.gender)[choiceWhich];
                        mSexTextView.setText(genderStr);
                        int gender=3;
                        if (genderStr.equals("男")){
                            LocalInfoManager.getInstance(PersonalInfoActivity.this).setGender(1);
                            gender=1;
                        }else if(genderStr.equals("女")){
                            LocalInfoManager.getInstance(PersonalInfoActivity.this).setGender(2);
                            gender=2;
                        }else {
                            LocalInfoManager.getInstance(PersonalInfoActivity.this).setGender(0);
                        }
                        updateGender(gender);
                        SharePrefUtil.saveInt(PersonalInfoActivity.this, SharedPreferenceConfig.gender,gender);
                    }
                };
        builder.setPositiveButton("确定", btnListener);
        dialog = builder.create();
        dialog.show();
    }
    private class ChoiceOnClickListener implements DialogInterface.OnClickListener {

        private int which = 0;
        @Override
        public void onClick(DialogInterface dialogInterface, int which) {
            this.which = which;
        }

        public int getWhich() {
            return which;
        }
    }
    //填写性别
    private void updateGender(int i){
        IUserInfoUpdateGender response = new IUserInfoUpdateGender();
        RequestWS.getInstance().getUserInfoProxy().updateGender(response, LocalInfoManager.getInstance(this).getSessionKey(),i);
    }

    //填写生日
    private void fillInBirthday() {
        Calendar calendar = Calendar.getInstance();

        Dialog dialog=null;
                DatePickerDialog.OnDateSetListener dateListener =new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker,
                                                  int year, int month, int dayOfMonth) {
                                //Calendar月份是从0开始,所以month要加1
                                mBirthdayTextView.setText(year+"-0"+(month+1)+"-0"+dayOfMonth);
                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                String birthday=mBirthdayTextView.getText().toString();
                                SharePrefUtil.saveString(PersonalInfoActivity.this,SharedPreferenceConfig.birthday,birthday);
                                Date date=null;
                                try {
                                    date = simpleDateFormat.parse(birthday);

                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                                updateBirthday(date);
                                LocalInfoManager.getInstance(PersonalInfoActivity.this).setBirthday(date);
                            }
                        };
                dialog = new DatePickerDialog(this,
                        dateListener,
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH));
        dialog.show();
        }
    //上传生日
    private void updateBirthday(Date date){
        IUserInfoUpdateBirthday response = new IUserInfoUpdateBirthday();
        RequestWS.getInstance().getUserInfoProxy().updateBirthDay(response, LocalInfoManager.getInstance(this).getSessionKey(), date);

    }
    private void showPopupWindow(View parent){
        if (mPopWindow == null) {
            View view = mLayoutInflater.inflate(R.layout.popwindow_select_photo,null);
            mPopWindow = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,true);
            initPop(view);
        }
        mPopWindow.setAnimationStyle(android.R.style.Animation_InputMethod);
        mPopWindow.setFocusable(true);
        mPopWindow.setOutsideTouchable(true);
        mPopWindow.setBackgroundDrawable(new BitmapDrawable());
        mPopWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        mPopWindow.showAtLocation(parent, Gravity.CENTER, 0, 0);
    }

    public void initPop(View view){
        mPhotograph = (TextView) view.findViewById(R.id.photograph);//拍照
        mAlbums = (TextView) view.findViewById(R.id.albums);//相册
        mCancel = (LinearLayout) view.findViewById(R.id.cancel);//取消
        mPhotograph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                mPopWindow.dismiss();
                mPhotoSaveName = String.valueOf(System.currentTimeMillis()) + ".png";
                Uri imageUri = null;
                Intent openCameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                imageUri = Uri.fromFile(new File(mPhotoSavePath, mPhotoSaveName));
                openCameraIntent.putExtra(MediaStore.Images.Media.ORIENTATION, 0);
                openCameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(openCameraIntent, PHOTOTAKE);
            }
        });
        mAlbums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                mPopWindow.dismiss();
                Intent openAlbumIntent = new Intent(Intent.ACTION_GET_CONTENT);
                openAlbumIntent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                startActivityForResult(openAlbumIntent, PHOTOZOOM);
            }
        });
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                mPopWindow.dismiss();

            }
        });
    }

    /**
     * 图片选择及拍照结果
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK) {
            return;
        }
        Uri uri = null;
        switch (requestCode) {
            case PHOTOZOOM://相册
                if (data==null) {
                    return;
                }
                uri = data.getData();
                String[] proj = { MediaStore.Images.Media.DATA };
                Cursor cursor = managedQuery(uri, proj, null, null,null);
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                cursor.moveToFirst();
                mPath = cursor.getString(column_index);// 图片在的路径
                Intent intent3=new Intent(PersonalInfoActivity.this, ClipActivity.class);
                intent3.putExtra("path", mPath);
                startActivityForResult(intent3, IMAGE_COMPLETE);
                break;
            case PHOTOTAKE://拍照
                mPath= mPhotoSavePath + mPhotoSaveName;
                uri = Uri.fromFile(new File(mPath));
                Intent intent2=new Intent(PersonalInfoActivity.this, ClipActivity.class);
                intent2.putExtra("path", mPath);
                startActivityForResult(intent2, IMAGE_COMPLETE);
                break;
            case IMAGE_COMPLETE:
                final String tempPath = data.getStringExtra("path");
                SharePrefUtil.saveString(this, LocalInfoManager.getInstance(this).getUserId(),tempPath);
                mIconImageView.setImageBitmap(getLoacalBitmap(tempPath));
                break;
            case 4:

                break;
            case MODIFYNICKNAME:
                if (resultCode==RESULT_OK){
                    String nickName = data.getStringExtra("NickName");
                    mNickNameTextView.setText(nickName);
                    LocalInfoManager.getInstance(this).setNickName(nickName);
                }
                break;
            default:
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * @param url
     * @return
     */
    public static Bitmap getLoacalBitmap(String url) {
        try {
            FileInputStream fis = new FileInputStream(url);
            return BitmapFactory.decodeStream(fis);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    class IUserInfoUpdateBirthday extends iuserinfo.IUserInfo_updateBirthDay_response{

        @Override
        public void onResponse() {
            LogUtils.LogD("updateBirthday","updateBirthday success!!");
        }

        @Override
        public void onError(String what, int code) {
            LogUtils.LogD("updateBirthday","updateBirthday onError!!");
        }

        @Override
        public void onTimeout() {
            LogUtils.LogD("updateBirthday","updateBirthday onTimeout!!");
        }
    }
    class IUserInfoUpdateGender extends iuserinfo.IUserInfo_updateGender_response{

        @Override
        public void onResponse() {

        }

        @Override
        public void onError(String what, int code) {

        }

        @Override
        public void onTimeout() {

        }
    }

}
