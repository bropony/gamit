package com.guiyi.egui.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.R;
import com.guiyi.egui.activity.personal.LoginActivity;
import com.guiyi.egui.activity.personal.PersonalInfoActivity;
import com.guiyi.egui.activity.personal.SettingActivity;
import com.guiyi.egui.logic.config.SharedPreferenceConfig;
import com.guiyi.egui.util.CommonUtil;
import com.guiyi.egui.util.ImageLoaderUtil;
import com.guiyi.egui.util.SharePrefUtil;
import com.jenwis.android.base.ui.BaseFragment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;


/**
 * Created by C on 2015/8/7.
 */
public class PersonalFragment extends BaseFragment implements View.OnClickListener {
    private RelativeLayout mInfoRelativeLayout;
    private RelativeLayout mLoginRelativeLayout;
    private ImageView mIconImageView;
    private TextView mVipNumberTextView;
    private TextView mSettingTextView;
    private TextView mNickNameTextView;
    private View mContentView;
    private TextView mBack;
    private TextView mTitle;
    private int mRequestCode = 2;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mContentView = inflater.inflate(R.layout.fragment_personal, container, false);
        super.onCreateView(inflater, container, savedInstanceState);
        return mContentView;
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mBack = (TextView) mContentView.findViewById(R.id.back_tv);
        mTitle = (TextView) mContentView.findViewById(R.id.title_tv);
        mLoginRelativeLayout = (RelativeLayout) mContentView.findViewById(R.id.login_rl);
        mIconImageView = (ImageView) mLoginRelativeLayout.findViewById(R.id.icon_iv);
        mInfoRelativeLayout = (RelativeLayout) mLoginRelativeLayout.findViewById(R.id.personInfo_rl);
        mNickNameTextView = (TextView) mInfoRelativeLayout.findViewById(R.id.nickName_tv);
        mVipNumberTextView = (TextView) mInfoRelativeLayout.findViewById(R.id.vipNum_tv);
        mSettingTextView = (TextView) mContentView.findViewById(R.id.setting_tv);

    }

    @Override
    public void setView() {
        mTitle.setText(R.string.action_bar_title_my_info);
        mBack.setVisibility(View.INVISIBLE);
        if (LocalInfoManager.getInstance(getActivity()).getSessionKey() != null &&
                !LocalInfoManager.getInstance(getActivity()).getSessionKey().equals("")) {
            String avatarUrl = LocalInfoManager.getInstance(getActivity()).getAvatarUrl();
            if (avatarUrl != null && !avatarUrl.equals("")) {
                ImageLoaderUtil.displayImage(avatarUrl, mIconImageView);
            } else {
                mIconImageView.setImageResource(R.drawable.head);
            }
            mNickNameTextView.setText(LocalInfoManager.getInstance(getActivity()).getNickName());
            mVipNumberTextView.setText(LocalInfoManager.getInstance(getActivity()).getUserId());
        }
    }

    @Override
    public void setViewListener() {
        mLoginRelativeLayout.setOnClickListener(this);
        mSettingTextView.setOnClickListener(this);
    }

    @Override
    public void onPageSelected() {

    }

    @Override
    public void onPageDisSelected() {

    }

    @Override
    public void onDataChange(int type, Object obj) {

    }

    @Override
    public void onResume() {
        super.onResume();
        if (!CommonUtil.IsLogined) {
            mIconImageView.setImageResource(R.drawable.head);
            mNickNameTextView.setText(R.string.button_login);
            mVipNumberTextView.setText("");
        } else {
            String avatarUrl = LocalInfoManager.getInstance(getActivity()).getAvatarUrl();
            if (avatarUrl != null && !avatarUrl.equals("")) {
                ImageLoaderUtil.displayImage(avatarUrl, mIconImageView);
            } else {
                mIconImageView.setImageResource(R.drawable.head);
            }

            mNickNameTextView.setText(LocalInfoManager.getInstance(getActivity()).getNickName());
            mVipNumberTextView.setText(LocalInfoManager.getInstance(getActivity()).getUserId());
        }
    }

    private void getUserAvatar(String avatarUr) {
        ImageLoaderUtil.displayImage(avatarUr, mIconImageView);
    }

    private void updateUserinfo(String nickName, String userId) {
        mNickNameTextView.setText(nickName);
        mVipNumberTextView.setText(userId);
        Log.v("Login", "updateUserinfo");
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == mRequestCode && resultCode == -1) {
            updateUserinfo(LocalInfoManager.getInstance(getActivity()).getNickName(), LocalInfoManager.getInstance(getActivity()).getUserId());
        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.login_rl:
                if (SharePrefUtil.getString(getActivity(), SharedPreferenceConfig.sessionKey, "").equals("")) {
                    Intent intent = new Intent(getActivity(), LoginActivity.class);
                    startActivityForResult(intent, mRequestCode);
                } else {
                    Intent intent = new Intent(getActivity(), PersonalInfoActivity.class);
                    startActivity(intent);
                }

                break;
            case R.id.setting_tv:
                Intent intent = new Intent(getActivity(), SettingActivity.class);
                startActivity(intent);
                break;
            default:
                break;
        }
    }

    public static Bitmap getLoacalBitmap(String url) {
        try {
            FileInputStream fis = new FileInputStream(url);
            return BitmapFactory.decodeStream(fis);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}
