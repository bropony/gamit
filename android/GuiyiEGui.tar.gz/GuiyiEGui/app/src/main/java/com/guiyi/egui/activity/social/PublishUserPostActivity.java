package com.guiyi.egui.activity.social;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Dialog.ExpressionDialog;
import com.guiyi.egui.Listener.ChooseImageOperateListener;
import com.guiyi.egui.Listener.CommitUserPostListener;
import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.Managers.UserPostsManager;
import com.guiyi.egui.R;
import com.guiyi.egui.customwidget.CustomEditText.CustomEditText;
import com.guiyi.egui.customwidget.CustomProgressLoading.CustomProgress;
import com.guiyi.egui.customwidget.choosePhoto.ChooseImagePopup;
import com.guiyi.egui.customwidget.choosePhoto.PhotoActivity;
import com.guiyi.egui.customwidget.choosePhoto.BimpUtil;
import com.guiyi.egui.customwidget.choosePhoto.PhotoAlbumActivity;
import com.guiyi.egui.events.RefreshUserPostsEvent;
import com.guiyi.egui.util.FileUtils;
import com.guiyi.egui.util.StringUtil;
import com.jenwis.android.base.ui.BaseActionBarActivity;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

import de.greenrobot.event.EventBus;


/**
 * Created by Administrator on 2015/8/14.
 */
public class PublishUserPostActivity extends BaseActionBarActivity implements View.OnClickListener{
    private TextView mBackTextView;
    private TextView mPublishTextView;
    private EditText mTitleEditText;
    private CustomEditText mContentEditText;
    private GridView mImageGridView;
    private TextView mAddExpressionTextView;
    private GridAdapter adapter;

    public static final int CHOOSE_IMAMGE_FROM_PHOTO_REQUEST_CODE = 0;

    private static final int CONTENT_MAX_LENGTH = 200;
    private static final int TITLE_MAX_LENGTH = 16;

    public static final int CAMERA_REQUEST = 1;
    private String mFilename;
    private String mImagePathDir = "/sdcard/camera/";

    private TextView mContentLengthTextView;

    private boolean mIsCommiting;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_publish_talk);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mBackTextView = (TextView) findViewById(R.id.back_text_view);
        mPublishTextView= (TextView) findViewById(R.id.publish_text_view);
         mTitleEditText = (EditText) findViewById(R.id.title_edit_text);
        mImageGridView= (GridView) findViewById(R.id.image_grid_view);
        mContentEditText= (CustomEditText) findViewById(R.id.content_edit_text);
        mAddExpressionTextView = (TextView)findViewById(R.id.add_expression_text_view);
        mContentLengthTextView = (TextView)findViewById(R.id.content_max_length_text_view);
    }

    @Override
    public void setView() {
        mImageGridView.setSelector(new ColorDrawable(Color.TRANSPARENT));
        BimpUtil.Clear();
        updataGridView();

    }

    @Override
    public void setViewListener() {
        mBackTextView.setOnClickListener(this);
        mPublishTextView.setOnClickListener(this);
        mAddExpressionTextView.setOnClickListener(this);

        mImageGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                if (arg2 == BimpUtil.bmp.size()) {
                    new ChooseImagePopup(PublishUserPostActivity.this, mImageGridView, chooseImageOperateListener);
                } else {
                    Intent intent = new Intent(PublishUserPostActivity.this,
                            PhotoActivity.class);
                    intent.putExtra("ID", arg2);
                    startActivity(intent);
                }
            }
        });

        mContentEditText.addTextChangedListener(new TextWatcher() {

            String text = "";

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                Editable editable = mContentEditText.getText();
                String content = editable.toString();

                int length = StringUtil.getLengthOfGb2312(content);
                if(length > CONTENT_MAX_LENGTH){
                    mContentEditText.setText(text);
                }
                text = mContentEditText.getText().toString();
                mContentLengthTextView.setText(StringUtil.getLengthOfGb2312(text) + "/" + CONTENT_MAX_LENGTH);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        mTitleEditText.addTextChangedListener(new TextWatcher() {
            String text = "";
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                Editable editable = mTitleEditText.getText();
                String content = editable.toString();

                int length = StringUtil.getLengthOfGb2312(content);
                if(length > TITLE_MAX_LENGTH){
                    mTitleEditText.setText(text);
                }
                text = mTitleEditText.getText().toString();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_text_view:
                if ((mTitleEditText.getText().toString()).equals("")&&(mContentEditText.getText().toString()).equals("")){
                    finish();
                }else {
                    dialog();
                }
                break;
            case R.id.publish_text_view:
                ArrayList<String> path = BimpUtil.originalPicturesPath;
                String title = mTitleEditText.getText().toString();
                String content = mContentEditText.getText().toString();
                if(title.equals("") || content.equals("")){
                    Toast.makeText(this,"标题或者内容不能为空！",Toast.LENGTH_SHORT).show();
                }else{
                    if(!mIsCommiting){
                        CustomProgress.getInstance(PublishUserPostActivity.this).showProgress("发布中...",false,null);
                        UserPostsManager.getInstance(this).commitUserPost(commitUserPostListener, LocalInfoManager.getInstance(this).getSessionKey(),title,content,new ArrayList<String>(),path);
                        mIsCommiting = !mIsCommiting;
                    }
                }
                break;

            case R.id.add_expression_text_view:
                addExpression();
                break;
            default:
                break;
        }
    }

    ExpressionDialog.ExpressionDialogListener addExpressionCallback = new ExpressionDialog.ExpressionDialogListener() {
        @Override
        public void result(String value) {
            String text = mContentEditText.getText().toString();
            mContentEditText.setText(text + value);
        }
    };

    private void addExpression(){
        ExpressionDialog dialog = new ExpressionDialog(this,addExpressionCallback);
    }
    protected void dialog() {
         AlertDialog.Builder builder = new AlertDialog.Builder(PublishUserPostActivity.this);
        builder.setTitle("退出此次编辑");
        builder.setCancelable(true);
        builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                PublishUserPostActivity.this.finish();
            }
        });
         builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
             @Override
             public void onClick(DialogInterface dialog, int which) {
                 dialog.dismiss();
             }
         });
         builder.create().show();
        }
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            if ((mTitleEditText.getText().toString()).equals("")&&(mContentEditText.getText().toString()).equals("")){
                finish();
            }else {
                dialog();
            }
            }
        return false;
        }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_REQUEST){
            BimpUtil.ImagePathList.add(mFilename);
        }
    }

    private void updataGridView(){
        adapter = new GridAdapter(this);
        adapter.update();
        mImageGridView.setAdapter(adapter);
    }



    ChooseImageOperateListener chooseImageOperateListener = new ChooseImageOperateListener(){

        @Override
        public void chooseCamera() {
            String name = UUID.randomUUID().toString();
            mFilename = mImagePathDir + "/" + name + ".png";

            final File file = new File(mFilename);
            if(!file.exists()){
                File dirPath = file.getParentFile();
                dirPath.mkdirs();
            }
            Uri uri = Uri.fromFile(file);
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);//构造intent
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            startActivityForResult(cameraIntent, CAMERA_REQUEST);//发出intent，并要求返回调用结果

        }

        @Override
        public void choosePhoto() {
            Intent intent = new Intent(PublishUserPostActivity.this, PhotoAlbumActivity.class);
            startActivityForResult(intent,CHOOSE_IMAMGE_FROM_PHOTO_REQUEST_CODE);
        }

        @Override
        public void cancel() {

        }
    };

    CommitUserPostListener commitUserPostListener = new CommitUserPostListener() {
        @Override
        public void success() {
            Log.v("CommitUserPost", "success");
            BimpUtil.Clear();
            mIsCommiting = false;
            //更新本地用户帖子
            RefreshUserPostsEvent refreshUserPostsEvent = new RefreshUserPostsEvent();
            refreshUserPostsEvent.UserPosts = UserPostsManager.getInstance(PublishUserPostActivity.this).getUserPosts();
            EventBus.getDefault().post(refreshUserPostsEvent);
            CustomProgress.getInstance(PublishUserPostActivity.this).hideProgress();
            finish();
            Toast.makeText(PublishUserPostActivity.this,"发表微说成功！",Toast.LENGTH_SHORT).show();
        }

        @Override
        public void failure(String what, int code) {
            Log.v("CommitUserPost","failed " + code + ":" + what);
            mIsCommiting = true;
            CustomProgress.getInstance(PublishUserPostActivity.this).hideProgress();
            Toast.makeText(PublishUserPostActivity.this,"发表微说失败！Code "+ code + ":" + what,Toast.LENGTH_SHORT).show();
        }
    };

    public class GridAdapter extends BaseAdapter {
        private LayoutInflater inflater; // 视图容器
        private int selectedPosition = -1;// 选中的位置
        private boolean shape;

        public boolean isShape() {
            return shape;
        }

        public void setShape(boolean shape) {
            this.shape = shape;
        }

        public GridAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        public void update() {
            initBitmap();
        }

        public int getCount() {
            return (BimpUtil.bmp.size() + 1);
        }

        public Object getItem(int arg0) {

            return null;
        }

        public long getItemId(int arg0) {

            return 0;
        }

        /**
         * ListView Item设置
         */
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final int coord = position;
            ViewHolder holder = null;
            if (convertView == null) {

                convertView = inflater.inflate(R.layout.item_published_grida,
                        parent, false);
                holder = new ViewHolder();
                holder.image = (ImageView) convertView
                        .findViewById(R.id.item_gride_image);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            if (position == BimpUtil.bmp.size()) {
                holder.image.setImageBitmap(BitmapFactory.decodeResource(
                        getResources(), R.drawable.icon_addpic_unfocused));
                if (position == 9) {
                    holder.image.setVisibility(View.GONE);
                }
            } else if(position < BimpUtil.bmp.size()){
                holder.image.setImageBitmap(BimpUtil.bmp.get(position));
            }

            return convertView;
        }

        public class ViewHolder {
            public ImageView image;
        }

        Handler handler = new Handler() {
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 1:
                        adapter.notifyDataSetChanged();
                        break;
                }
                super.handleMessage(msg);
            }
        };

        public void initBitmap() {
            new Thread(new Runnable() {
                public void run() {
                    BimpUtil.originalPicturesPath.clear();
                    BimpUtil.bmp.clear();
                    int count = BimpUtil.ImagePathList.size();
                    if(count == 0){
                        return;
                    }

                  for(int i = 0 ;i < count; i ++){
                      String path = BimpUtil.ImagePathList.get(i);
                      BimpUtil.originalPicturesPath.add(path);
                      Bitmap bm = null;
                      try {
                          bm = BimpUtil.revitionImageSize(path);
                      } catch (IOException e) {
                          e.printStackTrace();
                      }
                      BimpUtil.bmp.add(bm);
                      String newStr = path.substring(
                              path.lastIndexOf("/") + 1,
                              path.lastIndexOf("."));
                      FileUtils.saveBitmap(bm, "" + newStr);
                      handler.sendEmptyMessage(1);
                      BimpUtil.max ++;
                  }
                }
            }).start();
        }
    }

    protected void onRestart() {
        super.onRestart();
        updataGridView();
    }


}
