package com.guiyi.egui.Managers;

import android.content.Context;

import com.guiyi.egui.util.DateUtil;
import com.guiyi.egui.util.SharePrefUtil;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Administrator on 2015/8/21.
 * Restructure by ForOne on 2015/9/7
 */
public class LocalInfoManager {

    private static final String NICK_NAME_KEY="NICK_NAME";
    private static final String SESSION_KEY_KEY ="SESSION_KEY";
    private static final String USER_ID_KEY="USER_ID";
    private static final String AVATAR_URL_KEY="AVATAR_URL";
    private static final String BIRTHDAY_KEY="BIRTHDAY";
    private static final String GENDER_KEY="GENDER";
    private static final String ACCOUNT_KEY="ACCOUNT";
    private static final String SELECTED_TOPIC_TAG = "SELECTED_TOPIC_TAG";
    private static final String TOPIC_TAG_SEQ = "TOPIC_TAG_SEQ";
    private static final String LOCATION_CITY = "LOCATION_CITY";

    private  String nickName;
    private  String userId;
    private  String sessionKey;
    private  String avatarUrl;
    private  int gender;
    private  Date birthday;
    private  String account;
    private String localCity;


    private Set<String> selectedTopicTags;
    private Set<String> topicTagsSeq;

    private static LocalInfoManager mUserInfoManager;
    private Context mContext;

    private LocalInfoManager(Context context){
        mContext = context;
    }

    public static LocalInfoManager getInstance(Context context){
        if(mUserInfoManager == null){
            mUserInfoManager = new LocalInfoManager(context);
        }
        return mUserInfoManager;
    }

    public String getSessionKey() {
        if(sessionKey != null && sessionKey.length() != 0){
            return sessionKey;
        }
        sessionKey = SharePrefUtil.getString(mContext, SESSION_KEY_KEY,null);
        return sessionKey;
    }

    public void setSessionKey(String sessionKey) {
        if(this.sessionKey == null ||!this.sessionKey.equals(sessionKey)){
            this.sessionKey = sessionKey;
            SharePrefUtil.saveString(mContext, SESSION_KEY_KEY,sessionKey);
        }
    }

    public String getNickName() {
        if(nickName != null && nickName.length() != 0){
            return nickName;
        }
        nickName = SharePrefUtil.getString(mContext,NICK_NAME_KEY,null);
        return nickName;
    }

    public void setNickName(String nickName) {
        if(this.nickName == null ||!this.nickName.equals(nickName)){
            this.nickName = nickName;
            SharePrefUtil.saveString(mContext,NICK_NAME_KEY,nickName);
        }
    }

    public String getLocalCity() {
        if(localCity != null && localCity.length() != 0){
            return localCity;
        }
        localCity = SharePrefUtil.getString(mContext,LOCATION_CITY,null);
        return localCity;
    }

    public void setLocalCity(String localCity) {
        if(this.localCity == null ||!this.localCity.equals(localCity)){
            this.localCity = localCity;
            SharePrefUtil.saveString(mContext,LOCATION_CITY,localCity);
        }
    }

    public String getUserId() {
        if(userId != null && userId.length() != 0){
            return userId;
        }
        userId = SharePrefUtil.getString(mContext,USER_ID_KEY,null);
        return userId;
    }

    public void setUserId(String userId) {
        if(this.userId == null ||!this.userId.equals(userId)){
            this.userId = userId;
            SharePrefUtil.saveString(mContext,USER_ID_KEY,userId);
        }
    }

    public String getAvatarUrl() {
        if(avatarUrl != null && avatarUrl.length() != 0){
            return avatarUrl;
        }
        avatarUrl = SharePrefUtil.getString(mContext,AVATAR_URL_KEY,null);
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        if(this.avatarUrl == null ||!this.avatarUrl.equals(avatarUrl)){
            this.avatarUrl = avatarUrl;
            SharePrefUtil.saveString(mContext,AVATAR_URL_KEY,avatarUrl);
        }
    }

    public int getGender() {
        if(gender!= 0){
            return gender;
        }
        gender = SharePrefUtil.getInt(mContext, GENDER_KEY, 0);
        return gender;
    }

    public void setGender(int gender) {
        if(this.gender == 0 || this.gender != gender){
            this.gender = gender;
            SharePrefUtil.saveInt(mContext, GENDER_KEY, gender);
        }
    }

    public Date getBirthday() {
        if(birthday != null){
            return birthday;
        }
        try{
            long time = SharePrefUtil.getLong(mContext,BIRTHDAY_KEY,(long)0);
            birthday = DateUtil.TimeStampConvetToDate(time);
        }catch (Exception ex){
        }


        return birthday;
    }

    public void setBirthday(Date birthday) {
        if(this.birthday == null && birthday == null){
           return;
        }

        if((this.birthday == null && birthday != null)
                ||(this.birthday != null && this.birthday.getTime() != this.birthday.getTime())){
            this.birthday = birthday;
            SharePrefUtil.saveLong(mContext, BIRTHDAY_KEY, birthday.getTime());
        }
    }

    public String getAccount() {
        if(account != null && account.length() != 0){
            return account;
        }
        account = SharePrefUtil.getString(mContext, ACCOUNT_KEY, null);
        return account;
    }

    public void setAccount(String account) {
        if(this.account == null || !this.account.equals(account)){
            this.account = account;
            SharePrefUtil.saveString(mContext, ACCOUNT_KEY, account);
        }
    }

    public Set<String> getSelectedTopicTags() {
        if(selectedTopicTags != null){
            return selectedTopicTags;
        }
        selectedTopicTags = SharePrefUtil.getSetString(mContext,SELECTED_TOPIC_TAG,new HashSet<String>());
        return selectedTopicTags;
    }

    public void setSelectedTopicTags(Set<String> selectedTopicTags) {
        SharePrefUtil.saveStringSet(mContext,SELECTED_TOPIC_TAG,selectedTopicTags);
        this.selectedTopicTags = selectedTopicTags;
    }

    public Set<String> getTopicTagsSeq() {
        if(topicTagsSeq != null){
            return topicTagsSeq;
        }
        topicTagsSeq = SharePrefUtil.getSetString(mContext,TOPIC_TAG_SEQ,new HashSet<String>());
        return topicTagsSeq;
    }

    public void setTopicTagsSeq(Set<String> topicTagsSeq) {
        SharePrefUtil.saveStringSet(mContext,TOPIC_TAG_SEQ,topicTagsSeq);
        this.topicTagsSeq = topicTagsSeq;
    }


}
