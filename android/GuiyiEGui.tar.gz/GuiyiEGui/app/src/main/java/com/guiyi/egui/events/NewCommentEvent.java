package com.guiyi.egui.events;

/**
 * Created by ForOne on 15/8/28.
 * 新评论事件（待完善）
 */
public class NewCommentEvent {
    private String mContent;

    private String mId;
}
