package com.guiyi.egui.WeiXin;

public class Constants {


    //appid
    //请同时修改  androidmanifest.xml里面，.WXPayActivityd里的属性<data android:scheme="wxb4ba3c02aa476ea1"/>为新设置的appid
    public static final String APP_ID = "wxf2f565574a968187";

    public static final String PACKAGE_VALUE = "rentianlong=TL317Ren";


    //商户号
    public static final String MCH_ID = "1233848001";


    //  API密钥，在商户平台设置
    public static final  String API_KEY="412fde4e9c2e2bb619514ecea142e449";



}
