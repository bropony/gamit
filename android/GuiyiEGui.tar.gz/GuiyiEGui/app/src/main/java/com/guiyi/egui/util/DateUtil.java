package com.guiyi.egui.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by ForOne on 15/8/19.
 */
public class DateUtil {

    public static Date DatePlusDay(Date date,int days){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_YEAR, days);
        return cal.getTime();
    }

    public static Date DateReduceDay(Date date,int days){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_YEAR, - days);
        return cal.getTime();
    }

    public static String getDateIntervelTimeStringToNow(Date date){
        Date now = new Date();
        long interval = now.getTime() - date.getTime();
        long intervalMinute = interval/(1000*60);
        if(intervalMinute < 1){
            return "刚刚";
        }else if(intervalMinute < 60){
            return intervalMinute + "分钟前";
        }else{
            long invertHour = intervalMinute/60;
            if(invertHour < 24){
                return invertHour + "小时前";
             }else{
                long invertDay = invertHour / 24;
                return invertDay + "天前";
            }
        }
    }

    public static int compareDate(Date date1, Date date2) {

        try {
            if (date1.getTime() > date2.getTime()) {
                return 1;
            } else if (date1.getTime() < date2.getTime()) {
                return -1;
            } else {
                return 0;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0;
    }

    public static Date TimeStampConvetToDate(long tiemStamp){
        SimpleDateFormat format = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
        String d = format.format(tiemStamp);
        Date date = null;
        try {
             date= format.parse(d);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }
}
