package com.guiyi.egui.bean;


/**
 * Created by Administrator on 2015/9/3.
 */
public class TopicTag{

    private Boolean isDefualt;
    private String tagName;
    private String tagId;

    public String getTagType() {
        return tagType;
    }

    public void setTagType(String tagType) {
        this.tagType = tagType;
    }

    private String tagType;

    public boolean isSelected() {
        return isSelected;
    }

    public void setIsSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

    private boolean isSelected;


    public Boolean getIsDefualt() {
        return isDefualt;
    }

    public void setIsDefualt(Boolean isDefualt) {
        this.isDefualt = isDefualt;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

}
