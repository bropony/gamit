package com.guiyi.egui.util;

import android.content.Context;
import android.content.Intent;

import com.guiyi.egui.activity.personal.LoginActivity;

import message.TErrorConfigEnum;
import rmi.RmiErrorDefaultHandler;

/**
 * Created by ForOne on 15/9/3.
 */
public class ResponseErrorUtil {

    private Context mContext;
    private static ResponseErrorUtil mResponseErrorUtil;

    public static ResponseErrorUtil getInstance(Context context){
        if(mResponseErrorUtil == null){
            mResponseErrorUtil = new ResponseErrorUtil(context);
        }
        return mResponseErrorUtil;
    }

    ResponseErrorUtil(Context context){
        mContext = context;
    }

    public void initHandler(){
        RmiErrorDefaultHandler.setErrorDefaultHandler(new ResponseErrorHandler());
    }

    class ResponseErrorHandler extends RmiErrorDefaultHandler.ErrorDefaultHandlerBase {
        @Override
        public void onError(String what, int code) {
            switch (code){
                case TErrorConfigEnum.ErrorGate_notLoggedInYet:
                   // login();
                    break;
            }
        }
    }

    private void login(){
        Intent intent=new Intent(mContext,LoginActivity.class);
        mContext.startActivity(intent);
    }

}
