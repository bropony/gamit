package com.guiyi.egui.logic.account;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AccountLogic {

    public static final String PASSWORD_REGEX =  "^.{6,18}$";
    public static final String EMAIL_REGEX = "^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
    public static final String CELLPHONE_NUMBER__REGEX = "^((13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$";

    // 判断email格式是否正确
    public static boolean isEmail(String email) {
        if (email == null) {
            return false;
        }
        return isMacthRegex(email, EMAIL_REGEX);
    }

    // 判断手机格式是否正确
    public static boolean isCellPhoneNumber(String cellPhoneNumber) {
        if (cellPhoneNumber == null) {
            return false;
        }
        return isMacthRegex(cellPhoneNumber, CELLPHONE_NUMBER__REGEX);
    }

    //判断密码是否符合规定
    public static boolean isPasswordLegal(String password) {
        if (password == null) {
            return false;
        }
        return isMacthRegex(password, PASSWORD_REGEX);
    }

    private static boolean isMacthRegex(String source, String regex){
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(source);
        return m.matches();
    }
}