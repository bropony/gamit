package com.guiyi.egui.activity.personal;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.R;
import com.guiyi.egui.logic.account.AccountLogic;
import com.guiyi.egui.logic.config.SharedPreferenceConfig;
import com.guiyi.egui.util.CommonUtil;
import com.guiyi.egui.customwidget.CircleImageView;

import message.common.publicdef;
import message.gate.gatemsg;
import message.gate.ilogin;

import com.guiyi.egui.util.SharePrefUtil;
import com.guiyi.egui.websocket.RequestWS;
import com.jenwis.android.base.base.util.LogUtils;
import com.jenwis.android.base.ui.BaseActionBarActivity;


/**
 * Created by C on 2015/8/7.
 */

public class LoginActivity extends BaseActionBarActivity implements View.OnClickListener {

    private TextView mSwitchTextView;
    private TextView mRegisterTextView;
    private TextView mFindPassWordTextView;
    private TextView mBackTextView;
    private Boolean mSwitch = false;
    private EditText mPhoneNumberEditText;
    private EditText mPassWordEditText;
    private Button mLoginButton;
    private String mPhoneNumber;
    private String mPassWord;
    private CircleImageView mIconCircleImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setBaseContentView(R.layout.activity_login);
        super.onCreate(savedInstanceState);

    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mPhoneNumberEditText = (EditText) findViewById(R.id.phoneNum_et);
        mPassWordEditText = (EditText) findViewById(R.id.pwd_et);
        mLoginButton = (Button) findViewById(R.id.login_btn);
        mBackTextView = (TextView) findViewById(R.id.back_tv);
        mSwitchTextView = (TextView) findViewById(R.id.switch_btn);
        mRegisterTextView = (TextView) findViewById(R.id.register_tv);
        mFindPassWordTextView = (TextView) findViewById(R.id.find_pwd_tv);
        mIconCircleImageView = (CircleImageView) findViewById(R.id.icon_iv);
    }

    @Override
    public void setView() {

    }

    @Override
    public void setViewListener() {
        mRegisterTextView.setOnClickListener(this);
        mLoginButton.setOnClickListener(this);
        mBackTextView.setOnClickListener(this);
        mSwitchTextView.setOnClickListener(this);
        mSwitchTextView.setOnClickListener(this);
        mFindPassWordTextView.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.switch_btn:
                TextViewSwitch();
                break;
            case R.id.register_tv:
                Intent reg = new Intent(this, RegisterActivity.class);
                startActivity(reg);
                break;
            case R.id.find_pwd_tv:
                Intent find = new Intent(this, FindPwdActivity.class);
                startActivity(find);
                break;
            case R.id.login_btn:
                login();
                break;
            case R.id.back_tv:
                finish();

                break;
            default:
                break;
        }
    }

    //密码与明码切换
    private void TextViewSwitch() {
        if (!mSwitch) {
            mSwitchTextView.setBackgroundResource(R.drawable.box_b);
            mPassWordEditText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
        } else {
            mSwitchTextView.setBackgroundResource(R.drawable.box_a);
            mPassWordEditText.setTransformationMethod(PasswordTransformationMethod.getInstance());
        }
        mSwitch = !mSwitch;
    }

    private void login() {
        mPhoneNumber = mPhoneNumberEditText.getText().toString().trim();
        mPassWord = mPassWordEditText.getText().toString().trim();
        LocalInfoManager.getInstance(this).setAccount(mPhoneNumber);
        SharePrefUtil.saveString(this, SharedPreferenceConfig.account, mPhoneNumber);
        if (!AccountLogic.isCellPhoneNumber(mPhoneNumber)) {
            Toast.makeText(this, "输入的手机号码格式错误", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!AccountLogic.isPasswordLegal(mPassWord)) {
            Toast.makeText(this, "输入的密码格式错误", Toast.LENGTH_SHORT).show();
            return;
        }

        if (0 == CommonUtil.isNetworkAvailable(this)) {
            Toast.makeText(this, "无网络链接，请检查网络", Toast.LENGTH_SHORT).show();
        } else {
            ILoginLoginResponse response = new ILoginLoginResponse(this);
            gatemsg.SLogin loginInfo = new gatemsg.SLogin();
            loginInfo.deviceCode = CommonUtil.getDeviceCode(this);
            loginInfo.account = mPhoneNumber;
            loginInfo.password = mPassWord;
            loginInfo.loginType = publicdef.ELoginType.MobilePhoneNum;
            RequestWS.getInstance().getILoginProxy().login(response, loginInfo);
        }
    }

    class ILoginLoginResponse extends ilogin.ILogin_login_response {
        private Context ct;

        public ILoginLoginResponse(Context context) {
            super();
            this.ct = context;
        }

        @Override
        public void onResponse(gatemsg.SLoginReturn loginRes) {
            LocalInfoManager.getInstance(LoginActivity.this).setNickName(loginRes.nickname);
            LocalInfoManager.getInstance(LoginActivity.this).setSessionKey(loginRes.sessionKey);
            LocalInfoManager.getInstance(LoginActivity.this).setUserId(loginRes.userId);
            LocalInfoManager.getInstance(LoginActivity.this).setAvatarUrl(loginRes.avatarUrl);
            LocalInfoManager.getInstance(LoginActivity.this).setBirthday(loginRes.birthday);
            LocalInfoManager.getInstance(LoginActivity.this).setGender(loginRes.gender);

            Intent intent = new Intent();
            setResult(RESULT_OK, intent);
            if (loginRes.sessionKey != null) {
                CommonUtil.IsLogined = true;
                Toast.makeText(LoginActivity.this, R.string.dialog_title_login_success, Toast.LENGTH_SHORT).show();
                finish();
            }

            LogUtils.LogD("tag", "login_success!");

        }

        @Override
        public void onError(String what, int code) {
            LogUtils.LogD("tag", what);
            Toast.makeText(LoginActivity.this, what, Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onTimeout() {
            LogUtils.LogD("tag", "onTimeout");
            Toast.makeText(LoginActivity.this, R.string.toast_time_out, Toast.LENGTH_SHORT).show();
        }

    }

}
