package com.guiyi.egui.customwidget.CustomEditText;

import android.content.Context;
import android.text.SpannableString;
import android.util.AttributeSet;
import android.widget.EditText;

import com.guiyi.egui.util.ExpressionUtil;

/**
 * Created by ForOne on 15/8/26.
 * EditText 能够输入识别表情
 */
public class CustomEditText extends EditText {

    private Context mContext;

    private boolean mIsExpressionReplace = false;

    private int mMatchCount = 0;


    public CustomEditText(Context context) {
        super(context);
        mContext = context;
        ReplaceExpression();
    }

    public CustomEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        ReplaceExpression();
    }

    public CustomEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        ReplaceExpression();
    }



    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        try {
            if(mContext != null){
                ReplaceExpression();
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    private void ReplaceExpression(){
        if(!mIsExpressionReplace){
            String text = getText().toString();
            ExpressionUtil.ExpressionResult expressionResult = ExpressionUtil.getInstance().getExpressionString(mContext, text);
            if(expressionResult.MatchCount > mMatchCount){
                mIsExpressionReplace = !mIsExpressionReplace;
                int index = getSelectionStart();
                setText(expressionResult.SpannableString);
                setSelection(index);
                mMatchCount = expressionResult.MatchCount;
            }

        }else{
            mIsExpressionReplace = !mIsExpressionReplace;
        }

    }
}
