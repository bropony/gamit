package com.guiyi.egui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.guiyi.egui.Managers.TopicTagsManager;
import com.guiyi.egui.R;
import com.guiyi.egui.activity.home.TopicsManageActivity;
import com.guiyi.egui.adapter.ContentViewPagerAdapter;
import com.guiyi.egui.customwidget.CategoryTabStrip;
import com.jenwis.android.base.ui.BaseFragment;


/**
 * Created by C on 2015/8/7.
 */
public class HomeFragment extends BaseFragment implements View.OnClickListener {
    private View mView;
    private ViewPager mAdvertViewPager;
    private ViewPager mContentViewPager;
    private TextView mMoreTextView;
    private CategoryTabStrip mCategoryTabStrip;

    ContentViewPagerAdapter mAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_home, container, false);
        super.onCreateView(inflater, container, savedInstanceState);
        return mView;
    }

    @Override
    public void init() {
    }


    @Override
    public void findView() {
        mAdvertViewPager = (ViewPager) mView.findViewById(R.id.advert_view_pager);
        mMoreTextView = (TextView) mView.findViewById(R.id.more_text_view);
        mContentViewPager = (ViewPager) mView.findViewById(R.id.content_view_pager);
        mCategoryTabStrip = (CategoryTabStrip) mView.findViewById(R.id.category_tab_strip);

    }

    @Override
    public void setView() {

    }


    @Override
    public void setViewListener() {
        mMoreTextView.setOnClickListener(this);
    }

    @Override
    public void onPageSelected() {

    }

    @Override
    public void onPageDisSelected() {

    }

    @Override
    public void onDataChange(int type, Object obj) {

    }

    @Override
    public void onResume() {
        super.onResume();
        Log.v("setView", "setView");
        mAdapter = new ContentViewPagerAdapter(getChildFragmentManager(), TopicTagsManager.getInstance(getActivity()).getSelectedTopicTags());
        mContentViewPager.setAdapter(mAdapter);
        mCategoryTabStrip.setViewPager(mContentViewPager);
        mContentViewPager.setCurrentItem(mCategoryTabStrip.getCurrPosition());
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.more_text_view:
                Intent intent = new Intent(getActivity(), TopicsManageActivity.class);
                startActivityForResult(intent, 1);
                break;
            default:
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


}
