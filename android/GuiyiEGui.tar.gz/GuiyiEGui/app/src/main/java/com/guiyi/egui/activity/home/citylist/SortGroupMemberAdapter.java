package com.guiyi.egui.activity.home.citylist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.SectionIndexer;
import android.widget.TextView;

import com.guiyi.egui.R;

import java.util.List;

public class SortGroupMemberAdapter extends BaseAdapter implements SectionIndexer {
	private List<GroupMemberBean> mList = null;
	private Context mContext;

	public SortGroupMemberAdapter(Context context, List<GroupMemberBean> list) {
		mContext = context;
		mList = list;
	}
	
	public void updateListView(List<GroupMemberBean> list) {
		mList = list;
		notifyDataSetChanged();
	}

	public int getCount() {
		return mList.size();
	}

	public Object getItem(int position) {
		return mList.get(position);
	}

	public long getItemId(int position) {

		return position;
	}

	public View getView(final int position, View view, ViewGroup arg2) {
		ViewHolder viewHolder = null;
		final GroupMemberBean mContent = mList.get(position);
		if (view == null) {
			viewHolder = new ViewHolder();
			view = LayoutInflater.from(mContext).inflate(R.layout.activity_group_member_item, null);
			viewHolder.titleTextView = (TextView) view.findViewById(R.id.title_text_view);
			viewHolder.letterTextView = (TextView) view.findViewById(R.id.catalog_text_view);
			view.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) view.getTag();
		}

		int section = getSectionForPosition(position);

		if (position == getPositionForSection(section)) {
			viewHolder.letterTextView.setVisibility(View.VISIBLE);
			viewHolder.letterTextView.setText(mContent.getSortLetters());
		} else {
			viewHolder.letterTextView.setVisibility(View.GONE);
		}

		viewHolder.titleTextView.setText(this.mList.get(position).getName());

		return view;

	}

	final static class ViewHolder {
		TextView letterTextView;
		TextView titleTextView;
	}


	public int getSectionForPosition(int position) {
		return mList.get(position).getSortLetters().charAt(0);
	}


	public int getPositionForSection(int section) {
		for (int i = 0; i < getCount(); i++) {
			String sortStr = mList.get(i).getSortLetters();
			char firstChar = sortStr.toUpperCase().charAt(0);
			if (firstChar == section) {
				return i;
			}
		}

		return -1;
	}

	@Override
	public Object[] getSections() {
		return null;
	}
}