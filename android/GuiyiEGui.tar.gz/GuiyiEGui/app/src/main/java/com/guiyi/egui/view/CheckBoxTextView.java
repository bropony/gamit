package com.guiyi.egui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.guiyi.egui.util.T;

/**
 * Created by rentianlong on 2015/9/10.9:21
 * <p/>
 * company GDGY
 */
public class CheckBoxTextView extends TextView implements View.OnClickListener {
    private boolean isChecked;
    private CheckStateListener listener;
    public CheckBoxTextView(Context context) {
        this(context, null);
    }

    public CheckBoxTextView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CheckBoxTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.CheckBoxTextView);
        isChecked = typedArray.getBoolean(R.styleable.CheckBoxTextView_checked, false);
        typedArray.recycle();
        init();
    }

    private void init() {
        if (isChecked) {
            setBackgroundResource(R.drawable.right_b);
        } else {
            setBackgroundResource(R.drawable.right_a);
        }
        setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        change();
    }

    private void change() {
        if (!isChecked) {
            setBackgroundResource(R.drawable.right_b);
            isChecked = true;
            if (listener != null) {
                listener.isChecked(this);
            }
        } else {
            setBackgroundResource(R.drawable.right_a);
            isChecked = false;
            if (listener != null) {
                listener.noChecked(this);
            }
        }
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean isChecked) {
        this.isChecked = isChecked;
        init();
    }

    public void setOnCheckedListener(CheckStateListener listener) {
        this.listener = listener;
    }

    public interface CheckStateListener {
        void isChecked(View view);
        void noChecked(View view);

    }
}
