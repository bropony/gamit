package com.guiyi.egui.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Created by ForOne on 15/8/20.
 */
public class ImageUtil {

    private static final int QUALITY = 100;

    public static byte[] BitmapToBytes(Bitmap bitmap){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, QUALITY, baos);
        return baos.toByteArray();
    }

    public static Bitmap BytesToBitmap(byte[] data){
        if(data.length!=0){
            return BitmapFactory.decodeByteArray(data, 0, data.length);
        }
        return null;
    }

   public static boolean saveBitmapToFile(Bitmap bitmap,String path){
        Bitmap.CompressFormat format= Bitmap.CompressFormat.JPEG;
        OutputStream stream = null;
        try {
            stream = new FileOutputStream(path);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return bitmap.compress(format, QUALITY, stream);
    }

    public static Bitmap compressImageFromFile(String srcPath,float compressWidth,float compressHeight) {

        BitmapFactory.Options newOpts = new BitmapFactory.Options();
        newOpts.inJustDecodeBounds = true;//只读边,不读内容
        Bitmap bitmap = BitmapFactory.decodeFile(srcPath, newOpts);

        newOpts.inJustDecodeBounds = false;
        int width = newOpts.outWidth;
        int height = newOpts.outHeight;

        int size = 1;
        if (width > height && width > compressWidth) {
            size = (int) (newOpts.outWidth / compressWidth);
        } else if (width < height && height > compressHeight) {
            size = (int) (newOpts.outHeight / compressHeight);
        }
        if (size <= 0){
            size = 1;
        }

        newOpts.inSampleSize = size;//设置采样率

        newOpts.inPreferredConfig = Bitmap.Config.ARGB_8888;//该模式是默认的,可不设
        newOpts.inPurgeable = true;// 同时设置才会有效
        newOpts.inInputShareable = true;//。当系统内存不够时候图片自动被回收

        bitmap = BitmapFactory.decodeFile(srcPath, newOpts);
        return bitmap;
    }
}
