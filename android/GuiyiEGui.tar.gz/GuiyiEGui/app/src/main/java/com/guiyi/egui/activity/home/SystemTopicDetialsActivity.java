package com.guiyi.egui.activity.home;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.IBinder;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Dialog.ExpressionDialog;
import com.guiyi.egui.Listener.GetSystemTopicByIdListener;
import com.guiyi.egui.Managers.SystemTopicManager;
import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.R;
import com.guiyi.egui.activity.common.ImagePreviewActivity;
import com.guiyi.egui.activity.personal.LoginActivity;
import com.guiyi.egui.adapter.HomeTopicCommentListViewAdapter;
import com.guiyi.egui.adapter.HomeTopicCommenterIconGridViewAdapter;
import com.guiyi.egui.adapter.HomeTopicPicGridViewAdapter;
import com.guiyi.egui.customwidget.CommentListView.CommentListView;
import com.guiyi.egui.customwidget.CustomEditText.CustomEditText;
import com.guiyi.egui.customwidget.CustomGrideView.CustomGrideView;
import com.guiyi.egui.customwidget.FitImageView;
import com.guiyi.egui.events.SystemTopicStatusChangedEvent;
import com.guiyi.egui.util.CommonUtil;
import com.guiyi.egui.util.DateUtil;
import com.guiyi.egui.util.ImageLoaderUtil;
import com.guiyi.egui.websocket.RequestWS;
import com.jenwis.android.base.ui.BaseActivity;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import de.greenrobot.event.EventBus;
import message.common.publicdef;
import message.gate.gatemsg;
import message.gate.ipostoper;



/**
 * Created by ForOne on 15/9/3.
 */
public class SystemTopicDetialsActivity extends BaseActivity implements View.OnClickListener {

    public static String SYSTEM_TOPIC_ID = "com.guiyi.egui.systemtopicid";

    private int mLoginRequestCode = 2;

    private boolean mIsVoteup;

    private gatemsg.SSysTopic mSystemTopic;

    private ArrayList<gatemsg.SComment> mCommentList = new ArrayList<>();
    private Date mLastestCommentDate = new Date();

    private ArrayList<String> mUpvoteList = new ArrayList<>();

    private TextView mBackTextView;
    private TextView mTitleTextView;

    private TextView mVisitCountTextView;
    private TextView mTopicNameTextView;
    private TextView mTopicTitleTextView;
    private ImageView mFollowImageView;
    private TextView mPublishTimeTextView;
    private TextView mTopicContentTextView;
    private CustomGrideView mUserIconImageView;
    private TextView mShareTextView;
    private TextView mCommentTextView;
    private TextView mUpvoteTextView;
    private CommentListView mCommentListView;
    private TextView mCommitCommentsTextView;
    private CustomEditText mCommentEditText;
    private ImageView mExpressionImageView;
    private TextView mCommentCountTextView;
    private HomeTopicCommenterIconGridViewAdapter mAdapter;
    private FitImageView image1;
    private FitImageView image2;
    private FitImageView image3;
    private FitImageView image4;
    private FitImageView image5;
    private FitImageView image6;
    private FitImageView image7;
    private FitImageView image8;
    private FitImageView image9;
    private ArrayList<String> imageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_home_topic_detail);
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        //TODO 获取TopicId
        String topicId = intent.getStringExtra(SYSTEM_TOPIC_ID);
        SystemTopicManager.getInstance(this).getSystemTopicById(topicId, this, new GetSystemTopicByIdListener() {

            @Override
            public void success(gatemsg.SSysTopic systemTopic) {
                mSystemTopic = systemTopic;
                initSystemTopic();
            }

            @Override
            public void failed(String message) {

            }
        });
        mAdapter = new HomeTopicCommenterIconGridViewAdapter(this, mUpvoteList);
        mUserIconImageView.setAdapter(mAdapter);
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mBackTextView= (TextView) findViewById(R.id.back_tv);
        mTitleTextView= (TextView) findViewById(R.id.title_tv);
        mTopicNameTextView = (TextView)findViewById(R.id.topic_name_text_view);
        mTopicTitleTextView = (TextView)findViewById(R.id.topic_title_text_view);
        mFollowImageView = (ImageView)findViewById(R.id.follow_image_view);
        mPublishTimeTextView = (TextView)findViewById(R.id.publish_time_text_view);
        mTopicContentTextView = (TextView)findViewById(R.id.topic_content_text_view);
        mShareTextView = (TextView)findViewById(R.id.share_num_text_view);
        mCommentTextView = (TextView)findViewById(R.id.comment_num_text_view);
        mUpvoteTextView = (TextView)findViewById(R.id.upvote_text_view);
        mCommentListView = (CommentListView)findViewById(R.id.topic_comment_list_view);
        mCommitCommentsTextView = (TextView)findViewById(R.id.enter_text_view);
        mCommentEditText = (CustomEditText)findViewById(R.id.comment_edit_text);
        mVisitCountTextView = (TextView)findViewById(R.id.visit_times_text_view);
        mUserIconImageView= (CustomGrideView) findViewById(R.id.comment_person_icon_gridview);
        mExpressionImageView= (ImageView) findViewById(R.id.expression_image_view);
        mCommentCountTextView = (TextView)findViewById(R.id.comment_times_text_view);
        image1= (FitImageView) findViewById(R.id.home_topic_detail_pic_image_view1);
        image2= (FitImageView) findViewById(R.id.home_topic_detail_pic_image_view2);
        image3= (FitImageView) findViewById(R.id.home_topic_detail_pic_image_view3);
        image4= (FitImageView) findViewById(R.id.home_topic_detail_pic_image_view4);
        image5= (FitImageView) findViewById(R.id.home_topic_detail_pic_image_view5);
        image6= (FitImageView) findViewById(R.id.home_topic_detail_pic_image_view6);
        image7= (FitImageView) findViewById(R.id.home_topic_detail_pic_image_view7);
        image8= (FitImageView) findViewById(R.id.home_topic_detail_pic_image_view8);
        image9= (FitImageView) findViewById(R.id.home_topic_detail_pic_image_view9);

    }

    @Override
    public void setView() {
        mTitleTextView.setText("话题详情");
        //跳转到该详情页面的时候不是从顶部开始显示，通过顶部的控件获取焦点来实现从顶部开始显示
        mTopicTitleTextView.setFocusable(true);
        mTopicTitleTextView.setFocusableInTouchMode(true);
        mTopicTitleTextView.requestFocus();
    }

    @Override
    public void setViewListener() {
        mExpressionImageView.setOnClickListener(this);
        mUpvoteTextView.setOnClickListener(this);
        mCommentTextView.setOnClickListener(this);
        mShareTextView.setOnClickListener(this);
        mFollowImageView.setOnClickListener(this);
        mBackTextView.setOnClickListener(this);
        mCommitCommentsTextView.setOnClickListener(this);
        image1.setOnClickListener(this);
        image2.setOnClickListener(this);
        image3.setOnClickListener(this);
        image4.setOnClickListener(this);
        image5.setOnClickListener(this);
        image6.setOnClickListener(this);
        image7.setOnClickListener(this);
        image8.setOnClickListener(this);
        image9.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back_tv:
                finish();
                break;
            case R.id.follow_image_view:
                followOrNot();
                break;

            case R.id.comment_num_text_view:

                break;

            case R.id.share_num_text_view:
                if(!CommonUtil.IsLogined){
                    login();
                }else {
                    share();
                }
                break;

            case R.id.upvote_text_view:
                if(!CommonUtil.IsLogined){
                    login();
                }else {
                    upvoteOrNot();
                }
                break;

            case R.id.enter_text_view:
                if(!CommonUtil.IsLogined){
                    login();
                    hideSoftInput(getCurrentFocus().getWindowToken());
                }else {
                    String content =  mCommentEditText.getText().toString();
                    commitSystemTopicComments(content);
                    hideSoftInput(getCurrentFocus().getWindowToken());
                }
                break;
            case R.id.expression_image_view:
                addExpression();
                break;
            case R.id.home_topic_detail_pic_image_view1:
                imageViewSetOnclickListener(0);
                break;
            case R.id.home_topic_detail_pic_image_view2:
                imageViewSetOnclickListener(1);
                break;
            case R.id.home_topic_detail_pic_image_view3:
                imageViewSetOnclickListener(2);
                break;
            case R.id.home_topic_detail_pic_image_view4:
                imageViewSetOnclickListener(3);
                break;
            case R.id.home_topic_detail_pic_image_view5:
                imageViewSetOnclickListener(4);
                break;
            case R.id.home_topic_detail_pic_image_view6:
                imageViewSetOnclickListener(5);
                break;
            case R.id.home_topic_detail_pic_image_view7:
                imageViewSetOnclickListener(6);
                break;
            case R.id.home_topic_detail_pic_image_view8:
                imageViewSetOnclickListener(7);
                break;
            case R.id.home_topic_detail_pic_image_view9:
                imageViewSetOnclickListener(8);
                break;

        }
    }
    private void imageViewSetOnclickListener(int position){
        Intent intent = new Intent(SystemTopicDetialsActivity.this,ImagePreviewActivity.class);
        intent.putStringArrayListExtra(ImagePreviewActivity.IMAGE_PREVIEW_URL, imageList);
        intent.putExtra(ImagePreviewActivity.IMAGE_PREVIEW_INDEX, position);
        startActivity(intent);
    }
    ExpressionDialog.ExpressionDialogListener addExpressionCallback = new ExpressionDialog.ExpressionDialogListener() {
        @Override
        public void result(String value) {
            String text = mCommentEditText.getText().toString();
            mCommentEditText.setText(text + value);
        }
    };

    private void addExpression(){
        ExpressionDialog dialog = new ExpressionDialog(this,addExpressionCallback);
    }

    private void initSystemTopic(){
        if(mSystemTopic == null){
            return;
        }
        visitSystemTopic();
        querySystemTopicUpvoteStatus();
        getUpvoteList();
        getSystemTopicComments();
        mTopicContentTextView.setText(mSystemTopic.content);
        mTopicNameTextView.setText("美食");
        mTopicTitleTextView.setText(mSystemTopic.title);
        mPublishTimeTextView.setText(DateUtil.getDateIntervelTimeStringToNow(mSystemTopic.createDt));
        mCommentTextView.setText(mSystemTopic.commentedTimes + "");
        mCommentCountTextView.setText(mSystemTopic.commentedTimes + "");
        mUpvoteTextView.setText(mSystemTopic.upvotedTimes + "");
        mShareTextView.setText(mSystemTopic.sharedTimes + "");
        mVisitCountTextView.setText(mSystemTopic.viewTimes + "");
        setGridViewImages(mSystemTopic);
    }

    private gatemsg.SComment isContainComment(gatemsg.SComment comment){
        for (gatemsg.SComment scomment:mCommentList
             ) {
            if(comment.commentId.equals(scomment.commentId)){
                return scomment;
            }
        }
        return null;
    }

    private void getCommentsListSuccess(gatemsg.SeqComment commentList){
        if(!commentList.isEmpty()){
            for (int i = 0; i < commentList.getSize(); i ++){
                gatemsg.SComment comment = isContainComment(commentList.getArray()[i]);
                if(comment != null){
                    mCommentList.remove(comment);
                }
                mCommentList.add(commentList.getArray()[i]);
            }
        }
        if(commentList.getSize() != 0){
            mLastestCommentDate = commentList.getArray()[commentList.getSize() - 1].commentDt;
        }
        refreshCommentsUI();
    }

    private void setGridViewImages(gatemsg.SSysTopic systemTopic){
        //下载图片
        final gatemsg.SImageInfo[] imageInfos = systemTopic.images.getArray();
        if(imageInfos != null && imageInfos.length > 0){
            final ArrayList<String> thumbnaolImageList = new ArrayList<String>();
            imageList = new ArrayList<>();
            for (gatemsg.SImageInfo imageInfo:imageInfos) {
                thumbnaolImageList.add(imageInfo.formatedDownloadUrl);
                imageList.add(imageInfo.token);
            }
            int count=0;
            for (int a=0;a<imageList.size();a++){

                switch (count){
                    case 0:
                        ImageLoaderUtil.displayImage(imageList.get(a),image1);
                        image1.setVisibility(View.VISIBLE);
                        break;
                    case 1:
                        ImageLoaderUtil.displayImage(imageList.get(a),image2);
                        image2.setVisibility(View.VISIBLE);
                        break;
                    case 2:
                        ImageLoaderUtil.displayImage(imageList.get(a), image3);
                        image3.setVisibility(View.VISIBLE);
                        break;
                    case 3:
                        ImageLoaderUtil.displayImage(imageList.get(a),image4);
                        image4.setVisibility(View.VISIBLE);
                        break;
                    case 4:
                        ImageLoaderUtil.displayImage(imageList.get(a),image5);
                        image4.setVisibility(View.VISIBLE);
                        break;
                    case 5:
                        ImageLoaderUtil.displayImage(imageList.get(a),image6);
                        image6.setVisibility(View.VISIBLE);
                        break;
                    case 6:
                        ImageLoaderUtil.displayImage(imageList.get(a),image7);
                        image7.setVisibility(View.VISIBLE);
                        break;
                    case 7:
                        ImageLoaderUtil.displayImage(imageList.get(a),image8);
                        image8.setVisibility(View.VISIBLE);
                        break;
                    case 8:
                        ImageLoaderUtil.displayImage(imageList.get(a),image9);
                        image9.setVisibility(View.VISIBLE);
                        break;
                }
                count++;
                if(count==imageList.size()){
                    break;
                }
            }
        }
    }

    private void refreshCommentsUI(){
        HomeTopicCommentListViewAdapter commentListViewAdapter = new HomeTopicCommentListViewAdapter(this,mCommentList);
        mCommentListView.setDividerHeight(1);
        mCommentListView.setAdapter(commentListViewAdapter);
    }

    private void followOrNot(){
//        Toast.makeText(this, "关注，oh no！敬请期待！", Toast.LENGTH_SHORT).show();
        //notifySystemTopicStatus();
    }

    private void share(){
       Toast.makeText(this, "分享功能暂未实现！", Toast.LENGTH_SHORT).show();
        //notifySystemTopicStatus();
    }

    private void getUpvoteList(){
        int type = publicdef.EInteractiveType.Upvote;
        GetSystemTopicCommentsResponse response = new GetSystemTopicCommentsResponse(type);
        RequestWS.getInstance().getPostOperProxy().getSysTopicComments(response, CommonUtil.getDeviceCode(this), mSystemTopic.topicId, type, mLastestCommentDate, 20);
    }

    private void getUpvoteListSuccess(gatemsg.SeqComment upvoteList){

        for (gatemsg.SComment sComment : upvoteList.getArray()) {
            String avatarUrl = sComment.commenterInfo.avatarUrl;
            if(!mUpvoteList.contains(avatarUrl)){
                mUpvoteList.add(sComment.commenterInfo.avatarUrl);
            }
        }
        mAdapter.setImageList(mUpvoteList);
        mAdapter.notifyDataSetChanged();
    }


    private void commitCommentsSuccess(String newCommentId,String comments){
        Toast.makeText(this, "话题评论成功!", Toast.LENGTH_SHORT).show();
        gatemsg.SComment sComment = new gatemsg.SComment();
        gatemsg.SUserBrief user = new gatemsg.SUserBrief();
        user.userId = LocalInfoManager.getInstance(this).getUserId();
        user.nickname = LocalInfoManager.getInstance(this).getNickName();
        user.avatarUrl = LocalInfoManager.getInstance(this).getAvatarUrl();
        sComment.commentId = newCommentId;
        sComment.comment = comments;
        sComment.commentDt = new Date();
        sComment.commenterInfo = user;
        gatemsg.SComment comment = isContainComment(sComment);
        if(comment != null){
            mCommentList.remove(comment);
        }
        mCommentList.add(sComment);
        mSystemTopic.commentedTimes ++;
        mCommentTextView.setText(mSystemTopic.commentedTimes + "");
        mCommentCountTextView.setText(mSystemTopic.commentedTimes + "");
        refreshCommentsUI();

        mCommentEditText.setText("");

        notifySystemTopicStatus();

    }



    private void commitCommentsFailed(String message){
        Toast.makeText(this, "话题评论失败：" + message, Toast.LENGTH_SHORT).show();
    }

    private void commitSystemTopicComments(final String comments){

        ipostoper.IPostOper_commentSysTopic_response responser = new ipostoper.IPostOper_commentSysTopic_response(){
            @Override
            public void onResponse(String newCommentId) {
                commitCommentsSuccess(newCommentId,comments);
            }

            @Override
            public void onError(String what, int code) {
                commitCommentsFailed("Code:" + code + " what:" + what);
            }

            @Override
            public void onTimeout() {
                commitCommentsFailed("TimeOut");
            }
        };
        RequestWS.getInstance().getPostOperProxy().commentSysTopic(responser, LocalInfoManager.getInstance(this).getSessionKey(), mSystemTopic.topicId, comments);
    }

    private void querySystemTopicUpvoteStatus(){
        ipostoper.IPostOper_querySysTopicUpvoteStatus_response  querySystemTopicUpvoteStatusResponse = new ipostoper.IPostOper_querySysTopicUpvoteStatus_response() {
            @Override
            public void onResponse(publicdef.DictStringBool postUpvatedStatusDict) {
                HashMap<String, Boolean> map = postUpvatedStatusDict.getMap();
                if(map.containsKey(mSystemTopic.topicId)){
                    mIsVoteup =  map.get(mSystemTopic.topicId);
                   updateUpvoteImage();
                }
            }

            @Override
            public void onError(String what, int code) {

            }

            @Override
            public void onTimeout() {

            }
        };
        String[] topicId = new String[1];
        topicId[0] = mSystemTopic.topicId;
        publicdef.SeqString topicIdList = new publicdef.SeqString(topicId);
        RequestWS.getInstance().getPostOperProxy().querySysTopicUpvoteStatus(querySystemTopicUpvoteStatusResponse, LocalInfoManager.getInstance(this).getSessionKey(), topicIdList);
    }

    private void visitSystemTopic(){
        ipostoper.IPostOper_viewSysTopic_response  viewSystemtopicResponse = new ipostoper.IPostOper_viewSysTopic_response() {
            @Override
            public void onResponse(int totalViewTimes) {
               mVisitCountTextView.setText(totalViewTimes + "");
            }

            @Override
            public void onError(String what, int code) {

            }

            @Override
            public void onTimeout() {

            }
        };
        RequestWS.getInstance().getPostOperProxy().viewSysTopic(viewSystemtopicResponse, CommonUtil.getDeviceCode(this), mSystemTopic.topicId);
    }


    private void updateUpvoteImage(){
        Drawable drawable = mIsVoteup ? getResources().getDrawable(R.drawable.upvote):getResources().getDrawable(R.drawable.unupvote);
        drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
        mUpvoteTextView.setCompoundDrawables(drawable, null, null, null);
    }

    private void upvoteSuccess(){
        mIsVoteup = true;
        mSystemTopic.upvotedTimes ++;
        updateUpvoteImage();
        mUpvoteTextView.setText(mSystemTopic.upvotedTimes + "");
        notifySystemTopicStatus();
        if(mUpvoteList.contains(LocalInfoManager.getInstance(this).getAvatarUrl())){
            mUpvoteList.add(LocalInfoManager.getInstance(this).getAvatarUrl());
            mAdapter.setImageList(mUpvoteList);
            mAdapter.notifyDataSetChanged();
        }
        Toast.makeText(this, "点赞成功!", Toast.LENGTH_SHORT).show();
    }

    private void upvoteFailed(String error){
        Toast.makeText(this, "点赞失败：" + error, Toast.LENGTH_SHORT).show();
    }

    private void unupvoteFailed(String error){
        Toast.makeText(this, "取消点赞失败：" + error, Toast.LENGTH_SHORT).show();
    }

    private void unupvoteSuccess(){
        mIsVoteup = false;
        mSystemTopic.upvotedTimes --;
        updateUpvoteImage();
        mUpvoteTextView.setText(mSystemTopic.upvotedTimes + "");
        notifySystemTopicStatus();
        Toast.makeText(this, "取消点赞成功!", Toast.LENGTH_SHORT).show();
    }

    private void upvoteOrNot(){

        if(mIsVoteup){
            UnupvoteSystemTopicsResponse unupvoteSystemTopicsResponse = new UnupvoteSystemTopicsResponse();
            RequestWS.getInstance().getPostOperProxy().unupvoteSysTopic(unupvoteSystemTopicsResponse, LocalInfoManager.getInstance(this).getSessionKey(), mSystemTopic.topicId);
        }else{
            UpvoteSystemTopicResponse upvoteSystemTopicsResponse = new UpvoteSystemTopicResponse();
            RequestWS.getInstance().getPostOperProxy().upvoteSysTopic(upvoteSystemTopicsResponse, LocalInfoManager.getInstance(this).getSessionKey(), mSystemTopic.topicId);
        }
    }


    private void getSystemTopicComments(){
        int type = publicdef.EInteractiveType.Comment;
        GetSystemTopicCommentsResponse response = new GetSystemTopicCommentsResponse(type);
        RequestWS.getInstance().getPostOperProxy().getSysTopicComments(response, CommonUtil.getDeviceCode(this), mSystemTopic.topicId,type,mLastestCommentDate, 20);
    }

    private void notifySystemTopicStatus(){
        SystemTopicStatusChangedEvent systemTopicStatusChangedEvent = new SystemTopicStatusChangedEvent();
        systemTopicStatusChangedEvent.SystemTopicId = mSystemTopic.topicId;
        systemTopicStatusChangedEvent.CommentCount = mSystemTopic.commentedTimes;
        systemTopicStatusChangedEvent.ShareCount = mSystemTopic.sharedTimes;
        systemTopicStatusChangedEvent.UpvoteCount = mSystemTopic.upvotedTimes;
        systemTopicStatusChangedEvent.VisitCount = mSystemTopic.viewTimes;
        EventBus.getDefault().post(systemTopicStatusChangedEvent);
    }

    private void login(){
        Intent intent=new Intent(SystemTopicDetialsActivity.this,LoginActivity.class);
        startActivityForResult(intent, mLoginRequestCode);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
      if(requestCode == mLoginRequestCode && resultCode == RESULT_OK){
          querySystemTopicUpvoteStatus();
        }
    }

    class GetSystemTopicCommentsResponse extends ipostoper.IPostOper_getSysTopicComments_response {

        private int mInteractiveType;

        public GetSystemTopicCommentsResponse(int type){
            mInteractiveType = type;
        }

        @Override
        public void onResponse(gatemsg.SeqComment commentList) {
            if(mInteractiveType == publicdef.EInteractiveType.Comment){
                getCommentsListSuccess(commentList);
            }else{
                getUpvoteListSuccess(commentList);
            }
        }

        @Override
        public void onError(String what, int code) {

        }

        @Override
        public void onTimeout() {

        }
    }

    public class UnupvoteSystemTopicsResponse extends ipostoper.IPostOper_unupvoteSysTopic_response {

        @Override
        public void onResponse() {
            unupvoteSuccess();
        }

        @Override
        public void onError(String what, int code) {
            unupvoteFailed("Code:" + code + " what:" + what);
        }

        @Override
        public void onTimeout() {
            upvoteFailed("TimeOut");
        }
    }

    public class UpvoteSystemTopicResponse extends ipostoper.IPostOper_upvoteSysTopic_response {

        @Override
        public void onResponse() {
            upvoteSuccess();
        }

        @Override
        public void onError(String what, int code) {
            upvoteFailed("Code:" + code + " what:" + what);
        }

        @Override
        public void onTimeout() {
            upvoteFailed("TimeOut");
        }
    }
    //基类中重写了 键盘隐藏失效 在该类中重写设置
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {

            // 获得当前得到焦点的View，一般情况下就是EditText（特殊情况就是轨迹求或者实体案件会移动焦点）
            View v = getCurrentFocus();

            if (isShouldHideInput(v, ev)) {
                hideSoftInput(v.getWindowToken());
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    /**
     * 根据EditText所在坐标和用户点击的坐标相对比，来判断是否隐藏键盘，因为当用户点击EditText时没必要隐藏
     *
     * @param v
     * @param event
     * @return
     */
    private boolean isShouldHideInput(View v, MotionEvent event) {
        if (v != null && (v instanceof EditText)) {
            int[] l = { 0, 0 };
            v.getLocationInWindow(l);
            int left = l[0], top = l[1], bottom = top + v.getHeight(), right = left
                    + v.getWidth();
            if (event.getX() > left && event.getX() < right
                    && event.getY() > top && event.getY() < bottom) {
                // 点击EditText的事件，忽略它。
                return false;
            } else {
                return true;
            }
        }
        // 如果焦点不是EditText则忽略，这个发生在视图刚绘制完，第一个焦点不在EditView上，和用户用轨迹球选择其他的焦点
        return false;
    }

    /**
     * 多种隐藏软件盘方法
     *
     * @param token
     */
    private void hideSoftInput(IBinder token) {
        if (token != null) {
            InputMethodManager im = (InputMethodManager) getSystemService(this.INPUT_METHOD_SERVICE);
            im.hideSoftInputFromWindow(token,
                    InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }
}
