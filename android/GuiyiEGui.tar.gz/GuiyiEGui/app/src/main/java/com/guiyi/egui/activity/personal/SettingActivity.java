package com.guiyi.egui.activity.personal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.guiyi.egui.logic.config.SharedPreferenceConfig;
import com.guiyi.egui.util.CommonUtil;
import com.guiyi.egui.util.SharePrefUtil;
import com.jenwis.android.base.ui.BaseActionBarActivity;


/**
 * Created by Administrator on 2015/8/16.
 */
public class SettingActivity extends BaseActionBarActivity implements View.OnClickListener{
    private TextView mBack;
    private TextView mTitle;
    private TextView mExitTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_setting);
        super.onCreate(savedInstanceState);


    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mTitle = (TextView) findViewById(R.id.title_tv);

        mBack = (TextView) findViewById(R.id.back_tv);
        mExitTextView= (TextView) findViewById(R.id.exit_text_view);

    }

    @Override
    public void setView() {
        mTitle.setText("我的设置");
    }

    @Override
    public void setViewListener() {
        mBack.setOnClickListener(this);
        mExitTextView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_tv:
                finish();
                break;
            case R.id.exit_text_view:
                exit();
                break;
            default:
                break;
        }
    }

    private void exit() {
        SharePrefUtil.saveString(this, SharedPreferenceConfig.sessionKey,"");
        SharePrefUtil.saveString(this, SharedPreferenceConfig.nickName,"");
        SharePrefUtil.saveString(this, SharedPreferenceConfig.userId,"");
        SharePrefUtil.saveString(this, SharedPreferenceConfig.avatarUrl,"");
        SharePrefUtil.saveInt(this, SharedPreferenceConfig.gender, 0);
        SharePrefUtil.saveString(this, SharedPreferenceConfig.birthday, "");
        SharePrefUtil.saveString(this,SharedPreferenceConfig.account,"");
        Intent intent = new Intent(this,LoginActivity.class);
        startActivity(intent);
        CommonUtil.IsLogined=false;
        finish();

    }
}
