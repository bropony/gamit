package com.guiyi.egui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.guiyi.egui.R;


/**
 * Created by rentianlong on 2015/9/11.14:07
 * <p/>
 * company GDGY
 */
public class OrangeTextView extends TextView implements View.OnClickListener {
    private boolean isSelected;
    private SelectStateListener listener;

    public OrangeTextView(Context context) {
        this(context, null);
    }

    public OrangeTextView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public OrangeTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.OrangeTextView);
        isSelected = typedArray.getBoolean(R.styleable.CheckBoxTextView_checked, false);
        typedArray.recycle();
        init();

    }

    private void init() {
        if (!isSelected) {
            setBackgroundResource(R.color.white);
            setTextColor(Color.BLACK);
        } else {
            setBackgroundResource(R.color.orange);
            setTextColor(Color.WHITE);
        }
        setOnClickListener(this);
    }

    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
        change();
    }

    @Override
    public boolean isSelected() {
        return isSelected;
    }

    private void change() {
        if (!isSelected) {
            setBackgroundResource(R.color.orange);
            setTextColor(Color.WHITE);
            isSelected = true;
            if (listener != null) {
                listener.isSelected(this);
            }
        } else {
            setBackgroundResource(R.color.white);
            setTextColor(Color.BLACK);
            isSelected = false;
            if (listener != null) {
                listener.noSelected(this);
            }
        }
    }

    @Override
    public void onClick(View v) {
        change();
    }

    public interface SelectStateListener {
        void isSelected(View view);
        void noSelected(View view);
    }

    public void setSelectedStateListener(SelectStateListener listener) {
        this.listener = listener;
    }
}
