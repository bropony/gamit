package com.guiyi.egui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.guiyi.egui.R;
import com.guiyi.egui.util.ImageLoaderUtil;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/9/6.
 */
public class HomeTopicCommenterIconGridViewAdapter extends BaseAdapter{
    private Context mContext;
    private LayoutInflater mInflater;
    private ArrayList<String> mImageList = new ArrayList<>();

    public HomeTopicCommenterIconGridViewAdapter(Context context, ArrayList<String> imageList) {
        mContext=context;
        mInflater = LayoutInflater.from(context);
        mImageList = imageList;
    }

    public void setImageList(ArrayList<String> imageList){
        mImageList = imageList;
    }

    @Override
    public int getCount() {
        return mImageList.size();
    }

    @Override
    public Object getItem(int position) {
        return mImageList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.item_commenter_icon_grid_view,null);
        }
        imageView = (ImageView) convertView.findViewById(R.id.commenter_icon_image_view);
        ImageLoaderUtil.displayImage(mImageList.get(position), imageView);

        return convertView;
    }

}
