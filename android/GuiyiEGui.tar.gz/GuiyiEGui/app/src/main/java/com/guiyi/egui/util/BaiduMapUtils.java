package com.guiyi.egui.util;

import android.content.Context;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;

/**
 * Created by ForOne on 15/9/1.
 */
public class BaiduMapUtils {
    private LocationClient mLocationClient;
    private MyLocationListener mMyLocationListener;

    private LocationChangedListener mLocationChangedListener;
    private static BaiduMapUtils mBaiduMapUtils;

    private static final int BAIDU_MAP_REQUEST_INTERVAL = 3000;

    public static BaiduMapUtils getInstance(Context context){
        if(mBaiduMapUtils == null){
            mBaiduMapUtils = new BaiduMapUtils(context);
        }
        return mBaiduMapUtils;
    }

    private BaiduMapUtils(Context context) {
        mLocationClient = new LocationClient(context);
        mMyLocationListener = new MyLocationListener();
        mLocationClient.registerLocationListener(mMyLocationListener);
        initLocation();

    }

    public void start(){
        if(!mLocationClient.isStarted()){
            mLocationClient.start();
        }
    }

    public void setLocationChangedListener(LocationChangedListener locationChangedListener){
        mLocationChangedListener = locationChangedListener;
    }


    public  void stop(){
        if(mLocationClient.isStarted()){
            mLocationClient.stop();
        }
        mLocationChangedListener = null;
    }
    /**
     * 实现实时位置回调监听
     */
    public class MyLocationListener implements BDLocationListener {

        @Override
        public void onReceiveLocation(BDLocation location) {
            if(mLocationChangedListener == null){
                return;
            }
            String cityName = "";
            String cityCode = "";
            if (location.getLocType() == BDLocation.TypeGpsLocation ||
                    location.getLocType() == BDLocation.TypeNetWorkLocation ||
                    location.getLocType() == BDLocation.TypeOffLineLocation ){// GPS、网络与离线定位结果
                cityName = location.getCity();
                cityCode = location.getCityCode();
                mLocationChangedListener.locationChanged(cityName,cityCode);

            } else if (location.getLocType() == BDLocation.TypeServerError ||
                    location.getLocType() == BDLocation.TypeNetWorkException ||
                    location.getLocType() == BDLocation.TypeCriteriaException) {//定位失败
                mLocationChangedListener.locationFailed(location.getLocType());
            }
        }
    }

    private void initLocation(){
        LocationClientOption option = new LocationClientOption();
        option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy);//可选，默认高精度，设置定位模式，高精度，低功耗，仅设备
        option.setCoorType("gcj02");//可选，默认gcj02，设置返回的定位结果坐标系，bd09ll,bd09
        option.setScanSpan(BAIDU_MAP_REQUEST_INTERVAL);//可选，默认0，即仅定位一次，设置发起定位请求的间隔需要大于等于1000ms才是有效的
        option.setIsNeedAddress(true);//可选，设置是否需要地址信息，默认不需要
        option.setOpenGps(true);//可选，默认false,设置是否使用gps
        option.setLocationNotify(true);//可选，默认false，设置是否当gps有效时按照1S1次频率输出GPS结果
        option.setIgnoreKillProcess(true);//可选，默认true，定位SDK内部是一个SERVICE，并放到了独立进程，设置是否在stop的时候杀死这个进程，默认不杀死
        option.setEnableSimulateGps(false);//可选，默认false，设置是否需要过滤gps仿真结果，默认需要
        option.setIsNeedLocationDescribe(true);//可选，默认false，设置是否需要位置语义化结果，可以在BDLocation.getLocationDescribe里得到，结果类似于“在北京天安门附近”
        option.setIsNeedLocationPoiList(true);//可选，默认false，设置是否需要POI结果，可以在BDLocation.getPoiList里得到
        mLocationClient.setLocOption(option);
    }

    public interface LocationChangedListener{
        void locationChanged(String city, String cityCode);
        void locationFailed(int errorCode);
    }

}
