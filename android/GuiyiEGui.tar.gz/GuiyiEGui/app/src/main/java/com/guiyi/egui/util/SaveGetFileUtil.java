package com.guiyi.egui.util;

import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;
import java.io.StreamCorruptedException;
import java.util.ArrayList;

/**
 * Created by Administrator on 2015/9/4.
 */
public class SaveGetFileUtil {
    public static void saveFile(ArrayList list,File filesDir,String fileName){
         File sdCardDir = Environment.getExternalStorageDirectory();//获取SDCard目录
            File sdFile = new File(filesDir, fileName);


            try {
                FileOutputStream fos = new FileOutputStream(sdFile);
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                oos.writeObject(list);// 写入
                fos.close(); // 关闭输出流
            } catch (FileNotFoundException e) {

                e.printStackTrace();
            } catch (IOException e) {

                e.printStackTrace();
            }
    }
    
    public static ArrayList getFile(File filesDir,String fileName) {
        ArrayList list = null;
        File sdFile = new File(filesDir, fileName);

        try {
            FileInputStream fis=new FileInputStream(sdFile);   //获得输入流
            ObjectInputStream ois = new ObjectInputStream(fis);
            list = (ArrayList)ois.readObject();
            ois.close();
        } catch (StreamCorruptedException e) {

            e.printStackTrace();
        } catch (OptionalDataException e) {

            e.printStackTrace();
        } catch (FileNotFoundException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        } catch (ClassNotFoundException e) {

            e.printStackTrace();
        }
        return list;
    }
}
