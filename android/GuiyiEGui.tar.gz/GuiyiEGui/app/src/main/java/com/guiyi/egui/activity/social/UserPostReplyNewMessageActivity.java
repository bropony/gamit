package com.guiyi.egui.activity.social;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.R;
import com.jenwis.android.base.ui.BaseActionBarActivity;

/**
 * Created by Administrator on 2015/8/25.
 */
public class UserPostReplyNewMessageActivity extends BaseActionBarActivity implements View.OnClickListener{
    private TextView mBackTextView;
    private TextView mTitleTextView;
    private TextView mNoticeNumTextView;
    private TextView mCommentNumTextView;
    private RelativeLayout mNoticeRelativeLayout;
    private RelativeLayout mCommentRelativeLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_topic_reply_message);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mBackTextView= (TextView) findViewById(R.id.back_tv);
        mTitleTextView= (TextView) findViewById(R.id.title_tv);
        mNoticeNumTextView= (TextView) findViewById(R.id.notice_num_text_view);
        mCommentNumTextView= (TextView) findViewById(R.id.comment_num_text_view);
        mNoticeRelativeLayout= (RelativeLayout) findViewById(R.id.notice_relative_layout);
        mCommentRelativeLayout= (RelativeLayout) findViewById(R.id.comment_commend_relative_layout);
    }



    @Override
    public void setView() {
        mTitleTextView.setText(R.string.action_bar_title_message);
        mNoticeRelativeLayout.setOnClickListener(this);
        mCommentRelativeLayout.setOnClickListener(this);
        //TODO 通知、评论和点赞 有消息的时候 mNoticeNumTextView/mCommentNumTextView 两个控件visible；并设置textview的文字信息
    }

    @Override
    public void setViewListener() {
        mBackTextView.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back_tv:
                finish();
                break;
            case R.id.notice_relative_layout:
                //TODO 跳转系统通知中心 ui缺
                Toast.makeText(this,"待完成",Toast.LENGTH_SHORT).show();
                break;
            case R.id.comment_commend_relative_layout:
                Intent intent = new Intent(this, CommentAndCommendActivity.class);
                //是否传递参数待定
                startActivity(intent);
                break;
        }
    }
}
