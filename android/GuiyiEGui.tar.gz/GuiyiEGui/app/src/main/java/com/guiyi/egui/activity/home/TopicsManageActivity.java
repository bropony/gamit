package com.guiyi.egui.activity.home;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Managers.TopicTagsManager;
import com.guiyi.egui.R;
import com.guiyi.egui.adapter.MyDragGridViewAdapter;
import com.guiyi.egui.bean.TopicTag;
import com.guiyi.egui.customwidget.CustomGrideView.DragGridView;
import com.jenwis.android.base.ui.BaseActionBarActivity;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/9/1.
 */
public class TopicsManageActivity extends BaseActionBarActivity implements View.OnClickListener,AdapterView.OnItemClickListener{
    private TextView mBackTextView;
    private TextView mTitleTextView;
    private DragGridView mChannelGridView;
    private MyDragGridViewAdapter adapter;
    private ArrayList<String> mTopicItems = new ArrayList<>();
    private Context mContext;
    private ArrayList<String> mSelectedTopicItems = new ArrayList<>();//用来存放选中的数据

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_topics_manage);
        super.onCreate(savedInstanceState);

    }

    @Override
    public void init() {
        mContext = this;
        initTopicItems();
    }

    private void initTopicItems(){
      ArrayList<TopicTag> topicTags = TopicTagsManager.getInstance(mContext).getTopicTags();
        for (TopicTag topicTag:topicTags
             ) {
            mTopicItems.add(topicTag.getTagName());
            if(topicTag.isSelected()){
                mSelectedTopicItems.add(topicTag.getTagName());
            }
        }
    }


    @Override
    public void findView() {
        mBackTextView= (TextView) findViewById(R.id.back_tv);
        mTitleTextView= (TextView) findViewById(R.id.title_tv);
        mChannelGridView= (DragGridView) findViewById(R.id.channel_grid_view);
    }

    @Override
    public void setView() {
        mTitleTextView.setText(R.string.topics_manage);
    }

    @Override
    public void setViewListener() {
        mBackTextView.setOnClickListener(this);
        adapter = new MyDragGridViewAdapter(mTopicItems, mSelectedTopicItems,mContext);
        mChannelGridView.setAdapter(adapter);
        mChannelGridView.setOnItemClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back_tv:
                saveTopicTags();
                finish();
                break;
            default:
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
        String item = mTopicItems.get(position);
        //取消选中
        if(mSelectedTopicItems.contains(item)&&position!=0){
            mSelectedTopicItems.remove(item);
                Toast.makeText(mContext, "你取消选择了" + item,
                        Toast.LENGTH_SHORT).show();
        }else{
            mSelectedTopicItems.add(item);
        }
        adapter.notifyDataSetChanged();
    }

    private void saveTopicTags(){
        ArrayList selectedItems = adapter.saveSelectItem();
        ArrayList items = adapter.getItems();
        TopicTagsManager.getInstance(mContext).updateTopicTags(items,selectedItems);
    }
}
