package com.guiyi.egui.customwidget.CustomTextView;

import android.content.Context;
import android.text.SpannableString;
import android.util.AttributeSet;
import android.widget.TextView;

import com.guiyi.egui.util.ExpressionUtil;

/**
 * Created by ForOne on 15/8/26.
 * 能够识别表情的TextView
 */
public class CustomTextView extends TextView {

    private Context mContext;

    private boolean mIsExpressionReplace = false;

    public CustomTextView(Context context) {
        super(context);
        mContext = context;
        ReplaceExpression();
    }

    public CustomTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        ReplaceExpression();
    }

    public CustomTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        ReplaceExpression();
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        try {
            if(mContext != null){
                ReplaceExpression();
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    private void ReplaceExpression(){
        if(!mIsExpressionReplace){
            String text = getText().toString();
            SpannableString spannableString = ExpressionUtil.getInstance().getExpressionString(mContext, text).SpannableString;
            mIsExpressionReplace = !mIsExpressionReplace;
            setText(spannableString);
        }else{
            mIsExpressionReplace = !mIsExpressionReplace;
        }

    }
}
