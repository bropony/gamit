package com.guiyi.egui.activity.personal;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.R;
import com.guiyi.egui.util.ImageTools;
import com.guiyi.egui.util.QiniuUtil;
import com.guiyi.egui.customwidget.ClipImageLayout;
import com.guiyi.egui.websocket.RequestWS;
import com.jenwis.android.base.ui.BaseActionBarActivity;
import com.qiniu.android.http.ResponseInfo;
import com.qiniu.android.storage.UpCompletionHandler;

import org.json.JSONObject;

import java.io.File;

import message.gate.gatemsg;
import message.gate.ipostoper;
import message.gate.iuserinfo;

/**
 * Created by Administrator on 2015/8/20.
 */
public class ClipActivity extends BaseActionBarActivity{
    private ClipImageLayout mClipImageLayout;
    private String mPath;
    private ProgressDialog mLoadingDialog;
    private Bitmap mBitmap;
    private Button mSureButton;
    private TextView mBackTextView;
    private TextView mTitleTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_clipimage);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        mLoadingDialog =new ProgressDialog(this);
        mLoadingDialog.setTitle("请稍后...");
        mLoadingDialog.setCancelable(false);
        mPath=getIntent().getStringExtra("path");
        if(TextUtils.isEmpty(mPath)||!(new File(mPath).exists())){
            Toast.makeText(this, "图片加载失败", Toast.LENGTH_SHORT).show();
            return;
        }
        mBitmap = ImageTools.convertToBitmap(mPath, 600, 600);
        if(mBitmap ==null){
            Toast.makeText(this, "图片加载失败",Toast.LENGTH_SHORT).show();
            return;
        }
    }

    @Override
    public void findView() {
        mClipImageLayout = (ClipImageLayout) findViewById(R.id.id_clipImageLayout);
        mSureButton= (Button) findViewById(R.id.sure_button);
        mBackTextView= (TextView) findViewById(R.id.back_tv);
        mTitleTextView= (TextView) findViewById(R.id.title_tv);
    }

    @Override
    public void setView() {
        mActionBar.setVisibility(View.GONE);
        mClipImageLayout.setBitmap(mBitmap);
        mTitleTextView.setText(R.string.action_bar_title_setting_headicon);
    }

    @Override
    public void setViewListener() {
        mSureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                mLoadingDialog.show();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Bitmap bitmap = mClipImageLayout.clip();
//                        getExternalFilesDir
                        String path = getExternalFilesDir(null)+ "/com.guiyi.egui/cache/" + LocalInfoManager.getInstance(ClipActivity.this).getUserId() + ".png";
                        ImageTools.savePhotoToSDCard(bitmap, path);
                        Intent intent = new Intent();
                        intent.putExtra("path", path);
                        setResult(RESULT_OK, intent);
                        Log.v("tag", "request");
                        UploadAvatarImageResponse uploadAvatarImageResponse = new UploadAvatarImageResponse(path);
                        RequestWS.getInstance().getPostOperProxy().getImageUploadTokens(uploadAvatarImageResponse, LocalInfoManager.getInstance(ClipActivity.this).getSessionKey(),1);

                    }
                }).start();
            }
        });
        mBackTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }






    class UploadAvatarImageResponse extends  ipostoper.IPostOper_getImageUploadTokens_response{
        private String mAvatarPath;

        public UploadAvatarImageResponse(String avatarPath){
            mAvatarPath = avatarPath;
        }

        @Override
        public void onResponse(gatemsg.SeqImageInfo imageInfos) {
            if(imageInfos.getArray() != null && imageInfos.getArray().length > 0){
                final gatemsg.SImageInfo imageInfo = imageInfos.getArray()[0];
                Log.v("ClipActivit", "token:" + imageInfo.token);
                Log.v("ClipActivity", "key:" + imageInfo.imageKey);

                UpCompletionHandler upCompletionHandler = new UpCompletionHandler() {
                    @Override
                    public void complete(String s, ResponseInfo responseInfo, JSONObject jsonObject) {
                        Log.v("AvatarUpload","completed");
                        RequestWS.getInstance().getUserInfoProxy().changeAvatar(response, LocalInfoManager.getInstance(ClipActivity.this).getSessionKey(),imageInfo.imageKey);

                    }
                };

                QiniuUtil.uploadFile(mAvatarPath, imageInfo.imageKey, imageInfo.token, upCompletionHandler);
            }
        }

        @Override
        public void onError(String what, int code) {
            Log.v("ClipActivity", "onError " + code + ":" + what);
            mLoadingDialog.dismiss();
            finish();

        }

        @Override
        public void onTimeout() {
            Log.v("ClipActivity","onTimeOut");
            mLoadingDialog.dismiss();
            finish();
        }
    }



    iuserinfo.IUserInfo_changeAvatar_response response = new iuserinfo.IUserInfo_changeAvatar_response(){
        @Override
        public void onResponse() {
            Log.v("tag","onResponse");
            mLoadingDialog.dismiss();
            finish();
        }

        @Override
        public void onError(String what, int code) {
            Log.v("tag","onError"+what+"---"+code);
            mLoadingDialog.dismiss();
        }

        @Override
        public void onTimeout() {
            Log.v("tag","onTimeout");
            mLoadingDialog.dismiss();
        }
    };

}
