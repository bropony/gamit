package com.guiyi.egui.Managers;

import android.content.Context;
import android.util.Log;

import com.guiyi.egui.Listener.CommitUserPostListener;
import com.guiyi.egui.Listener.CommonResponseListener;
import com.guiyi.egui.util.QiniuUtil;
import com.guiyi.egui.websocket.RequestWS;

import java.util.ArrayList;

import message.common.publicdef;
import message.gate.gatemsg;
import message.gate.ipostoper;
import message.gate.itaileroper;

/**
 * Created by ForOne on 15/9/10.
 */
public class TailerOrderManager {

    private static TailerOrderManager mTailerOrderManager;
    private Context mContext;

    public static TailerOrderManager getInstance(Context context){
        if(mTailerOrderManager == null){
            mTailerOrderManager = new TailerOrderManager(context);
        }
        return mTailerOrderManager;
    }

    private TailerOrderManager(Context context){
        mContext = context;
    }

    public void commitTailerOrder(final CommonResponseListener callback,final String sessionKey, final itaileroper.SNewOrderParams params, final ArrayList<String> images,final boolean sendToFriends){
        String content = params.content;
        String title = params.title;

        CommitUserPostListener commitUserPostResponse = new CommitUserPostListener() {
            @Override
            public void success() {

                if(callback != null){
                    callback.success();
                }

                itaileroper.ITailerOper_newTailerOrder_response newTailerOrderResponse = new itaileroper.ITailerOper_newTailerOrder_response() {
                    @Override
                    public void onResponse(String orderId) {

                    }

                    @Override
                    public void onError(String what, int code) {

                    }

                    @Override
                    public void onTimeout() {

                    }
                };
                RequestWS.getInstance().getTailerOperProxy().newTailerOrder(newTailerOrderResponse,sessionKey,params);

            }

            @Override
            public void failure(String what, int code) {
                if(callback != null){
                    callback.failure(what, code);
                }
            }
        };

      if(sendToFriends){
          UserPostsManager.getInstance(mContext).commitUserPost(commitUserPostResponse, LocalInfoManager.getInstance(mContext).getSessionKey(), title, content, new ArrayList<String>(), images);
      }else{

          ipostoper.IPostOper_getImageUploadTokens_response getImageTokensRespose = new ipostoper.IPostOper_getImageUploadTokens_response() {
              @Override
              public void onResponse(final gatemsg.SeqImageInfo imageInfos) {
                  if(imageInfos.getArray().length != images.size()){
                      if(callback != null){
                          callback.failure("",0);
                      }
                      return;
                  }


                  //第二步：上传图片到托管服务器完毕后
                  QiniuUtil.UploadFileListListener uploadFileListCallback = new QiniuUtil.UploadFileListListener() {
                      @Override
                      public void success() {
                          Log.v("Commit", "第三步：上传图片到托管服务器完毕后，通知Server图片上传成功！");
                          String[] imageKeys = new String[imageInfos.getArray().length];
                          for (int i = 0; i< imageInfos.getArray().length; i++){
                              imageKeys[i] = imageInfos.getArray()[i].imageKey;
                          }
                          publicdef.SeqString seqString = new publicdef.SeqString(imageKeys);

                          ipostoper.IPostOper_didImageUpload_response uploadImagesResponse = new ipostoper.IPostOper_didImageUpload_response() {
                              @Override
                              public void onResponse() {


                                  itaileroper.ITailerOper_newTailerOrder_response response = new itaileroper.ITailerOper_newTailerOrder_response() {
                                      @Override
                                      public void onResponse(String orderId) {

                                          if(callback != null){
                                              callback.success();
                                          }
                                      }

                                      @Override
                                      public void onError(String what, int code) {
                                          if(callback != null){
                                              callback.failure(what,0);
                                          }
                                      }

                                      @Override
                                      public void onTimeout() {
                                          if(callback != null){
                                              callback.failure("TimeOut",0);
                                          }
                                      }
                                  };

                                  Log.v("Commit", "第四步：服务器得知图片上传成功，准备上传设计需求");
                                  //第四步：提交需求
                                  RequestWS.getInstance().getTailerOperProxy().newTailerOrder(response,sessionKey,params);
                              }

                              @Override
                              public void onError(String what, int code) {
                                  if(callback != null){
                                      callback.failure(what,code);
                                  }
                              }

                              @Override
                              public void onTimeout() {
                                  if(callback != null){
                                      callback.failure("TimeOut",0);
                                  }
                              }
                          };

                          //第三步：上传图片成功之后，通知服务器上传图片成功
                          RequestWS.getInstance().getPostOperProxy().didImageUpload(uploadImagesResponse, LocalInfoManager.getInstance(mContext).getSessionKey(),seqString);
                      }

                      @Override
                      public void failed() {
                          if(callback != null){
                              callback.failure("",0);
                          }
                      }
                  };


                  Log.v("Commit", "第二步，获取图片tokens成功，通过token上传图片");
                  //第二步：解析Server返回的图片信息，上传图片到托管服务器
                  gatemsg.SImageInfo[] sImages = imageInfos.getArray();

                  QiniuUtil.uploadFiles(sImages, images, uploadFileListCallback);
              }

              @Override
              public void onError(String what, int code) {
                  if(callback != null){
                      callback.failure(what,code);
                  }
              }

              @Override
              public void onTimeout() {
                  if(callback != null){
                      callback.failure("TimeOut",0);
                  }
              }
          };

          Log.v("Commit", "第一步，获取图片tokens");
          //第一步，获取图片tokens
          RequestWS.getInstance().getPostOperProxy().getImageUploadTokens(getImageTokensRespose, LocalInfoManager.getInstance(mContext).getSessionKey(), images.size());
      }

    }


}
