package com.guiyi.egui.logic.config;

/**
 * Created by zhengyuji on 15/8/3.
 */
public class WSProxy {
    public static final String LOGIN = "ILogin";
    public static final String POSTOPER = "IPostOper";
    public static final String USERINFO = "IUserInfo";
    public static final String TAILEROPER = "ITailerOper";
}
