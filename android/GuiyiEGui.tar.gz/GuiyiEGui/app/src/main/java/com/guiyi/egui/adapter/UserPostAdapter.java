package com.guiyi.egui.adapter;

import android.content.Context;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Managers.UserFollowManager;
import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.R;
import com.guiyi.egui.activity.personal.LoginActivity;
import com.guiyi.egui.customwidget.CustomTextView.CustomTextView;
import com.guiyi.egui.events.UserPostStatusChangedEvent;
import com.guiyi.egui.util.CommonUtil;
import com.guiyi.egui.util.DateUtil;
import com.guiyi.egui.util.ImageLoaderUtil;
import com.guiyi.egui.customwidget.CircleImageView;

import java.util.ArrayList;

import de.greenrobot.event.EventBus;
import message.gate.gatemsg;

/**
 * Created by ForOne on 15/8/19.
 */
public class UserPostAdapter extends BaseAdapter{

    private LayoutInflater mInflater;
    private Context mContext;
    private gatemsg.SUserPost[] mUserPost;

    private final int MAX_IMAGE_COUNT = 3;

    public
    UserPostAdapter(Context context) {
        mContext = context;
        mInflater = LayoutInflater.from(context);
        EventBus.getDefault().register(this);
    }

    public void setUserPost(gatemsg.SUserPost[] userPost){
        mUserPost = userPost;
    }

    @Override
    public int getCount() {
        return mUserPost.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.list_item_topic, null);
            holder = new ViewHolder();
            holder.title = (TextView)convertView.findViewById(R.id.topic_title_text_view);
            holder.content = (CustomTextView)convertView.findViewById(R.id.topic_content_text_view);
            holder.image1 = (ImageView)convertView.findViewById(R.id.topic_content_image_view_1);
            holder.image2 = (ImageView)convertView.findViewById(R.id.topic_content_image_view_2);
            holder.image3 = (ImageView)convertView.findViewById(R.id.topic_content_image_view_3);
            holder.image4 = (ImageView)convertView.findViewById(R.id.topic_content_image_view_4);
            holder.image5 = (ImageView)convertView.findViewById(R.id.topic_content_image_view_5);
            holder.image6 = (ImageView)convertView.findViewById(R.id.topic_content_image_view_6);
            holder.image7 = (ImageView)convertView.findViewById(R.id.topic_content_image_view_7);
            holder.image8 = (ImageView)convertView.findViewById(R.id.topic_content_image_view_8);
            holder.image9 = (ImageView)convertView.findViewById(R.id.topic_content_image_view_9);
            holder.image0 = (ImageView)convertView.findViewById(R.id.topic_content_image_view);
            holder.portrait = (CircleImageView)convertView.findViewById(R.id.portrait_image_view);
            holder.nickname = (TextView)convertView.findViewById(R.id.nickName_text_view);
            holder.follow = (TextView)convertView.findViewById(R.id.topic_follow_text_view);
            holder.time = (TextView)convertView.findViewById(R.id.topic_publish_time);
            holder.shareCount = (TextView)convertView.findViewById(R.id.user_post_share_text_view);
            holder.commentCount = (TextView)convertView.findViewById(R.id.user_post_comment_text_view);
            holder.upvoteCount = (TextView)convertView.findViewById(R.id.user_post_upvote_text_view);

            convertView.setTag(holder);
        }
        else {
            holder = (ViewHolder) convertView.getTag();
        }

        final gatemsg.SUserPost userPost = mUserPost[position];

       if(userPost != null){
           holder.title.setText(userPost.title);
           holder.content.setText(userPost.content);
           holder.time.setText(DateUtil.getDateIntervelTimeStringToNow(userPost.createDt));
           holder.shareCount.setText(userPost.sharedTimes + "");
           holder.commentCount.setText(userPost.commentedTimes + "");
           holder.upvoteCount.setText(userPost.upvotedTimes + "");
           holder.nickname.setText(userPost.userInfo.nickname);

           if(userPost.userInfo.avatarUrl != null){
               ImageLoaderUtil.displayImage(userPost.userInfo.avatarUrl, holder.portrait);
           }
           holder.follow.setTag(userPost.postId);

           //自己的帖子不显示关注按钮
            if(userPost.userInfo.userId.equals(LocalInfoManager.getInstance(mContext).getUserId())){
                holder.follow.setVisibility(View.GONE);
            }else{

                holder.follow.setVisibility(View.VISIBLE);

                final FollowUserResponse followUserResponse =  new FollowUserResponse(holder);
                final UnfollowUserResponse unfollowUserResponse =  new UnfollowUserResponse(holder);

                if(!CommonUtil.IsLogined){
                    holder.follow.setBackgroundResource(R.drawable.follow);
                }else{
                    boolean isFollow = UserFollowManager.getInstance(mContext).isFollow(userPost.userInfo.userId);
                    holder.follow.setBackgroundResource(isFollow ?R.drawable.unfollow:R.drawable.follow);
                }

                holder.follow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!CommonUtil.IsLogined) {
                            Intent intent = new Intent(mContext, LoginActivity.class);
                            mContext.startActivity(intent);
                        } else {
                            boolean isFollow = UserFollowManager.getInstance(mContext).isFollow(userPost.userInfo.userId);
                            if (isFollow) {
                                UserFollowManager.getInstance(mContext).unfollowUser(unfollowUserResponse, LocalInfoManager.getInstance(mContext).getSessionKey(), userPost.userInfo.userId);
                            } else {
                                UserFollowManager.getInstance(mContext).followUser(followUserResponse, LocalInfoManager.getInstance(mContext).getSessionKey(), userPost.userInfo.userId);
                            }
                        }
                    }
                });
            }

           //下载图片
           gatemsg.SImageInfo[] imageInfos = userPost.images.getArray();
           if (imageInfos.length==9){
               holder.image1.setVisibility(View.VISIBLE);
               holder.image2.setVisibility(View.VISIBLE);
               holder.image3.setVisibility(View.VISIBLE);
               holder.image4.setVisibility(View.VISIBLE);
               holder.image5.setVisibility(View.VISIBLE);
               holder.image6.setVisibility(View.VISIBLE);
               holder.image7.setVisibility(View.VISIBLE);
               holder.image8.setVisibility(View.VISIBLE);
               holder.image9.setVisibility(View.VISIBLE);
               holder.image0.setVisibility(View.GONE);
           }else if(imageInfos.length==8){
               holder.image1.setVisibility(View.VISIBLE);
               holder.image2.setVisibility(View.VISIBLE);
               holder.image3.setVisibility(View.VISIBLE);
               holder.image4.setVisibility(View.VISIBLE);
               holder.image5.setVisibility(View.VISIBLE);
               holder.image6.setVisibility(View.VISIBLE);
               holder.image7.setVisibility(View.VISIBLE);
               holder.image8.setVisibility(View.VISIBLE);
               holder.image9.setVisibility(View.GONE);
               holder.image0.setVisibility(View.GONE);
           }else if(imageInfos.length==7){
               holder.image1.setVisibility(View.VISIBLE);
               holder.image2.setVisibility(View.VISIBLE);
               holder.image3.setVisibility(View.VISIBLE);
               holder.image4.setVisibility(View.VISIBLE);
               holder.image5.setVisibility(View.VISIBLE);
               holder.image6.setVisibility(View.VISIBLE);
               holder.image7.setVisibility(View.VISIBLE);
               holder.image8.setVisibility(View.GONE);
               holder.image9.setVisibility(View.GONE);
               holder.image0.setVisibility(View.GONE);
           }else if(imageInfos.length==6){
               holder.image1.setVisibility(View.VISIBLE);
               holder.image2.setVisibility(View.VISIBLE);
               holder.image3.setVisibility(View.VISIBLE);
               holder.image4.setVisibility(View.VISIBLE);
               holder.image5.setVisibility(View.VISIBLE);
               holder.image6.setVisibility(View.VISIBLE);
               holder.image7.setVisibility(View.GONE);
               holder.image8.setVisibility(View.GONE);
               holder.image9.setVisibility(View.GONE);
               holder.image0.setVisibility(View.GONE);
           }else if(imageInfos.length==5){
               holder.image1.setVisibility(View.VISIBLE);
               holder.image2.setVisibility(View.VISIBLE);
               holder.image3.setVisibility(View.VISIBLE);
               holder.image4.setVisibility(View.VISIBLE);
               holder.image5.setVisibility(View.VISIBLE);
               holder.image6.setVisibility(View.GONE);
               holder.image7.setVisibility(View.GONE);
               holder.image8.setVisibility(View.GONE);
               holder.image9.setVisibility(View.GONE);
               holder.image0.setVisibility(View.GONE);
           }else if(imageInfos.length==4){
               holder.image1.setVisibility(View.VISIBLE);
               holder.image2.setVisibility(View.VISIBLE);
               holder.image3.setVisibility(View.GONE);
               holder.image4.setVisibility(View.VISIBLE);
               holder.image5.setVisibility(View.VISIBLE);
               holder.image6.setVisibility(View.GONE);
               holder.image7.setVisibility(View.GONE);
               holder.image8.setVisibility(View.GONE);
               holder.image9.setVisibility(View.GONE);
               holder.image0.setVisibility(View.GONE);
           }else if(imageInfos.length == 3){
               holder.image1.setVisibility(View.VISIBLE);
               holder.image2.setVisibility(View.VISIBLE);
               holder.image3.setVisibility(View.VISIBLE);
               holder.image4.setVisibility(View.GONE);
               holder.image5.setVisibility(View.GONE);
               holder.image6.setVisibility(View.GONE);
               holder.image7.setVisibility(View.GONE);
               holder.image8.setVisibility(View.GONE);
               holder.image9.setVisibility(View.GONE);
               holder.image0.setVisibility(View.GONE);
           }else if(imageInfos.length == 2){
               holder.image1.setVisibility(View.VISIBLE);
               holder.image2.setVisibility(View.VISIBLE);
               holder.image3.setVisibility(View.GONE);
               holder.image4.setVisibility(View.GONE);
               holder.image5.setVisibility(View.GONE);
               holder.image6.setVisibility(View.GONE);
               holder.image7.setVisibility(View.GONE);
               holder.image8.setVisibility(View.GONE);
               holder.image9.setVisibility(View.GONE);
               holder.image0.setVisibility(View.GONE);
           }else if(imageInfos.length == 1){
               holder.image1.setVisibility(View.GONE);
               holder.image2.setVisibility(View.GONE);
               holder.image3.setVisibility(View.GONE);
               holder.image4.setVisibility(View.GONE);
               holder.image5.setVisibility(View.GONE);
               holder.image6.setVisibility(View.GONE);
               holder.image7.setVisibility(View.GONE);
               holder.image8.setVisibility(View.GONE);
               holder.image9.setVisibility(View.GONE);
               holder.image0.setVisibility(View.VISIBLE);
           }else{
               holder.image1.setVisibility(View.GONE);
               holder.image2.setVisibility(View.GONE);
               holder.image3.setVisibility(View.GONE);
               holder.image4.setVisibility(View.GONE);
               holder.image5.setVisibility(View.GONE);
               holder.image6.setVisibility(View.GONE);
               holder.image7.setVisibility(View.GONE);
               holder.image8.setVisibility(View.GONE);
               holder.image9.setVisibility(View.GONE);
               holder.image0.setVisibility(View.GONE);
           }

           if(imageInfos != null && imageInfos.length > 0){
               ArrayList<String> urlList = new ArrayList<>();
               //微说列表预览时只下载指定数量的图片，目前下载3张,图片为缩略图
               ImageView image_1=null;
               ImageView image_2=null;
               ImageView image_3=null;
               ImageView image_4=null;
               ImageView image_5=null;
               ImageView image_6=null;
               ImageView image_7=null;
               ImageView image_8=null;
               ImageView image_9=null;
               ImageView image_0=null;
               if (imageInfos.length==1){
                   image_0=holder.image0;
                   ImageLoaderUtil.displayImage(imageInfos[0].formatedDownloadUrl, image_0);
               }else if (imageInfos.length==2){
                   image_1=holder.image1;
                   image_2=holder.image2;
                   ImageLoaderUtil.displayImage(imageInfos[0].formatedDownloadUrl, image_1);
                   ImageLoaderUtil.displayImage(imageInfos[1].formatedDownloadUrl, image_2);
               }else if (imageInfos.length==3){
                   image_1=holder.image1;
                   image_2=holder.image2;
                   image_3=holder.image3;
                   ImageLoaderUtil.displayImage(imageInfos[0].formatedDownloadUrl, image_1);
                   ImageLoaderUtil.displayImage(imageInfos[1].formatedDownloadUrl, image_2);
                   ImageLoaderUtil.displayImage(imageInfos[2].formatedDownloadUrl, image_3);
               }else if (imageInfos.length==4){
                   image_1=holder.image1;
                   image_2=holder.image2;
                   image_4=holder.image4;
                   image_5=holder.image5;
                   ImageLoaderUtil.displayImage(imageInfos[0].formatedDownloadUrl, image_1);
                   ImageLoaderUtil.displayImage(imageInfos[1].formatedDownloadUrl, image_2);
                   ImageLoaderUtil.displayImage(imageInfos[2].formatedDownloadUrl, image_4);
                   ImageLoaderUtil.displayImage(imageInfos[3].formatedDownloadUrl, image_5);

               }else if (imageInfos.length==5){
                   image_1=holder.image1;
                   image_2=holder.image2;
                   image_3=holder.image3;
                   image_4=holder.image4;
                   image_5=holder.image5;
                   ImageLoaderUtil.displayImage(imageInfos[0].formatedDownloadUrl, image_1);
                   ImageLoaderUtil.displayImage(imageInfos[1].formatedDownloadUrl, image_2);
                   ImageLoaderUtil.displayImage(imageInfos[2].formatedDownloadUrl, image_3);
                   ImageLoaderUtil.displayImage(imageInfos[3].formatedDownloadUrl, image_4);
                   ImageLoaderUtil.displayImage(imageInfos[4].formatedDownloadUrl, image_5);
               }else if (imageInfos.length==6){
                   image_1=holder.image1;
                   image_2=holder.image2;
                   image_3=holder.image3;
                   image_4=holder.image4;
                   image_5=holder.image5;
                   image_6=holder.image6;
                   ImageLoaderUtil.displayImage(imageInfos[0].formatedDownloadUrl, image_1);
                   ImageLoaderUtil.displayImage(imageInfos[1].formatedDownloadUrl, image_2);
                   ImageLoaderUtil.displayImage(imageInfos[2].formatedDownloadUrl, image_3);
                   ImageLoaderUtil.displayImage(imageInfos[3].formatedDownloadUrl, image_4);
                   ImageLoaderUtil.displayImage(imageInfos[4].formatedDownloadUrl, image_5);
                   ImageLoaderUtil.displayImage(imageInfos[5].formatedDownloadUrl, image_6);
               }else if (imageInfos.length==7){
                   image_1=holder.image1;
                   image_2=holder.image2;
                   image_3=holder.image3;
                   image_4=holder.image4;
                   image_5=holder.image5;
                   image_6=holder.image6;
                   image_7=holder.image7;
                   ImageLoaderUtil.displayImage(imageInfos[0].formatedDownloadUrl, image_1);
                   ImageLoaderUtil.displayImage(imageInfos[1].formatedDownloadUrl, image_2);
                   ImageLoaderUtil.displayImage(imageInfos[2].formatedDownloadUrl, image_3);
                   ImageLoaderUtil.displayImage(imageInfos[3].formatedDownloadUrl, image_4);
                   ImageLoaderUtil.displayImage(imageInfos[4].formatedDownloadUrl, image_5);
                   ImageLoaderUtil.displayImage(imageInfos[5].formatedDownloadUrl, image_6);
                   ImageLoaderUtil.displayImage(imageInfos[6].formatedDownloadUrl, image_7);
               }else if (imageInfos.length==8){
                   image_1=holder.image1;
                   image_2=holder.image2;
                   image_3=holder.image3;
                   image_4=holder.image4;
                   image_5=holder.image5;
                   image_6=holder.image6;
                   image_7=holder.image7;
                   image_8=holder.image8;
                   ImageLoaderUtil.displayImage(imageInfos[0].formatedDownloadUrl, image_1);
                   ImageLoaderUtil.displayImage(imageInfos[1].formatedDownloadUrl, image_2);
                   ImageLoaderUtil.displayImage(imageInfos[2].formatedDownloadUrl, image_3);
                   ImageLoaderUtil.displayImage(imageInfos[3].formatedDownloadUrl, image_4);
                   ImageLoaderUtil.displayImage(imageInfos[4].formatedDownloadUrl, image_5);
                   ImageLoaderUtil.displayImage(imageInfos[5].formatedDownloadUrl, image_6);
                   ImageLoaderUtil.displayImage(imageInfos[6].formatedDownloadUrl, image_7);
                   ImageLoaderUtil.displayImage(imageInfos[7].formatedDownloadUrl, image_8);
               }else if (imageInfos.length==9){
                   image_1=holder.image1;
                   image_2=holder.image2;
                   image_3=holder.image3;
                   image_4=holder.image4;
                   image_5=holder.image5;
                   image_6=holder.image6;
                   image_7=holder.image7;
                   image_8=holder.image8;
                   image_9=holder.image9;
                   ImageLoaderUtil.displayImage(imageInfos[0].formatedDownloadUrl, image_1);
                   ImageLoaderUtil.displayImage(imageInfos[1].formatedDownloadUrl, image_2);
                   ImageLoaderUtil.displayImage(imageInfos[2].formatedDownloadUrl, image_3);
                   ImageLoaderUtil.displayImage(imageInfos[3].formatedDownloadUrl, image_4);
                   ImageLoaderUtil.displayImage(imageInfos[4].formatedDownloadUrl, image_5);
                   ImageLoaderUtil.displayImage(imageInfos[5].formatedDownloadUrl, image_6);
                   ImageLoaderUtil.displayImage(imageInfos[6].formatedDownloadUrl, image_7);
                   ImageLoaderUtil.displayImage(imageInfos[7].formatedDownloadUrl, image_8);
                   ImageLoaderUtil.displayImage(imageInfos[8].formatedDownloadUrl, image_9);
               }else {

               }

           }else{

           }
       }
        return convertView;
    }

    //不要改函数名字以及参数，EventBus会调用该函数
    public void onEventMainThread(UserPostStatusChangedEvent userPostStatusChangedEvent){
        String id = userPostStatusChangedEvent.UserPostId;
        for (gatemsg.SUserPost userPost:mUserPost
             ) {
            if(userPost.postId.equals(id)){
                userPost.commentedTimes = userPostStatusChangedEvent.CommentCount;
                userPost.upvotedTimes = userPostStatusChangedEvent.UpvoteCount;
                userPost.sharedTimes = userPostStatusChangedEvent.ShareCount;
            }
        }
        notifyDataSetChanged();
    }



    class UnfollowUserResponse implements UserFollowManager.FollowOrNotUserListener {

        private ViewHolder mViewHolder;
        public UnfollowUserResponse(ViewHolder viewHolder){
            mViewHolder = viewHolder;
        }

        @Override
        public void success(gatemsg.SMyFocus newFocus) {
            mViewHolder.follow.setBackgroundResource(R.drawable.follow);
            notifyDataSetChanged();
            Toast.makeText(mContext, "取消关注成功！", Toast.LENGTH_SHORT).show();
            //TODO 更新同一个人其他帖子的关注按钮状态
        }

        @Override
        public void failed(String error) {
            mViewHolder.follow.setBackgroundResource(R.drawable.follow);
            //TODO 更新同一个人其他帖子的关注按钮状态
        }
    }

    class FollowUserResponse implements UserFollowManager.FollowOrNotUserListener {
        private ViewHolder mViewHolder;
        public FollowUserResponse(ViewHolder viewHolder){
            mViewHolder = viewHolder;
        }

        @Override
        public void success(gatemsg.SMyFocus newFocus) {
            mViewHolder.follow.setBackgroundResource(R.drawable.unfollow);
            notifyDataSetChanged();
            Toast.makeText(mContext, R.string.attention_success, Toast.LENGTH_SHORT).show();
        }

        @Override
        public void failed(String error) {
            mViewHolder.follow.setBackgroundResource(R.drawable.follow);
        }
    }

     final class ViewHolder{
        public TextView title;
         public CustomTextView content;
         public TextView nickname;
         public CircleImageView portrait;
         public TextView follow;
         public TextView time;
         public TextView shareCount;
         public TextView commentCount;
         public TextView upvoteCount;
         public ImageView image1;
         public ImageView image2;
         public ImageView image3;
         public ImageView image4;
         public ImageView image5;
         public ImageView image6;
         public ImageView image7;
         public ImageView image8;
         public ImageView image9;
         public ImageView image0;
     }
}
