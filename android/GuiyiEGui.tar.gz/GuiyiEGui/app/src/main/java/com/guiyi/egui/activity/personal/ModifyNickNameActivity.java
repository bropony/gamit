package com.guiyi.egui.activity.personal;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.R;
import com.guiyi.egui.util.CommonUtil;
import com.guiyi.egui.util.StringUtil;
import com.guiyi.egui.websocket.RequestWS;
import com.jenwis.android.base.base.util.LogUtils;
import com.jenwis.android.base.ui.BaseActionBarActivity;

import message.gate.iuserinfo;

/**
 * Created by C on 2015/8/19.
 */
public class ModifyNickNameActivity extends BaseActionBarActivity implements View.OnClickListener{
    private TextView mBack;
    private TextView mTitle;
    private TextView mSave;
    private EditText mNickNameEditText;
    private String mNickName;
    private String mNewNickName;
    private static final int TITLE_MAX_LENGTH = 12;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_modify_nickname);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {
        Intent intent = getIntent();
        mNickName = intent.getStringExtra("NickName");
    }

    @Override
    public void findView() {
        mBack= (TextView) findViewById(R.id.back_tv);
        mTitle= (TextView) findViewById(R.id.title_tv);
        mSave= (TextView) findViewById(R.id.right_text_view);
        mNickNameEditText= (EditText) findViewById(R.id.nickName_EditText);
    }

    @Override
    public void setView() {
        mTitle.setText(R.string.action_bar_title_nick_name);
        mSave.setVisibility(View.VISIBLE);
        mSave.setText("保存");
        mNickNameEditText.setText(mNickName);
    }

    @Override
    public void setViewListener() {
        mBack.setOnClickListener(this);
        mSave.setOnClickListener(this);
        mNickNameEditText.addTextChangedListener(new TextWatcher() {
            String text = "";
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                Editable editable = mNickNameEditText.getText();
                String content = editable.toString();

                int length = StringUtil.getLengthOfGb2312(content);
                if(length > TITLE_MAX_LENGTH){
                    mNickNameEditText.setText(text);
                    Toast.makeText(ModifyNickNameActivity.this,"昵称字数过多",Toast.LENGTH_SHORT).show();
                }
                text = mNickNameEditText.getText().toString();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back_tv:
                finish();
                break;
            case R.id.right_text_view:
                modifyNickName();
                break;
        }
    }

    private void modifyNickName() {
        mNewNickName =mNickNameEditText.getText().toString().trim();
        if (mNewNickName.equals("")){
            Toast.makeText(this,R.string.toast_nick_name_illegal,Toast.LENGTH_SHORT).show();
            return;
        }
        if (0 == CommonUtil.isNetworkAvailable(this)) {
            Toast.makeText(this, R.string.toast_network_error, Toast.LENGTH_SHORT).show();
        } else {
            IUserInfoChangeNickName response = new IUserInfoChangeNickName(this);
            RequestWS.getInstance().getUserInfoProxy().changeNickname(response, LocalInfoManager.getInstance(this).getSessionKey(), mNewNickName);

        }

        Intent intent = new Intent();
        intent.putExtra("NickName", mNewNickName);
        setResult(RESULT_OK, intent);
    }
    class IUserInfoChangeNickName extends iuserinfo.IUserInfo_changeNickname_response{
        private Context ct;
        public IUserInfoChangeNickName(Context context)
        {
            super();
            this.ct=context;
        }

        @Override
        public void onResponse() {
            LocalInfoManager.getInstance(ModifyNickNameActivity.this).setNickName(mNickName);
            finish();
            LogUtils.LogD("tag","success!");
        }

        @Override
        public void onError(String what, int code) {
            LogUtils.LogD("tag",what+"--onError--"+code);
        }

        @Override
        public void onTimeout() {
            LogUtils.LogD("tag","timeout!");
        }
    }
}
