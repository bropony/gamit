package com.guiyi.egui.Managers;

import android.content.Context;

import com.guiyi.egui.bean.TopicTag;

import org.apache.http.util.EncodingUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by ForOne on 15/9/7.
 */
public class TopicTagsManager {
    private static TopicTagsManager mTopicTagsManager;
    private ArrayList<TopicTag> mTopicTags = new ArrayList<>();
    private Context mContext;

    public static TopicTagsManager getInstance(Context context){
        if(mTopicTagsManager == null){
            mTopicTagsManager = new TopicTagsManager(context);
        }
        return mTopicTagsManager;
    }

    private TopicTagsManager(Context context){
        mContext = context;
        loadTopicsJson();
        initSelectedTopicTags();
        initTopicTagsOrder();
    }

    private void loadTopicsJson(){
        String json = getAssetsJson();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject object = (JSONObject) arr.opt(i);
                TopicTag topicTag = new TopicTag();
                topicTag.setTagName(object.getString("tagName"));
                topicTag.setTagId(object.getString("tagId"));
                if(!object.isNull("isDefault")&& object.getString("isDefault").equals("1")){
                    topicTag.setIsDefualt(true);
                }else{
                    topicTag.setIsDefualt(false);
                }

                if(!object.isNull("tagType")){
                    topicTag.setTagType(object.getString("tagType"));
                }
                mTopicTags.add(topicTag);
            }
        } catch (JSONException e) {

            e.printStackTrace();
        }
    }

    private String getAssetsJson(){
        String result = "";
        try {
            InputStream in = mContext.getAssets().open("json/t_topic_tag.json");
            int length = in.available();
            byte[]  buffer = new byte[length];
            in.read(buffer);
            result = EncodingUtils.getString(buffer, "UTF-8");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    private void initSelectedTopicTags(){
        Set<String> stringSet = LocalInfoManager.getInstance(mContext).getSelectedTopicTags();
        if(stringSet != null && stringSet.size() != 0){//本地已配置显示的话题，则显示设置的话题
            for (String tag:stringSet
                    ) {
                for (TopicTag topicTag:mTopicTags
                        ) {
                    if(topicTag.getTagId().equals(tag)){
                        topicTag.setIsSelected(true);
                        break;
                    }
                }
            }
        }else{//本地没有设置显示话题时，设置默认的
            for (TopicTag topicTag:mTopicTags
                    ) {
                topicTag.setIsSelected(topicTag.getIsDefualt());
            }
        }

    }

    private void initTopicTagsOrder(){
        Set<String> stringSet = LocalInfoManager.getInstance(mContext).getTopicTagsSeq();
        if(stringSet != null && stringSet.size() != 0){
            ArrayList<TopicTag> topicTags = new ArrayList<>();
            for (String tag:stringSet
                 ) {
                for (TopicTag topicTag:mTopicTags
                        ) {
                    if(topicTag.getTagId().equals(tag)){

                        if(topicTag.getTagId().equals("0")){
                            topicTags.add(0,topicTag);
                        }else{
                            topicTags.add(topicTag);
                        }
                        break;
                    }
                }
            }
            mTopicTags = topicTags;
        }
    }

    public void updateTopicTags(ArrayList<String> items,ArrayList<String> selectedItems){
        ArrayList<TopicTag> topicTags = new ArrayList<>();
        for (String tagName:items
                ) {
            for (TopicTag topicTag:mTopicTags
                    ) {
                if(topicTag.getTagName().equals(tagName)){
                    topicTags.add(topicTag);
                    if(selectedItems.contains(topicTag.getTagName())) {
                        topicTag.setIsSelected(true);
                    }else {
                        topicTag.setIsSelected(false);
                    }
                    break;
                }
            }
        }
        mTopicTags = topicTags;
        saveTopicTags(mTopicTags);
    }

    public ArrayList<TopicTag> getTopicTags(){
        return mTopicTags;
    }

    public ArrayList<TopicTag> getSelectedTopicTags(){
        ArrayList<TopicTag> topicTags = new ArrayList<>();
        for (TopicTag topicTag:mTopicTags
             ) {
            if(topicTag.isSelected()){
                topicTags.add(topicTag);
            }
        }
        return topicTags;
    }

    public void saveTopicTags(ArrayList<TopicTag> topicTags){

        Set<String> orderSet = new HashSet<>();
        Set<String> selectedSet = new HashSet<>();
        for (TopicTag topicTag:topicTags
             ) {
            orderSet.add(topicTag.getTagId());
            if(topicTag.isSelected()){
                selectedSet.add(topicTag.getTagId());
            }
        }
        mTopicTags = topicTags;
        LocalInfoManager.getInstance(mContext).setSelectedTopicTags(selectedSet);
        LocalInfoManager.getInstance(mContext).setTopicTagsSeq(orderSet);
    }

    public String getTagNameByTagId(String tagId){
        String tagName = null;
        for (TopicTag topicTag:mTopicTags
             ) {
            if(topicTag.getTagId().equals(tagId)){
                tagName = topicTag.getTagName();
                return tagName;
            }
        }
        return tagName;
    }
}
