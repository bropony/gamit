package com.guiyi.egui.util;

/**
 * Created by C on 2015/8/11.
 */

import com.guiyi.egui.logic.config.WSProxy;

import rmi.RmiClient;
import rmi.RmiManager;

import java.net.URI;


public class RmiSetting {
    public static void initSettings()
    {
        RmiSetting.createGateServiceClient();
        RmiSetting.registMessageHandlers();
    }

    private static void createGateServiceClient()
    {
        URI serverURI = null;

        try{
            serverURI = new URI("ws://192.168.0.168:8001");
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return;
        }

        RmiClient client = new RmiClient(serverURI);

        RmiManager.instance().addRmiClient(RmiManager.ClientType_GateServer, client);
        RmiSetting.bindGateServiceProxies(client);
    }

    private static void bindGateServiceProxies(RmiClient client)
    {

        client.bindProxy(WSProxy.LOGIN);
        client.bindProxy(WSProxy.POSTOPER);
        client.bindProxy(WSProxy.USERINFO);
        client.bindProxy(WSProxy.TAILEROPER);


        // list more proxy bindings blow...
        //TODO
    }

    private static void registMessageHandlers()
    {
        //MessageManager.instance().registMessageHandler(command.ETestCommand.FirstMessage, new FirstMessageHandler());

        // list more handler registering blow...
        // to do
    }
}
