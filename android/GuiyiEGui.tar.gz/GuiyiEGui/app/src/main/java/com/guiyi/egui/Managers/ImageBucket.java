package com.guiyi.egui.Managers;

import java.util.List;

/**
 * 一个目录的相册对象
 * 
 * @author Administrator
 * 
 */
public class ImageBucket {
	public int count = 0;
	public String bucketName;
	public List<ImageItem> imageList;

}
