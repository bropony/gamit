package com.guiyi.egui.Managers;

import android.content.Context;
import android.util.Log;

import com.guiyi.egui.Listener.CommitUserPostListener;
import com.guiyi.egui.Listener.GetUserPostByIdListener;
import com.guiyi.egui.Listener.GetUserPostsLisenter;
import com.guiyi.egui.customwidget.CustomProgressLoading.CustomProgress;
import com.guiyi.egui.util.CommonUtil;
import com.guiyi.egui.util.DateUtil;
import com.guiyi.egui.util.QiniuUtil;
import com.guiyi.egui.websocket.RequestWS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import message.common.publicdef;
import message.gate.gatemsg;
import message.gate.ipostoper;

/**
 * Created by ForOne on 15/8/19.
 * 用于管理User Posts
 */
public class UserPostsManager {
    private static UserPostsManager mUserPostsManager;
    private Context mContext;

    private ArrayList<gatemsg.SUserPost> mUserPosts;

    //最新的帖子的时间
    private Date mLastestUserPostDate;

    //最旧的帖子的时间
    private Date mOldestUserPostDate;

    private boolean mIsFirstRequestLastestUserPost = true;

    private UserPostsManager(Context context){
        mContext = context;
        mUserPosts = new ArrayList<>();
    }

    public static UserPostsManager getInstance(Context context){
        if(mUserPostsManager == null){
            mUserPostsManager = new UserPostsManager(context);
        }
        return mUserPostsManager;
    }

    public ArrayList<gatemsg.SUserPost> getUserPosts(){
        return mUserPosts;
    }

    public void addUserPost(gatemsg.SUserPost userPost){

        gatemsg.SUserPost post = isContainThePost(userPost.postId);
        if(post != null){
            mUserPosts.remove(post);
        }
        mUserPosts.add(userPost);
    }

    public void addUserPost(gatemsg.SUserPost userPost,int index){
        gatemsg.SUserPost post = isContainThePost(userPost.postId);
        if(post != null){
            mUserPosts.remove(post);
        }
        mUserPosts.add(index,userPost);
    }

    //根据Post的ID来确定是否已经存在该帖子
    public gatemsg.SUserPost isContainThePost(String postId){
        gatemsg.SUserPost sUserPost = null;
        for (gatemsg.SUserPost post:mUserPosts) {
            if(post.postId.equals(postId)){
                sUserPost = post;
                break;
            }
        }
        return sUserPost;
    }

    private void sortSUserPosts(){
        Collections.sort(mUserPosts, new Comparator<gatemsg.SUserPost>() {
            @Override
            public int compare(gatemsg.SUserPost lhs, gatemsg.SUserPost rhs) {
                return DateUtil.compareDate(rhs.createDt, lhs.createDt);
            }
        });
    }

    public void getUserPostById(String postId, Context context, final GetUserPostByIdListener callback){
        gatemsg.SUserPost userPost = null;
        userPost = isContainThePost(postId);
        if(userPost != null){
            if(callback != null){
                callback.getUserPostResponse(userPost);
            }
            return;
        }

        ipostoper.IPostOper_getUserPostByPostId_response response = new ipostoper.IPostOper_getUserPostByPostId_response() {
            @Override
            public void onResponse(gatemsg.SUserPost userPost) {
                if(callback != null){
                    callback.getUserPostResponse(userPost);
                }
            }

            @Override
            public void onError(String what, int code) {
                if(callback != null){
                    callback.getUserPostResponse(null);
                }
            }

            @Override
            public void onTimeout() {
                if(callback != null){
                    callback.getUserPostResponse(null);
                }
            }
        };

        RequestWS.getInstance().getPostOperProxy().getUserPostByPostId(response, CommonUtil.getDeviceCode(context), postId, QiniuUtil.DefaultImageThumbnailFormat());
    }

    public void addUserPosts(ArrayList<gatemsg.SUserPost> userPostArrayList){
       for (gatemsg.SUserPost userPost : userPostArrayList){
           addUserPost(userPost);
       }
    }

    public void addUserPosts(gatemsg.SUserPost[] userPosts){
        List<gatemsg.SUserPost> list = Arrays.asList(userPosts);
        addUserPosts(new ArrayList<gatemsg.SUserPost>(list));
    }

    public void clearUserPosts(){
        mUserPosts.clear();
        mLastestUserPostDate = null;
        mOldestUserPostDate = null;
    }


    public void getUserPostFromServer(GetUserPostsLisenter callback, String devicesCode, String tag, Date date, int count){
        GetUserPostResponse getUserPostResponse = new GetUserPostResponse(callback);
        String format = QiniuUtil.DefaultImageThumbnailFormat();
        RequestWS.getInstance().getPostOperProxy().getLatestUserPosts(getUserPostResponse, devicesCode, tag, date, count, format);
    }

    //向下刷新帖子
    public void getOldestUserPost(GetUserPostsLisenter callback, String devicesCode, String tag, int count){
        initDate();
        GetFormerUserPostResponse getFormerUserPostResponse = new GetFormerUserPostResponse(callback);
        String format = QiniuUtil.DefaultImageThumbnailFormat();
        RequestWS.getInstance().getPostOperProxy().getFormerUserPosts(getFormerUserPostResponse, devicesCode, tag, mOldestUserPostDate, count, format);
    }

    //向上刷新帖子
    public void getLatestUserPost(GetUserPostsLisenter callback, String devicesCode, String tag, int count){
        initDate();
        getUserPostFromServer(callback, devicesCode, tag, mLastestUserPostDate, count);
    }


    private void initDate(){
        if(mLastestUserPostDate == null){
            mLastestUserPostDate = DateUtil.DatePlusDay(new Date(),1);
        }
        if(mOldestUserPostDate == null){
            mOldestUserPostDate = new Date();
        }
    }

    public void commitUserPost(final CommitUserPostListener callback,String sessionKey,String title,String content,ArrayList<String> tags, final ArrayList<String> images){

        publicdef.SeqString listString = new publicdef.SeqString(tags.toArray(new String[tags.size()]));

        gatemsg.SUserBrief userInfo = new gatemsg.SUserBrief();
        userInfo.userId = LocalInfoManager.getInstance(mContext).getUserId();
        userInfo.nickname = LocalInfoManager.getInstance(mContext).getNickName();
        userInfo.avatarUrl = LocalInfoManager.getInstance(mContext).getAvatarUrl();

        final gatemsg.SUserPost userPost = new gatemsg.SUserPost();
        userPost.postId = UUID.randomUUID().toString();
        userPost.userInfo  = userInfo;
        userPost.content = content;
        userPost.title = title;
        userPost.tags = listString;
        userPost.commentedTimes = 0;
        userPost.sharedTimes = 0;
        userPost.upvotedTimes = 0;


        //第二步：Server返回图片的相关信息，如，图片的token，用于托管图片
        ipostoper.IPostOper_commitUserPost_response response = new ipostoper.IPostOper_commitUserPost_response(){

            @Override
            public void onResponse(String postId, final gatemsg.SeqImageInfo seqImageInfo) {
                userPost.images = seqImageInfo;
                userPost.postId = postId;

                if(seqImageInfo.getArray().length != images.size()){
                    if(callback != null){
                        callback.failure("Server返回图片信息不正确!", 0);
                    }
                    return;
                }

                Log.v("Commit","第二步：Server返回图片的相关信息");

                //第四步：上传图片到托管服务器完毕后，通知Server图片上传成功，发布微说成功！
                QiniuUtil.UploadFileListListener uploadFileListCallback = new QiniuUtil.UploadFileListListener() {
                    @Override
                    public void success() {
                        Log.v("Commit", "第四步：上传图片到托管服务器完毕后，通知Server图片上传成功！");
                        String[] imageKeys = new String[seqImageInfo.getArray().length];
                        for (int i = 0; i< seqImageInfo.getArray().length; i++){
                            imageKeys[i] = seqImageInfo.getArray()[i].imageKey;
                        }
                        publicdef.SeqString seqString = new publicdef.SeqString(imageKeys);

                        DidImageUploadResponse didImageUploadResponse = new DidImageUploadResponse(userPost,callback);
                        RequestWS.getInstance().getPostOperProxy().didImageUpload(didImageUploadResponse, LocalInfoManager.getInstance(mContext).getSessionKey(),seqString);
                    }

                    @Override
                    public void failed() {
                        if(callback != null){
                            callback.failure("托管图片失败！",0);
                        }
                    }
                };


                //第三步：解析Server返回的图片信息，上传图片到托管服务器
                gatemsg.SImageInfo[] imageInfos = seqImageInfo.getArray();

                QiniuUtil.uploadFiles(imageInfos, images, uploadFileListCallback);
                Log.v("Commit", "第三步：解析Server返回的图片信息，上传图片到托管服务器");
            }

            @Override
            public void onError(String what, int code) {
               if(callback != null){
                   callback.failure(what,code);
               }
            }

            @Override
            public void onTimeout() {
                if(callback != null){
                    callback.failure("Time Out",0);
                }
            }
        };



        //第一步：上传帖子到Server，但只上传图片数量，而不上传图片
        RequestWS.getInstance().getPostOperProxy().commitUserPost(response,sessionKey,title,content,listString,images.size());
        Log.v("Commit","第一步：上传帖子到Server");
    }

    public void commitUserPostWithImageKeys(final CommitUserPostListener callback,String sessionKey,String title,String content,ArrayList<String> tags,final gatemsg.SeqImageInfo imageInfos){

        publicdef.SeqString listString = new publicdef.SeqString(tags.toArray(new String[tags.size()]));

        gatemsg.SUserBrief userInfo = new gatemsg.SUserBrief();
        userInfo.userId = LocalInfoManager.getInstance(mContext).getUserId();
        userInfo.nickname = LocalInfoManager.getInstance(mContext).getNickName();
        userInfo.avatarUrl = LocalInfoManager.getInstance(mContext).getAvatarUrl();

        final gatemsg.SUserPost userPost = new gatemsg.SUserPost();
        userPost.postId = UUID.randomUUID().toString();
        userPost.userInfo  = userInfo;
        userPost.content = content;
        userPost.title = title;
        userPost.tags = listString;
        userPost.commentedTimes = 0;
        userPost.sharedTimes = 0;
        userPost.upvotedTimes = 0;


        ipostoper.IPostOper_commitUserPost_response response = new ipostoper.IPostOper_commitUserPost_response(){

            @Override
            public void onResponse(String postId, final gatemsg.SeqImageInfo seqImageInfo) {

                userPost.images = imageInfos;
                userPost.postId = postId;
                addUserPost(userPost,0);
                if(callback != null){
                    callback.success();
                }
            }

            @Override
            public void onError(String what, int code) {
                if(callback != null){
                    callback.failure(what,code);
                }
            }

            @Override
            public void onTimeout() {
                if(callback != null){
                    callback.failure("Time Out",0);
                }
            }
        };

        RequestWS.getInstance().getPostOperProxy().commitUserPost(response,sessionKey,title,content,listString,0);
    }


    class DidImageUploadResponse extends ipostoper.IPostOper_didImageUpload_response{

        private gatemsg.SUserPost userPost;
        private CommitUserPostListener mCommitUserPostListener;

        public DidImageUploadResponse(gatemsg.SUserPost post,CommitUserPostListener callback){
            userPost = post;
            mCommitUserPostListener = callback;
        }

        @Override
        public void onResponse() {
            addUserPost(userPost,0);
            if(mCommitUserPostListener != null){
                mCommitUserPostListener.success();
            }
            Log.v("Commit", "第五步：服务端成功收到图片托管成功的消息，更新帖子！");
        }

        @Override
        public void onError(String what, int code) {
            if(mCommitUserPostListener != null){
                mCommitUserPostListener.failure(what,code);
            }
        }

        @Override
        public void onTimeout() {
            if(mCommitUserPostListener != null){
                mCommitUserPostListener.failure("TimeOut",0);
            }
        }
    }

    class GetFormerUserPostResponse extends ipostoper.IPostOper_getFormerUserPosts_response {

        private GetUserPostsLisenter mUserPostsLisenter;

        public GetFormerUserPostResponse(GetUserPostsLisenter userPostsLisenter){
            mUserPostsLisenter = userPostsLisenter;
        }

        @Override
        public void onResponse(gatemsg.SeqUserPost userPostList) {
            gatemsg.SUserPost[] userPosts = userPostList.getArray();
            addUserPosts(userPostList.getArray());
            sortSUserPosts();
            if(mUserPostsLisenter != null){
                mUserPostsLisenter.getUserPostsCallback(mUserPosts);
            }


            if(userPosts.length > 0){
                gatemsg.SUserPost lastestUserPost = userPosts[0];
                gatemsg.SUserPost oldestUserPost = userPosts[userPosts.length - 1];

                if(DateUtil.compareDate(lastestUserPost.createDt,mLastestUserPostDate) == 1){
                    mLastestUserPostDate = lastestUserPost.createDt;
                }

                if(DateUtil.compareDate(mOldestUserPostDate,oldestUserPost.createDt) == 1){
                    mOldestUserPostDate = oldestUserPost.createDt;
                }
            }
        }

        @Override
        public void onError(String what, int code) {
            Log.v("GetFormerUserPost","onError code " + code + ": " + what);
        }

        @Override
        public void onTimeout() {
            Log.v("GetFormerUserPost","onTimeout");
        }
    }

    class GetUserPostResponse extends ipostoper.IPostOper_getLatestUserPosts_response {
        private GetUserPostsLisenter mUserPostsLisenter;

        public GetUserPostResponse(GetUserPostsLisenter userPostsLisenter){
            mUserPostsLisenter = userPostsLisenter;
        }

        @Override
        public void onResponse(gatemsg.SeqUserPost userPostList) {
            gatemsg.SUserPost[] userPosts = userPostList.getArray();
            addUserPosts(userPostList.getArray());
            sortSUserPosts();
            if(mUserPostsLisenter != null){

                mUserPostsLisenter.getUserPostsCallback(mUserPosts);
            }


            if(userPosts.length > 0){
                gatemsg.SUserPost lastestUserPost = userPosts[0];
                gatemsg.SUserPost oldestUserPost = userPosts[userPosts.length - 1];

                if(DateUtil.compareDate(lastestUserPost.createDt,mLastestUserPostDate) == 1 || mIsFirstRequestLastestUserPost){
                    mLastestUserPostDate = lastestUserPost.createDt;
                    mIsFirstRequestLastestUserPost = false;
                }

                if(DateUtil.compareDate(mOldestUserPostDate,oldestUserPost.createDt) == 1){
                    mOldestUserPostDate = oldestUserPost.createDt;
                }
            }
            Log.v("GetUserPostResponse",userPostList.getArray().length+"----------");
        }

        @Override
        public void onError(String what, int code) {
            Log.v("GetUserPostResponse","onError code " + code + ": " + what);
        }

        @Override
        public void onTimeout() {
            Log.v("GetUserPostResponse","onTimeout");
        }
    }
}
