package com.guiyi.egui.customwidget;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.ImageView;

/**
 * Created by Administrator on 2015/9/8.
 */
public class FitImageView extends ImageView {
    private Bitmap mBitmap;
    private int mBitmapWidth;
    private int mBitmapHeight;

    private boolean mReady;
    private boolean mSetupPending;

    public FitImageView(Context context) {
        super(context);
        init();
    }

    public FitImageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public FitImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        mReady = true;

        if (mSetupPending) {
            setup();
            mSetupPending = false;
        }
    }

    private void reSize() {
        int width = getResources().getDisplayMetrics().widthPixels;
        int height = (int) (getResources().getDisplayMetrics().heightPixels);
        int imgH = mBitmapHeight;
        int imgW = mBitmapWidth;
        int lastH = imgH;
        int lastW = imgW;
        double radio = 1.0;
        radio = (width * 1.0) / imgW;
        if (imgH * radio > height) {
            radio = (height * 1.0) / imgH;
        }
        lastH = (int) (radio * imgH);
        lastW = (int) (radio * imgW);
        ViewGroup.LayoutParams lp = this.getLayoutParams();
        lp.width = lastW;
        lp.height = lastH;
        this.setLayoutParams(lp);
    }

    @Override
    public void setImageBitmap(Bitmap bm) {
        super.setImageBitmap(bm);
        mBitmap = bm;
        setup();
        reSize();
    }

    private void setup() {
        if (!mReady) {
            mSetupPending = true;
            return;
        }

        if (mBitmap == null) {
            return;
        }

        mBitmapHeight = mBitmap.getHeight();
        mBitmapWidth = mBitmap.getWidth();

        invalidate();
    }

}
