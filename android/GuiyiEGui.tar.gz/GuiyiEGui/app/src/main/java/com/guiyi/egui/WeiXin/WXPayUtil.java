package com.guiyi.egui.WeiXin;

import android.content.Context;

import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

import java.util.Random;

/**
 * Created by ForOne on 15/9/9.
 */
public class WXPayUtil {

    private Context mContext;
    private IWXAPI mWXApi;

    public WXPayUtil(Context context) {
        mContext = context;
        mWXApi = WXAPIFactory.createWXAPI(context, null);
    }

    /**提交订单到后台服务器，通过后台生成订单，并返回prepay_id,sign等信息
     * @param tradeBody 商品描述
     * @param tradeDetail 商品详情
     * @param tradeAttach 商品附加信息
     * @param tradeNO 交易ID
     * @param totalFee 总金额
     * @param ip  APP的IP
     * @param tradeType 交易类型 APP
     */
    public void commitPrepay(String tradeBody,String tradeDetail,String tradeAttach,String tradeNO,String totalFee,String ip,String tradeType){

    }

    /**通过后台返回的perpay_id,sign等信息，调用微信进行支付
     * @param prepayId
     * @param sign
     */
    public void WXPay(String prepayId,String sign){
        PayReq request = new PayReq();
        request.appId = Constants.APP_ID;
        request.partnerId = Constants.MCH_ID;
        request.prepayId = prepayId;
        request.packageValue = Constants.PACKAGE_VALUE;
        request.nonceStr = genNonceStr();
        request.timeStamp = String.valueOf(genTimeStamp());
        request.sign = sign;
        mWXApi.registerApp(Constants.APP_ID);
        mWXApi.sendReq(request);
    }

    private String genNonceStr() {
        Random random = new Random();
        return MD5.getMessageDigest(String.valueOf(random.nextInt(10000)).getBytes());
    }

    private long genTimeStamp() {
        return System.currentTimeMillis() / 1000;
    }
}
