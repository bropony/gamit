package com.guiyi.egui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Listener.GetUserPostsLisenter;
import com.guiyi.egui.Managers.UserPostsManager;
import com.guiyi.egui.R;
import com.guiyi.egui.activity.personal.LoginActivity;
import com.guiyi.egui.activity.social.UserPostReplyNewMessageActivity;
import com.guiyi.egui.activity.social.PublishUserPostActivity;
import com.guiyi.egui.activity.social.UserPostDetailActivity;
import com.guiyi.egui.adapter.UserPostAdapter;

import com.guiyi.egui.customwidget.CircleImageView;
import com.guiyi.egui.customwidget.XListView.XListView;
import com.guiyi.egui.events.RefreshUserPostsEvent;
import com.guiyi.egui.util.CommonUtil;
import com.jenwis.android.base.base.util.LogUtils;
import com.jenwis.android.base.ui.BaseFragment;

import java.util.ArrayList;

import de.greenrobot.event.EventBus;
import message.gate.gatemsg;


/**
 * Created by C on 2015/8/7.
 */
public class FriendsFragment extends BaseFragment implements View.OnClickListener, RadioGroup.OnCheckedChangeListener, XListView.IXListViewListener {

    public static String USER_POST_ID = "com.guiyi.userposetid";

    private RadioGroup mHeaderTabRadioButton;
    private RadioGroup mTabRadioButton;
    private RelativeLayout mPublishTalkRelativeLayout;
    private XListView mFriendsListView;
    private View mContentView;
    private LinearLayout mHeader;
    private RelativeLayout mAction;
    private TextView mNewMessageTextView;
    private ArrayList<gatemsg.SUserPost> mUserPosts;
    UserPostAdapter mAdapter;
    private CircleImageView mIconImageView;
    private int mLoginRequestCode = 2;

    GetUserPostsLisenter mUserPostsListener = new GetUserPostsLisenter() {
        @Override
        public void getUserPostsCallback(ArrayList<gatemsg.SUserPost> userPosts) {
            refresUserPost(userPosts);

        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventBus.getDefault().register(this);
        mAdapter = new UserPostAdapter(getActivity());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mContentView = inflater.inflate(R.layout.fragment_friends, container, false);
        super.onCreateView(inflater, container, savedInstanceState);

        onRefresh();
        return mContentView;

    }

    @Override
    public void onResume() {
        super.onResume();
        Log.v("Fragment", "onResume");
    }

    @Override
    public void init() {
        //添加头部内容
        mHeader = (LinearLayout) View.inflate(getActivity(), R.layout.friends_stick_header, null);
        mAction = (RelativeLayout) View.inflate(getActivity(), R.layout.friends_stick_action, null);
        mUserPosts = new ArrayList();

    }


    @Override
    public void findView() {
        mPublishTalkRelativeLayout = (RelativeLayout) mContentView.findViewById(R.id.pub_comment_relative_layout);
        mFriendsListView = (XListView) mContentView.findViewById(R.id.friends_lv);
        mNewMessageTextView = (TextView) mAction.findViewById(R.id.new_message_text_view);
        mIconImageView = (CircleImageView) mContentView.findViewById(R.id.portrait_image_view);
    }

    @Override
    public void setView() {
        mFriendsListView.addHeaderView(mHeader);
        mFriendsListView.addHeaderView(mAction);
        mTabRadioButton = (RadioGroup) mContentView.findViewById(R.id.tab_radioGroup);
        mHeaderTabRadioButton = (RadioGroup) mAction.findViewById(R.id.tab_header_radioGroup);
        mFriendsListView.setPullLoadEnable(true);
        mFriendsListView.setPullRefreshEnable(true);
        mAdapter.setUserPost(mUserPosts.toArray(new gatemsg.SUserPost[mUserPosts.size()]));
        mFriendsListView.setAdapter(mAdapter);
    }

    @Override
    public void setViewListener() {
        mNewMessageTextView.setOnClickListener(this);
//        mIconImageView.setOnClickListener(this);
        mPublishTalkRelativeLayout.setOnClickListener(this);
        mTabRadioButton.setOnCheckedChangeListener(this);
        mHeaderTabRadioButton.setOnCheckedChangeListener(this);
        mFriendsListView.setXListViewListener(this);
        {

            mFriendsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    int index = i - 3;
                    if (mUserPosts.size() >= index) {
                        String userPostId = mUserPosts.get(index).postId;
                        Intent intent = new Intent(getActivity(), UserPostDetailActivity.class);
                        intent.putExtra(USER_POST_ID, userPostId);
                        startActivity(intent);
                    }
                }
            });
            mFriendsListView.setOnScrollListener(new AbsListView.OnScrollListener() {

                @Override
                public void onScrollStateChanged(AbsListView view, int scrollState) {

                }

                @Override
                public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                    if (firstVisibleItem >= 2) {
                        mTabRadioButton.setVisibility(View.VISIBLE);
                    } else {

                        mTabRadioButton.setVisibility(View.GONE);
                    }
                }
            });
        }
    }


    @Override
    public void onPageSelected() {

    }

    @Override
    public void onPageDisSelected() {

    }

    @Override
    public void onDataChange(int type, Object obj) {

    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        //Fragment通过add的方法添加，hide与show时不会走生命周期，会调用onHiddenChanged，用replace时，会走生命周期
        if (!hidden) {
//           requestUserPosts();
            onRefresh();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.pub_comment_relative_layout:
                if (CommonUtil.IsLogined) {
                    Intent intent = new Intent(getActivity(), PublishUserPostActivity.class);
                    startActivity(intent);
                } else {
                    login();
                }

                break;
            case R.id.new_message_text_view:
                Intent newMessageIntent = new Intent(getActivity(), UserPostReplyNewMessageActivity.class);
                startActivity(newMessageIntent);
                Toast.makeText(getActivity(), "对接过后，判断该按钮的显示和隐藏,暂时显示", Toast.LENGTH_LONG).show();
                break;
            case R.id.portrait_image_view:
                //TODO 点击头像跳转，查看个人信息
                break;
            default:
                break;
        }
    }

    private void login() {
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        startActivityForResult(intent, mLoginRequestCode);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.one_btn:
                Toast.makeText(getActivity(), "1", Toast.LENGTH_SHORT).show();
                break;
            case R.id.two_btn:
                Toast.makeText(getActivity(), "2", Toast.LENGTH_SHORT).show();
                break;
            case R.id.three_btn:
                Toast.makeText(getActivity(), "3", Toast.LENGTH_SHORT).show();
                break;
            case R.id.four_btn:
                Toast.makeText(getActivity(), "4", Toast.LENGTH_SHORT).show();
                break;
            default:
                break;
        }
    }

    //不要修改函数名以及参数，EventBus回调用
    public void onEventMainThread(RefreshUserPostsEvent refreshUserPostsEvent) {
        if (refreshUserPostsEvent.UserPosts != null) {
            refresUserPost(refreshUserPostsEvent.UserPosts);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    private void refresUserPost(ArrayList<gatemsg.SUserPost> userPosts) {
        mUserPosts = userPosts;
        updateTopicsListView();

    }

    private void requestUserPosts() {
        UserPostsManager.getInstance(getActivity()).getLatestUserPost(mUserPostsListener, CommonUtil.getDeviceCode(getActivity()), "", 20);
        Log.v("Topic", "requestUserPosts");
    }

    private void updateTopicsListView() {
        mAdapter.setUserPost(mUserPosts.toArray(new gatemsg.SUserPost[mUserPosts.size()]));
        mAdapter.notifyDataSetChanged();

    }

    @Override
    public void onRefresh() {
        requestUserPosts();
        onLoad();

    }

    @Override
    public void onLoadMore() {
        UserPostsManager.getInstance(getActivity()).getOldestUserPost(mUserPostsListener, CommonUtil.getDeviceCode(getActivity()), "", 20);
        onLoad();
    }

    private void onLoad() {
        mFriendsListView.stopRefresh();
        mFriendsListView.stopLoadMore();
        mFriendsListView.setRefreshTime("刚刚");
    }
}
