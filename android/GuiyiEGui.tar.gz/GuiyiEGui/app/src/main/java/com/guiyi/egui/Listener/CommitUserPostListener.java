package com.guiyi.egui.Listener;

/**
 * Created by ForOne on 15/8/21.
 */
public interface CommitUserPostListener {
    void success();
    void failure(String what,int code);
}
