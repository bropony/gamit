package com.guiyi.egui.Managers;

/**
 * Created by ForOne on 15/8/27.
 */
public class UserFansManager {

    private static UserFansManager mUserFansManager;

    public UserFansManager getInstance(){
        if(mUserFansManager == null){
            mUserFansManager = new UserFansManager();
        }
        return mUserFansManager;
    }

    public void getUserFans(){

    }
}
