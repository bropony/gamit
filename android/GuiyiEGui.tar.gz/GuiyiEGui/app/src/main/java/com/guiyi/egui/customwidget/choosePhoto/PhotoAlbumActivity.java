package com.guiyi.egui.customwidget.choosePhoto;

import java.io.Serializable;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.TextView;

import com.guiyi.egui.Managers.ImageBucket;
import com.guiyi.egui.R;
import com.guiyi.egui.activity.social.PublishUserPostActivity;
import com.guiyi.egui.adapter.ImageBucketAdapter;
import com.guiyi.egui.util.AlbumHelper;

public class PhotoAlbumActivity extends Activity {
	List<ImageBucket> dataList;
	GridView gridView;
	ImageBucketAdapter adapter;// 自定义的适配器
	AlbumHelper helper;
	public static final String EXTRA_IMAGE_LIST = "imagelist";
	public static Bitmap mBitmap
			;
	private TextView mBackTextView;
	private TextView mTitleTextView;

	public final static int REQUEST_CODE = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_image_bucket);

		helper = AlbumHelper.getHelper();
		helper.init(getApplicationContext());

		initData();
		initView();
	}

	/**
	 * 初始化数据
	 */
	private void initData() {
		dataList = helper.getImagesBucketList(false);
		mBitmap =BitmapFactory.decodeResource(
				getResources(),
				R.drawable.icon_addpic_unfocused);
	}

	/**
	 * 初始化view视图
	 */
	private void initView() {
		mTitleTextView= (TextView) findViewById(R.id.title_tv);
		mTitleTextView.setText(R.string.action_bar_title_select_album);
		mBackTextView= (TextView) findViewById(R.id.back_tv);
		gridView = (GridView) findViewById(R.id.gridview);
		adapter = new ImageBucketAdapter(PhotoAlbumActivity.this, dataList);
		gridView.setAdapter(adapter);

		gridView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
									int position, long id) {

				/**
				 * 通知适配器，绑定的数据发生了改变，应当刷新视图
				 */
				Intent intent = new Intent(
						PhotoAlbumActivity.this,
						ImageGridActivity.class);
				intent.putExtra(PhotoAlbumActivity.EXTRA_IMAGE_LIST,
						(Serializable) dataList.get(position).imageList);
				startActivityForResult(intent,REQUEST_CODE);
			}

		});
		mBackTextView.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				finish();
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode == REQUEST_CODE){
			Bundle bundle = data.getExtras();
			Intent intent = new Intent(PhotoAlbumActivity.this,
					PublishUserPostActivity.class);
			intent.putExtras(bundle);
			setResult(requestCode, intent);
			finish();
		}
	}
}
