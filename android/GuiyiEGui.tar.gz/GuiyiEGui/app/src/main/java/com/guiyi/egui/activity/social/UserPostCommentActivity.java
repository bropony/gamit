package com.guiyi.egui.activity.social;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Dialog.ExpressionDialog;
import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.R;
import com.guiyi.egui.customwidget.CustomEditText.CustomEditText;
import com.guiyi.egui.util.StringUtil;
import com.guiyi.egui.websocket.RequestWS;
import com.jenwis.android.base.base.util.LogUtils;
import com.jenwis.android.base.ui.BaseActivity;

import message.gate.ipostoper;

/**
 * Created by Administrator on 2015/8/25.
 */
public class UserPostCommentActivity extends BaseActivity implements View.OnClickListener{
    private TextView mBackTextView;
    private TextView mTitleTextView;
    private TextView mSendTextView;
    private TextView mAddExpressionTextView;
    private CustomEditText mCommentEditText;
    private String mPostId;
    private String mComment;
    private static final int CONTENT_MAX_LENGTH = 200;
    private TextView mContentlengthTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_user_post_comment);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {
        Intent intent = getIntent();
        mPostId=intent.getStringExtra("POST_ID");
    }

    @Override
    public void findView() {
        mBackTextView= (TextView) findViewById(R.id.back_tv);
        mTitleTextView = (TextView) findViewById(R.id.title_tv);
        mSendTextView = (TextView) findViewById(R.id.right_text_view);
        mCommentEditText= (CustomEditText) findViewById(R.id.comment_edit_text);
        mAddExpressionTextView = (TextView)findViewById(R.id.add_expression_text_view);
        mContentlengthTextView= (TextView) findViewById(R.id.word_num_text_view);
    }

    @Override
    public void setView() {
        mTitleTextView.setText(R.string.action_bar_title_comment);
        mSendTextView.setVisibility(View.VISIBLE);
        mSendTextView.setText(R.string.action_bar_right_text_send);
        mCommentEditText.addTextChangedListener(new TextWatcher() {

            String text = "";

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                Editable editable = mCommentEditText.getText();
                String content = editable.toString();

                int length = StringUtil.getLengthOfGb2312(content);
                if (length > CONTENT_MAX_LENGTH) {
                    mCommentEditText.setText(text);
                }
                text = mCommentEditText.getText().toString();
                mContentlengthTextView.setText(StringUtil.getLengthOfGb2312(text) + "/" + CONTENT_MAX_LENGTH);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    @Override
    public void setViewListener() {
        mBackTextView.setOnClickListener(this);
        mSendTextView.setOnClickListener(this);
        mAddExpressionTextView.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back_tv:
                if ((mCommentEditText.getText().toString()).equals("")){
                    finish();
                }else {
                    dialog();
                }
                break;
            case R.id.right_text_view:
                commitComment();
                break;

            case R.id.add_expression_text_view:
                addExpression();
                break;
        }
    }
    protected void dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(UserPostCommentActivity.this);
        builder.setTitle("退出此次编辑");
        builder.setCancelable(true);
        builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                UserPostCommentActivity.this.finish();
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            if ((mCommentEditText.getText().toString()).equals("")){
                finish();
            }else {
                dialog();
            }
        }
        return false;
    }

    ExpressionDialog.ExpressionDialogListener addExpressionCallback = new ExpressionDialog.ExpressionDialogListener() {
        @Override
        public void result(String value) {
            String text = mCommentEditText.getText().toString();
            mCommentEditText.setText(text + value);
        }
    };

    private void addExpression(){
        ExpressionDialog dialog = new ExpressionDialog(this,addExpressionCallback);
    }

    private void commitComment() {
        mComment=mCommentEditText.getText().toString();
        if(mComment == null || mComment.equals("")){
            Toast.makeText(this, "评论不能为空！", Toast.LENGTH_SHORT).show();
            return;
        }
        CommitUserPostCommentResponse commitUserPostComment = new CommitUserPostCommentResponse();
        RequestWS.getInstance().getPostOperProxy().commentUserPost(commitUserPostComment, LocalInfoManager.getInstance(this).getSessionKey(), mPostId, mComment);
    }

    class CommitUserPostCommentResponse extends ipostoper.IPostOper_commentUserPost_response {

        @Override
        public void onResponse(String commentId) {
            commitCommentSuccess();

        }

        @Override
        public void onError(String what, int code) {
            commitCommentFailed("Code:" + code + " what:" + what);
            LogUtils.LogD("tag","Code:" + code + " what:" + what);
        }

        @Override
        public void onTimeout() {
            commitCommentFailed("TimeOut");
        }
    }
    private void commitCommentSuccess(){
        Toast.makeText(this,"提交评论成功!",Toast.LENGTH_SHORT).show();
        Intent intent = new Intent();
        intent.putExtra("COMMENT_CONTENT",mComment);
        setResult(RESULT_OK,intent);
        finish();
    }

    private void commitCommentFailed(String error){
        Toast.makeText(this, "提交评论失败：" + error, Toast.LENGTH_SHORT).show();
    }

}
