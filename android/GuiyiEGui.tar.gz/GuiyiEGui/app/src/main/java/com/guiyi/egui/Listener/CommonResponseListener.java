package com.guiyi.egui.Listener;

/**
 * Created by ForOne on 15/9/10.
 */
public interface CommonResponseListener {
    void success();
    void failure(String what,int code);
}
