package com.guiyi.egui.Listener;

/**
 * Created by ForOne on 15/8/25.
 */
public interface ChooseImageOperateListener {
    void chooseCamera();

    void choosePhoto();

    void cancel();

}
