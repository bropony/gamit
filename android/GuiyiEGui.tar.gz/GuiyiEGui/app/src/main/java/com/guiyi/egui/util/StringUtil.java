package com.guiyi.egui.util;

import java.io.UnsupportedEncodingException;

/**
 * Created by ForOne on 15/8/31.
 */
public class StringUtil {
    public static int getLengthOfGb2312(String source){
        try {
            return source.getBytes("gb2312").length;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
