package com.guiyi.egui.activity.customize;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.jenwis.android.base.ui.BaseActivity;

/**
 * Created by rentianlong on 2015/9/9.14:25
 * <p/>
 * company GDGY
 */
public class CustomizeActivity extends BaseActivity implements View.OnClickListener {
    private TextView mTitle;
    private TextView mBack;
    private RelativeLayout mTuwenCustomize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_custonzie);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mTitle = (TextView) findViewById(R.id.title_tv);
        mBack = (TextView) findViewById(R.id.back_tv);
        mTuwenCustomize = (RelativeLayout) findViewById(R.id.id_rl_tuwen_customize);
    }

    @Override
    public void setView() {
        mTitle.setText(R.string.str_title_customize);
        mBack.setVisibility(View.VISIBLE);
    }

    @Override
    public void setViewListener() {
        mTuwenCustomize.setOnClickListener(this);
        mBack.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.id_rl_tuwen_customize:
                Intent intent = new Intent(this, PublishDesignActivity.class);
                startActivity(intent);
                break;
            case R.id.back_tv:
                this.finish();
                break;
            default:
                break;
        }
    }
}
