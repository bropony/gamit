package com.guiyi.egui.util;

import android.os.Handler;
import android.os.Looper;

/**
 *Created by ForOne on 15/8/20.
 */
public final class AsyncRunUtil {
    public static void run(Runnable r) {
        Handler h = new Handler(Looper.getMainLooper());
        h.post(r);
    }
}
