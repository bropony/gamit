package com.guiyi.egui.Dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.SimpleAdapter;

import com.guiyi.egui.R;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ForOne on 15/8/26.
 */
public class ExpressionDialog {
    private Dialog builder;

    private int[] imageIds = new int[107];
    private Context mContext;
    private ExpressionDialogListener mExpressionDialogListener;

    public ExpressionDialog(Context context, ExpressionDialogListener callback){
        mContext = context;
        mExpressionDialogListener = callback;
        createExpressionDialog();
    }
    /**
     * 创建一个表情选择对话框
     */
    private void createExpressionDialog() {
        builder = new Dialog(mContext);
        GridView gridView = createGridView();
        builder.setContentView(gridView);
        builder.setTitle("默认表情");
        WindowManager.LayoutParams lp=builder.getWindow().getAttributes();
        WindowManager windowManager = builder.getWindow().getWindowManager();
        Display display = windowManager.getDefaultDisplay();

        lp.width = (int) (display.getHeight()*0.5);
        lp.height = (int) (display.getWidth()*0.8);
        lp.alpha = 0.7f;
        builder.getWindow().setAttributes(lp);
        builder.show();
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position,
                                    long arg3) {
                String value = null;
                if(position < 10){
                    value = "f00" + position;
                }else if(position < 100){
                    value = "f0" + position;
                }else{
                    value = "f" + position;
                }
                if(mExpressionDialogListener != null){
                    mExpressionDialogListener.result(value);
                }
                builder.dismiss();
            }
        });
    }


    /**
     * 生成一个表情对话框中的gridview
     * @return
     */
    private GridView createGridView() {
        final GridView view = new GridView(mContext);
        List<Map<String,Object>> listItems = new ArrayList<Map<String,Object>>();

        for(int i = 0; i < imageIds.length; i++){
            try {
                if(i<10){
                    Field field = R.drawable.class.getDeclaredField("f00" + i);
                    int resourceId = Integer.parseInt(field.get(null).toString());
                    imageIds[i] = resourceId;
                }else if(i<100){
                    Field field = R.drawable.class.getDeclaredField("f0" + i);
                    int resourceId = Integer.parseInt(field.get(null).toString());
                    imageIds[i] = resourceId;
                }else{
                    Field field = R.drawable.class.getDeclaredField("f" + i);
                    int resourceId = Integer.parseInt(field.get(null).toString());
                    imageIds[i] = resourceId;
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            } catch (SecurityException e) {
                e.printStackTrace();
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            Map<String,Object> listItem = new HashMap<String,Object>();
            listItem.put("image", imageIds[i]);
            listItems.add(listItem);
        }

        SimpleAdapter simpleAdapter = new SimpleAdapter(mContext, listItems, R.layout.expression_dialog_grid_view_cell, new String[]{"image"}, new int[]{R.id.image});
        view.setAdapter(simpleAdapter);
        view.setNumColumns(6);
        view.setBackgroundColor(Color.rgb(214, 211, 214));
        view.setHorizontalSpacing(1);
        view.setVerticalSpacing(1);
        view.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        view.setGravity(Gravity.CENTER);
        return view;
    }

    public interface ExpressionDialogListener{
        void result(String value);
    }

}
