package com.guiyi.egui.events;

/**
 * Created by ForOne on 15/9/2.
 */
public class LocationChangedEvent {
    public String CityName;
}
