package com.guiyi.egui.logic.util;

/**
 * Created by zhengyuji on 15/8/4.
 */
public class ResponseCodeHelper {
    //public static int CODE_

}
