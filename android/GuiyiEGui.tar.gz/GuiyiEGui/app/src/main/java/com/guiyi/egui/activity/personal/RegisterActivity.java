package com.guiyi.egui.activity.personal;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.R;
import com.guiyi.egui.activity.MainActivity;
import com.guiyi.egui.logic.account.AccountLogic;
import com.guiyi.egui.logic.config.SharedPreferenceConfig;
import com.guiyi.egui.util.CommonUtil;

import message.common.publicdef;
import message.gate.gatemsg;
import message.gate.ilogin;

import com.guiyi.egui.util.SharePrefUtil;
import com.guiyi.egui.websocket.RequestWS;
import com.jenwis.android.base.base.util.LogUtils;
import com.jenwis.android.base.ui.BaseActionBarActivity;


/**
 * Created by C on 2015/8/8.
 */
public class RegisterActivity extends BaseActionBarActivity implements View.OnClickListener {
    private EditText mPhoneNumberEditText;
    private EditText mPassWordEditText;
    private EditText mCheckCodeEditText;
    private EditText mInviteCodeEditText;
    private String mPhoneNumber;
    private String mPassWord;
    private String mCheckCode;
    private String mInviteCode;
    private TextView back;
    private TextView mSwitchTextView;
    private TextView mGetCodeTextView;
    private TextView mCheckBoxTextView;
    private TextView mTitle;
    private boolean mSwitch = false, mCheckBox = false;
    private Button mRegisterButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_register);
        super.onCreate(savedInstanceState);


    }

    @Override
    public void init() {
    }

    @Override
    public void findView() {
        mTitle = (TextView) findViewById(R.id.title_tv);
        back = (TextView) findViewById(R.id.back_tv);
        back.setOnClickListener(this);
        mSwitchTextView = (TextView) findViewById(R.id.switch_btn);
        mGetCodeTextView = (TextView) findViewById(R.id.getCode_tv);
        mCheckBoxTextView = (TextView) findViewById(R.id.check_tv);
        mPhoneNumberEditText = (EditText) findViewById(R.id.phoneNum_et);
        mPassWordEditText = (EditText) findViewById(R.id.pwd_et);

        mCheckCodeEditText = (EditText) findViewById(R.id.phoneCode_et);

        mInviteCodeEditText = (EditText) findViewById(R.id.code_et);

        mRegisterButton = (Button) findViewById(R.id.register_btn);
    }

    @Override
    public void setView() {
        mTitle.setText("手机快速注册");
    }

    @Override
    public void setViewListener() {
        mSwitchTextView.setOnClickListener(this);
        mGetCodeTextView.setOnClickListener(this);
        mCheckBoxTextView.setOnClickListener(this);
        mRegisterButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_tv:
                finish();
                break;
            case R.id.register_btn:
                register();
                break;
            case R.id.switch_btn:
                if (mSwitch == false) {
                    mSwitchTextView.setBackgroundResource(R.drawable.box_b);
                    mPassWordEditText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    mSwitch = true;
                } else {
                    mSwitchTextView.setBackgroundResource(R.drawable.box_a);
                    mPassWordEditText.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    mSwitch = false;
                }
                break;
            case R.id.getCode_tv:
                getCode();
                break;
            case R.id.check_tv:
                if (mCheckBox == false) {
                    mCheckBoxTextView.setBackgroundResource(R.drawable.right_b);
                    mCheckBox = true;

                } else {
                    mCheckBoxTextView.setBackgroundResource(R.drawable.right_a);
                    mCheckBox = false;
                }
                break;
            default:
                break;
        }
    }

    //验证码倒计时
    private CountDownTimer timer = new CountDownTimer(61000, 1000) {

        @Override
        public void onTick(long millisUntilFinished) {
            mGetCodeTextView.setText("重发(" + (millisUntilFinished / 1000) + "s)");
            mGetCodeTextView.setClickable(false);
        }

        @Override
        public void onFinish() {
//            code.setEnabled(true);
            mGetCodeTextView.setClickable(true);
            mGetCodeTextView.setText("点击重发");
        }
    };

    //获取验证码
    private void getCode() {
        mPhoneNumber = mPhoneNumberEditText.getText().toString().trim();
        if (TextUtils.isEmpty(mPhoneNumber)) {
            Toast.makeText(this, "手机号码必填", Toast.LENGTH_SHORT).show();
            return;
        } else if (!AccountLogic.isCellPhoneNumber(mPhoneNumber)) {
            Toast.makeText(this, "输入的手机号码格式错误", Toast.LENGTH_SHORT).show();
            return;
        }
        timer.start();

        ILoginGetPhoneSingupValidationCode response = new ILoginGetPhoneSingupValidationCode();
        RequestWS.getInstance().getILoginProxy().getPhoneSignupValidationCode(response, CommonUtil.getDeviceCode(this), mPhoneNumber);

    }

    class ILoginGetPhoneSingupValidationCode extends ilogin.ILogin_getPhoneSignupValidationCode_response {

        @Override
        public void onResponse() {
            LogUtils.LogD("tag", "onResponse");
        }

        @Override
        public void onError(String what, int code) {
            LogUtils.LogD("tag", "onResponse");
        }

        @Override
        public void onTimeout() {
            LogUtils.LogD("tag", "onTimeout");
        }
    }

    //注册
    private void register() {
        mPassWord = mPassWordEditText.getText().toString().trim();
        mPhoneNumber = mPhoneNumberEditText.getText().toString().trim();
        LocalInfoManager.getInstance(this).setAccount(mPhoneNumber);
//        验证码、邀请码
        mCheckCode = mCheckCodeEditText.getText().toString().trim();
//        inviteCode=itCode.getText().toString().trim();
        LogUtils.LogD("tag", mCheckCode);
        if (TextUtils.isEmpty(mPhoneNumber)) {
            Toast.makeText(this, "手机号码必填", Toast.LENGTH_SHORT).show();
            return;
        } else if (!AccountLogic.isCellPhoneNumber(mPhoneNumber)) {
            Toast.makeText(this, "输入的手机号码格式错误", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(mPassWord)) {
            Toast.makeText(this, "密码必填", Toast.LENGTH_SHORT).show();
            return;
        } else if (!AccountLogic.isPasswordLegal(mPassWord)) {
            Toast.makeText(this, "输入的密码格式错误", Toast.LENGTH_SHORT).show();
            return;
        }
        //TODO 开放验证码
//        if (TextUtils.isEmpty(mCheckCode)){
//            Toast.makeText(this,"验证码不能为空",Toast.LENGTH_SHORT).show();
//            return;
//        }
        if (mCheckBox == false) {
            Toast.makeText(this, "请阅读，并同意我的E柜用户注册协议", Toast.LENGTH_SHORT).show();
            return;
        }
        if (0 == CommonUtil.isNetworkAvailable(this)) {
            Toast.makeText(this, "无网络链接，请检查网络", Toast.LENGTH_SHORT).show();
            return;
        } else {
            ILoginSignupResponse response = new ILoginSignupResponse(this);
            gatemsg.SSignup signupInfo = new gatemsg.SSignup();
            signupInfo.deviceCode = CommonUtil.getDeviceCode(this);
            signupInfo.loginType = publicdef.ELoginType.MobilePhoneNum;
            signupInfo.account = mPhoneNumber;
            signupInfo.password = mPassWord;
            signupInfo.validationCode = mCheckCode;
            Log.v("register", "Signup");
            RequestWS.getInstance().getILoginProxy().signup(response, signupInfo);
            SharePrefUtil.saveString(this, SharedPreferenceConfig.account, mPhoneNumber);
        }
    }

    class ILoginSignupResponse extends ilogin.ILogin_signup_response {
        private Context ct;

        public ILoginSignupResponse(Context context) {
            super();
            this.ct = context;
        }

        @Override
        public void onResponse(gatemsg.SLoginReturn signupRes) {
            Log.v("register", "onResponse");
            LocalInfoManager.getInstance(RegisterActivity.this).setNickName(signupRes.nickname);
            LocalInfoManager.getInstance(RegisterActivity.this).setSessionKey(signupRes.sessionKey);
            LocalInfoManager.getInstance(RegisterActivity.this).setUserId(signupRes.userId);
            LocalInfoManager.getInstance(RegisterActivity.this).setBirthday(signupRes.birthday);

            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
            Toast.makeText(ct, "注册成功", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(String what, int code) {

            Toast.makeText(ct, what, Toast.LENGTH_SHORT).show();
            Log.v("register", "onError");
            Log.v("register", "what:" + what + "code:" + code);
            LogUtils.LogD("tag", "what:" + what + "code:" + code);
        }


        @Override
        public void onTimeout() {
            Log.v("register", "onTimeout");
            LogUtils.LogD("tag", "onTimeout");
            Toast.makeText(ct, R.string.toast_time_out, Toast.LENGTH_SHORT).show();
        }

    }
}

