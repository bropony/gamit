package com.guiyi.egui.events;

/**
 * Created by ForOne on 15/9/3.
 */
public class SystemTopicStatusChangedEvent {
    public String SystemTopicId;
    public int CommentCount;
    public int UpvoteCount;
    public int ShareCount;
    public int VisitCount;
}
