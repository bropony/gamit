package com.guiyi.egui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.guiyi.egui.customwidget.CircleImageView;
import com.guiyi.egui.customwidget.CustomTextView.CustomTextView;
import com.guiyi.egui.util.DateUtil;
import com.guiyi.egui.util.ImageLoaderUtil;

import java.util.ArrayList;

import message.gate.gatemsg;

/**
 * Created by Administrator on 2015/9/6.
 */
public class HomeTopicCommentListViewAdapter extends BaseAdapter {
    private LayoutInflater mInflater;
    private Context mContext;
    private ArrayList<gatemsg.SComment> mCommentList = new ArrayList<>();

    public HomeTopicCommentListViewAdapter(Context context,ArrayList<gatemsg.SComment> commentList){
        mContext = context;
        mInflater = LayoutInflater.from(context);
        mCommentList = commentList;
    }

    @Override
    public int getCount() {
        return mCommentList.size();
    }

    @Override
    public Object getItem(int position) {
        return mCommentList.get(position);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;

        if(view == null){
            view = mInflater.inflate(R.layout.item_home_topics_comment_list_view,null);
            viewHolder = new ViewHolder();
            viewHolder.userIcon= (CircleImageView) view.findViewById(R.id.comment_person_icon_imageview);
            viewHolder.userNickName= (TextView) view.findViewById(R.id.user_nickname__text_view);
            viewHolder.commentTime= (TextView) view.findViewById(R.id.comment_time_text_view);
            viewHolder.ContentTextView= (CustomTextView) view.findViewById(R.id.comment_content_text_view);
            view.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)view.getTag();
        }

        gatemsg.SComment comment = mCommentList.get(position);
        viewHolder.userNickName.setText(comment.commenterInfo.nickname);
        viewHolder.commentTime.setText(DateUtil.getDateIntervelTimeStringToNow(comment.commentDt));
        viewHolder.ContentTextView.setText(comment.comment);
        ImageLoaderUtil.displayImage(comment.commenterInfo.avatarUrl,viewHolder.userIcon);
        return view;
    }

    final class ViewHolder{
        public CircleImageView userIcon;
        public TextView userNickName;
        public TextView commentTime;
        public CustomTextView ContentTextView;
    }
}
