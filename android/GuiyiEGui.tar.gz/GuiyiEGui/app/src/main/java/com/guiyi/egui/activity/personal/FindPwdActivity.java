package com.guiyi.egui.activity.personal;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.jenwis.android.base.ui.BaseActionBarActivity;

/**
 * Created by C on 2015/8/8.
 */
public class FindPwdActivity extends BaseActionBarActivity implements View.OnClickListener {
    private TextView mBack;
    private TextView mGetCodeTextView;
    private TextView mSureButton;
    private TextView mSwitchTextView;
    private TextView mTitleTextView;
    private EditText mPhoneNumberEditText;
    private EditText mCheckCodeEditText;
    private EditText mPassWordEditText;
    private String mPhoneNumber;
    private String mCheckCode;
    private String mPassWord;
    private boolean mSwitch =false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_find_pwd);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mTitleTextView =(TextView)findViewById(R.id.title_tv);
        mBack =(TextView)findViewById(R.id.back_tv);
        mGetCodeTextView =(TextView)findViewById(R.id.getCode_tv);
        mSwitchTextView =(TextView)findViewById(R.id.switch_btn);
        mSureButton =(Button)findViewById(R.id.sure_btn);
        mPhoneNumberEditText =(EditText)findViewById(R.id.phoneNum_et);
        mCheckCodeEditText =(EditText)findViewById(R.id.phoneCode_et);
        mPassWordEditText =(EditText)findViewById(R.id.pwd_et);
    }

    @Override
    public void setView() {
        mTitleTextView.setText("找回密码");
    }

    @Override
    public void setViewListener() {
        mBack.setOnClickListener(this);
        mGetCodeTextView.setOnClickListener(this);
        mSwitchTextView.setOnClickListener(this);
        mSureButton.setOnClickListener(this);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_tv:
                finish();
                break;
            case R.id.getCode_tv:
                getCode();
                break;
            case R.id.switch_btn:
                if(mSwitch ==false) {
                    mSwitchTextView.setBackgroundResource(R.drawable.box_b);
                    mPassWordEditText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    mSwitch =true;
                }else {
                    mSwitchTextView.setBackgroundResource(R.drawable.box_a);
                    mPassWordEditText.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    mSwitch =false;
                }
                break;
            case R.id.sure_btn:
                settingPassWord();
                break;
            default:
                break;
        }
    }
    //改密码
    private void settingPassWord() {
        mPhoneNumber = mPhoneNumberEditText.getText().toString().trim();
        mCheckCode = mCheckCodeEditText.getText().toString().trim();
        mPassWord = mPassWordEditText.getText().toString().trim();

    }
    //验证码倒计时
    private CountDownTimer timer = new CountDownTimer(61000, 1000) {

        @Override
        public void onTick(long millisUntilFinished) {
            mGetCodeTextView.setText("重发(" + (millisUntilFinished / 1000) + "s)");
            mGetCodeTextView.setClickable(false);
        }

        @Override
        public void onFinish() {
//            code.setEnabled(true);
            mGetCodeTextView.setClickable(true);
            mGetCodeTextView.setText("点击重发");
        }
    };
    //获取验证码
    private void getCode() {
    timer.start();
    }


}
