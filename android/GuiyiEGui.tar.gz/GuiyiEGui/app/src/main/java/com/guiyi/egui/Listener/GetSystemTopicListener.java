package com.guiyi.egui.Listener;

import java.util.ArrayList;

import message.gate.gatemsg;

/**
 * Created by ForOne on 15/9/3.
 */
public interface GetSystemTopicListener {
    void getSystemTopicsCallback(ArrayList<gatemsg.SSysTopic> systemTopics);

    void failed(String message);
}
