package com.guiyi.egui.activity.social;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Listener.GetUserPostByIdListener;
import com.guiyi.egui.Managers.UserFollowManager;
import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.Managers.UserPostsManager;
import com.guiyi.egui.R;
import com.guiyi.egui.activity.common.ImagePreviewActivity;
import com.guiyi.egui.activity.personal.LoginActivity;
import com.guiyi.egui.adapter.CommentListViewAdapter;
import com.guiyi.egui.adapter.GridViewAdapter;
import com.guiyi.egui.customwidget.CommentListView.CommentListView;
import com.guiyi.egui.customwidget.CustomGrideView.CustomGrideView;
import com.guiyi.egui.customwidget.CustomTextView.CustomTextView;
import com.guiyi.egui.customwidget.FitImageView;
import com.guiyi.egui.events.UserPostStatusChangedEvent;
import com.guiyi.egui.fragment.FriendsFragment;
import com.guiyi.egui.util.CommonUtil;
import com.guiyi.egui.util.DateUtil;
import com.guiyi.egui.util.ImageLoaderUtil;
import com.guiyi.egui.customwidget.CircleImageView;
import com.guiyi.egui.websocket.RequestWS;
import com.jenwis.android.base.ui.BaseActivity;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import de.greenrobot.event.EventBus;
import message.common.publicdef;
import message.gate.gatemsg;
import message.gate.ipostoper;

/**
 * Created by ForOne on 2015/8/21.
 */
public class UserPostDetailActivity extends BaseActivity implements View.OnClickListener{
    private TextView mBackTextView;
    private TextView mTitleTextView;
    private CustomTextView mContentTextView;
    private TextView mFollowTextView;
    private TextView mNicknameTextView;
    private TextView mVisitCountTextView;
    private TextView mCommentCountTextView;
    private TextView mPublishTimeTextView;
    private TextView mShareTextView;
    private TextView mCommentTextView;
    private TextView mUpvoteTextView;
    private TextView mMoreTextView;
    private ImageView mCollectTextView;
    private TextView mUserPostTitleTextView;
    private RelativeLayout mPublishCommentRelativeLayout;
    private CommentListView mCommentListView;
    private TextView mMoreComments;
    private int mCommentRequestCode = 1;
    private int mLoginRequestCode = 2;
    private CircleImageView mAvatarImageView;
    private gatemsg.SUserPost mUserPost;
    private ArrayList<gatemsg.SComment> mCommentList = new ArrayList<>();
    private Date mLastestCommentDate = new Date();
    private boolean mIsVoteup;
    private FitImageView image1;
    private FitImageView image2;
    private FitImageView image3;
    private FitImageView image4;
    private FitImageView image5;
    private FitImageView image6;
    private FitImageView image7;
    private FitImageView image8;
    private FitImageView image9;
    private  ArrayList<String> imageList;
    private TextView mNoCommentTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_user_post_detail);
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String postId = intent.getStringExtra(FriendsFragment.USER_POST_ID);
        UserPostsManager.getInstance(this).getUserPostById(postId,this,new GetUserPostByIdListener(){
            @Override
            public void getUserPostResponse(gatemsg.SUserPost userPost) {
                mUserPost = userPost;
                setViewValue(userPost);
            }
        });
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mBackTextView= (TextView) findViewById(R.id.back_tv);
        mTitleTextView= (TextView) findViewById(R.id.title_tv);
        mCollectTextView= (ImageView) findViewById(R.id.right_image_view);
        mContentTextView = (CustomTextView)findViewById(R.id.user_post_content);
        mUserPostTitleTextView = (TextView)findViewById(R.id.user_post_title);
        mNicknameTextView = (TextView)findViewById(R.id.user_post_nickName);
        mFollowTextView = (TextView)findViewById(R.id.user_post_follow_button);
        mVisitCountTextView = (TextView)findViewById(R.id.user_post_visit_count);
        mCommentCountTextView = (TextView)findViewById(R.id.user_post_comment_count);
        mPublishTimeTextView = (TextView)findViewById(R.id.user_post_publish_time);
        mShareTextView = (TextView)findViewById(R.id.user_post_share_text_view);
        mCommentTextView = (TextView)findViewById(R.id.user_post_comment_text_view);
        mUpvoteTextView = (TextView)findViewById(R.id.user_post_upvote_text_view);
        mMoreTextView = (TextView)findViewById(R.id.user_post_more_text_view);
        mAvatarImageView = (CircleImageView)findViewById(R.id.user_post_avatar);
        mCommentListView = (CommentListView) findViewById(R.id.user_post_comment_list_view);
        mPublishCommentRelativeLayout= (RelativeLayout) findViewById(R.id.pub_comment_relative_layout);
        mMoreComments = (TextView)findViewById(R.id.user_post_more_comments);
        image1= (FitImageView) findViewById(R.id.social_topic_detail_pic_image_view1);
        image2= (FitImageView) findViewById(R.id.social_topic_detail_pic_image_view2);
        image3= (FitImageView) findViewById(R.id.social_topic_detail_pic_image_view3);
        image4= (FitImageView) findViewById(R.id.social_topic_detail_pic_image_view4);
        image5= (FitImageView) findViewById(R.id.social_topic_detail_pic_image_view5);
        image6= (FitImageView) findViewById(R.id.social_topic_detail_pic_image_view6);
        image7= (FitImageView) findViewById(R.id.social_topic_detail_pic_image_view7);
        image8= (FitImageView) findViewById(R.id.social_topic_detail_pic_image_view8);
        image9= (FitImageView) findViewById(R.id.social_topic_detail_pic_image_view9);
        mNoCommentTextView= (TextView) findViewById(R.id.no_comment_text_view);
    }

    @Override
    public void setView() {
        mCollectTextView.setVisibility(View.VISIBLE);
        mCollectTextView.setImageResource(R.drawable.uncollection);
        mTitleTextView.setText(R.string.action_bar_title_topic_detail);
    }

    private void setViewValue(gatemsg.SUserPost userPost){
        mUserPostTitleTextView.setText(userPost.title);
        mNicknameTextView.setText(userPost.userInfo.nickname.equals("") ? "没有昵称" : userPost.userInfo.nickname);
        mVisitCountTextView.setText(userPost.viewTimes + "");
        mCommentCountTextView.setText(userPost.commentedTimes + "");
        mCommentTextView.setText(userPost.commentedTimes + "");
        mShareTextView.setText(userPost.sharedTimes + "");
        mUpvoteTextView.setText(userPost.upvotedTimes + "");
        mPublishTimeTextView.setText(DateUtil.getDateIntervelTimeStringToNow(userPost.createDt));
        mContentTextView.setText(userPost.content);
        ImageLoaderUtil.displayImage(userPost.userInfo.avatarUrl, mAvatarImageView);
        setGridViewImages(userPost);
        getUserPostComments(mLastestCommentDate);
        setFollowStatus();
        visitUserPost();
        queryUserPostUpvoteStatus();
    }

    private void queryUserPostUpvoteStatus(){
        ipostoper.IPostOper_queryUserPostUpvoteStatus_response  queryUserPostUpvoteStatusResponse = new ipostoper.IPostOper_queryUserPostUpvoteStatus_response() {
            @Override
            public void onResponse(publicdef.DictStringBool postUpvatedStatusDict) {
                HashMap<String, Boolean> map = postUpvatedStatusDict.getMap();
                if(map.containsKey(mUserPost.postId)){
                    mIsVoteup =  map.get(mUserPost.postId);
                    updateUpvoteImage();
                }
            }

            @Override
            public void onError(String what, int code) {

            }

            @Override
            public void onTimeout() {

            }
        };
        String[] postId = new String[1];
        postId[0] = mUserPost.postId;
        publicdef.SeqString userPostList = new publicdef.SeqString(postId);
        RequestWS.getInstance().getPostOperProxy().queryUserPostUpvoteStatus(queryUserPostUpvoteStatusResponse, LocalInfoManager.getInstance(this).getSessionKey(), userPostList);
    }

    private void visitUserPost(){
        ipostoper.IPostOper_viewUserPost_response  viewUserPostResponse = new ipostoper.IPostOper_viewUserPost_response() {
            @Override
            public void onResponse(int totalViewTimes) {
                mVisitCountTextView.setText(totalViewTimes + "");
            }

            @Override
            public void onError(String what, int code) {

            }

            @Override
            public void onTimeout() {

            }
        };
        RequestWS.getInstance().getPostOperProxy().viewUserPost(viewUserPostResponse, CommonUtil.getDeviceCode(this), mUserPost.postId);
    }


    private void getUserPostComments(Date date){
        GetUserPostCommentsResponse response = new GetUserPostCommentsResponse();
        RequestWS.getInstance().getPostOperProxy().getUserPostComments(response, CommonUtil.getDeviceCode(this), mUserPost.postId, date, 20);
    }

    private void setGridViewImages(gatemsg.SUserPost userPost){
        //下载图片
        final gatemsg.SImageInfo[] imageInfos = userPost.images.getArray();
        if(imageInfos != null && imageInfos.length > 0){
            final ArrayList<String> thumbnaolImageList = new ArrayList<String>();
            imageList = new ArrayList<>();
            for (gatemsg.SImageInfo imageInfo:imageInfos) {
                thumbnaolImageList.add(imageInfo.formatedDownloadUrl);
                imageList.add(imageInfo.token);

            }
            int count=0;
            for (int a=0;a<imageList.size();a++){

                switch (count){
                    case 0:
                        ImageLoaderUtil.displayImage(imageList.get(a),image1);
                        image1.setVisibility(View.VISIBLE);
                        break;
                    case 1:
                        ImageLoaderUtil.displayImage(imageList.get(a),image2);
                        image2.setVisibility(View.VISIBLE);
                        break;
                    case 2:
                        ImageLoaderUtil.displayImage(imageList.get(a), image3);
                        image3.setVisibility(View.VISIBLE);
                        break;
                    case 3:
                        ImageLoaderUtil.displayImage(imageList.get(a),image4);
                        image4.setVisibility(View.VISIBLE);
                        break;
                    case 4:
                        ImageLoaderUtil.displayImage(imageList.get(a),image5);
                        image4.setVisibility(View.VISIBLE);
                        break;
                    case 5:
                        ImageLoaderUtil.displayImage(imageList.get(a),image6);
                        image6.setVisibility(View.VISIBLE);
                        break;
                    case 6:
                        ImageLoaderUtil.displayImage(imageList.get(a),image7);
                        image7.setVisibility(View.VISIBLE);
                        break;
                    case 7:
                        ImageLoaderUtil.displayImage(imageList.get(a),image8);
                        image8.setVisibility(View.VISIBLE);
                        break;
                    case 8:
                        ImageLoaderUtil.displayImage(imageList.get(a),image9);
                        image9.setVisibility(View.VISIBLE);
                        break;
                }
                count++;
                if(count==imageList.size()){
                    break;
                }
            }
        }
    }

    private void setCommentListView(gatemsg.SeqComment commentList){
        if(!commentList.isEmpty()){
            for (int i = 0; i < commentList.getSize(); i ++){
                mCommentList.add(commentList.getArray()[i]);
                //TODO 根据id评论是否存在
            }
        }
        if(commentList.getSize() != 0){
            mLastestCommentDate = commentList.getArray()[commentList.getSize() - 1].commentDt;
        }
        refreshCommentList();
    }

    private void refreshCommentList(){
        CommentListViewAdapter commentListViewAdapter = new CommentListViewAdapter(this,mCommentList);
        mCommentListView.setAdapter(commentListViewAdapter);
        if (mCommentList.size()!=0){
            mNoCommentTextView.setText("");
        }
        if (mCommentList.size() >= mUserPost.commentedTimes){
            mMoreComments.setVisibility(View.GONE);
        }else{
            mMoreComments.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void setViewListener() {
        mBackTextView.setOnClickListener(this);
        mShareTextView.setOnClickListener(this);
        mCommentTextView.setOnClickListener(this);
        mUpvoteTextView.setOnClickListener(this);
        mMoreTextView.setOnClickListener(this);
        mPublishCommentRelativeLayout.setOnClickListener(this);
        mMoreComments.setOnClickListener(this);
        image1.setOnClickListener(this);
        image2.setOnClickListener(this);
        image3.setOnClickListener(this);
        image4.setOnClickListener(this);
        image5.setOnClickListener(this);
        image6.setOnClickListener(this);
        image7.setOnClickListener(this);
        image8.setOnClickListener(this);
        image9.setOnClickListener(this);

    }

    private void setFollowStatus(){
        if(mUserPost == null){
            return;
        }
        mFollowTextView.setTag(mUserPost.postId);
        //自己的帖子不显示关注按钮
        if(mUserPost.userInfo.userId.equals(LocalInfoManager.getInstance(this).getUserId())){
            mFollowTextView.setVisibility(View.GONE);
        }else{

            mFollowTextView.setVisibility(View.VISIBLE);

            final FollowUserResponse followUserResponse =  new FollowUserResponse();
            final UnfollowUserResponse unfollowUserResponse =  new UnfollowUserResponse();

            if(!CommonUtil.IsLogined){
                mFollowTextView.setBackgroundResource(R.drawable.follow);
            }else{
                boolean isFollow = UserFollowManager.getInstance(UserPostDetailActivity.this).isFollow(mUserPost.userInfo.userId);
                mFollowTextView.setBackgroundResource(isFollow ? R.drawable.unfollow : R.drawable.follow);
            }

            mFollowTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!CommonUtil.IsLogined) {
                        Intent intent = new Intent(UserPostDetailActivity.this, LoginActivity.class);
                        startActivity(intent);
                    } else {
                        boolean isFollow = UserFollowManager.getInstance(UserPostDetailActivity.this).isFollow(mUserPost.userInfo.userId);
                        if (isFollow) {
                            UserFollowManager.getInstance(UserPostDetailActivity.this).unfollowUser(unfollowUserResponse, LocalInfoManager.getInstance(UserPostDetailActivity.this).getSessionKey(), mUserPost.userInfo.userId);
                        } else {
                            UserFollowManager.getInstance(UserPostDetailActivity.this).followUser(followUserResponse, LocalInfoManager.getInstance(UserPostDetailActivity.this).getSessionKey(), mUserPost.userInfo.userId);
                        }
                    }
                }
            });
        }
    }

    private void notifyUserPostStatus(){
        UserPostStatusChangedEvent userPostStatusChangedEvent = new UserPostStatusChangedEvent();
        userPostStatusChangedEvent.UserPostId = mUserPost.postId;
        userPostStatusChangedEvent.IsFollow = UserFollowManager.getInstance(UserPostDetailActivity.this).isFollow(mUserPost.userInfo.userId);
        userPostStatusChangedEvent.CommentCount = mUserPost.commentedTimes;
        userPostStatusChangedEvent.ShareCount = mUserPost.sharedTimes;
        userPostStatusChangedEvent.UpvoteCount = mUserPost.upvotedTimes;
        EventBus.getDefault().post(userPostStatusChangedEvent);
    }

    private void login(){
        Intent intent=new Intent(UserPostDetailActivity.this,LoginActivity.class);
        startActivityForResult(intent, mLoginRequestCode);
    }

    class UnfollowUserResponse implements UserFollowManager.FollowOrNotUserListener {


        @Override
        public void success(gatemsg.SMyFocus newFocus) {
            mFollowTextView.setBackgroundResource(R.drawable.follow);
            notifyUserPostStatus();
            Toast.makeText(UserPostDetailActivity.this, "取消关注成功！", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void failed(String error) {
            mFollowTextView.setBackgroundResource(R.drawable.follow);
        }
    }

    class FollowUserResponse implements UserFollowManager.FollowOrNotUserListener {

        @Override
        public void success(gatemsg.SMyFocus newFocus) {
            mFollowTextView.setBackgroundResource(R.drawable.unfollow);
            notifyUserPostStatus();
            Toast.makeText(UserPostDetailActivity.this, R.string.attention_success, Toast.LENGTH_SHORT).show();
        }

        @Override
        public void failed(String error) {
            mFollowTextView.setBackgroundResource(R.drawable.follow);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back_tv:
                finish();
                break;

            case R.id.user_post_comment_text_view:
//                editComment();
                if(CommonUtil.IsLogined){
                    comment();
                }else{
                    login();
                }

                break;

            case R.id.pub_comment_relative_layout:
//                commitComment();
                if(CommonUtil.IsLogined){
                    comment();
                }else{
                    login();
                }
                break;

            case R.id.user_post_upvote_text_view:
                if(CommonUtil.IsLogined){
                    upvoteOrNot();
                }else{
                    login();
                }

                break;

            case R.id.user_post_share_text_view:
                if(CommonUtil.IsLogined){
                    share();
                }else{
                    login();
                }

                break;

            case R.id.user_post_more_comments:
                getUserPostComments(mLastestCommentDate);
                break;
            case R.id.social_topic_detail_pic_image_view1:
                imageViewSetOnclickListener(0);
                break;
            case R.id.social_topic_detail_pic_image_view2:
                imageViewSetOnclickListener(1);
                break;
            case R.id.social_topic_detail_pic_image_view3:
                imageViewSetOnclickListener(2);
                break;
            case R.id.social_topic_detail_pic_image_view4:
                imageViewSetOnclickListener(3);
                break;
            case R.id.social_topic_detail_pic_image_view5:
                imageViewSetOnclickListener(4);
                break;
            case R.id.social_topic_detail_pic_image_view6:
                imageViewSetOnclickListener(5);
                break;
            case R.id.social_topic_detail_pic_image_view7:
                imageViewSetOnclickListener(6);
                break;
            case R.id.social_topic_detail_pic_image_view8:
                imageViewSetOnclickListener(7);
                break;
            case R.id.social_topic_detail_pic_image_view9:
                imageViewSetOnclickListener(8);
                break;

            default:
                break;
        }
    }
    private void imageViewSetOnclickListener(int position){
        Intent intent = new Intent(UserPostDetailActivity.this,ImagePreviewActivity.class);
                    intent.putStringArrayListExtra(ImagePreviewActivity.IMAGE_PREVIEW_URL, imageList);
                    intent.putExtra(ImagePreviewActivity.IMAGE_PREVIEW_INDEX, position);
                    startActivity(intent);
    }

    private void share(){
        Toast.makeText(this, "分享功能暂未实现！", Toast.LENGTH_SHORT).show();
        //notifyUserPostStatus();
    }

    private void upvoteOrNot(){
        if(mIsVoteup){
            UnupvoteUserPostResponse unupvoteUserPostResponse = new UnupvoteUserPostResponse();
            RequestWS.getInstance().getPostOperProxy().unupvoteUserPost(unupvoteUserPostResponse, LocalInfoManager.getInstance(this).getSessionKey(), mUserPost.postId);
        }else{
            UpvoteUserPostResponse upvoteUserPostResponse = new UpvoteUserPostResponse();
            RequestWS.getInstance().getPostOperProxy().upvoteUserPost(upvoteUserPostResponse, LocalInfoManager.getInstance(this).getSessionKey(), mUserPost.postId);
        }
    }

    private void updateUpvoteImage(){
        Drawable drawable = mIsVoteup ? getResources().getDrawable(R.drawable.upvote):getResources().getDrawable(R.drawable.unupvote);
        drawable.setBounds(0,0,drawable.getMinimumWidth(),drawable.getMinimumHeight());
        mUpvoteTextView.setCompoundDrawables(drawable, null, null, null);
    }

    private void upvoteSuccess(){
        mIsVoteup = true;
        mUserPost.upvotedTimes ++;
        mUpvoteTextView.setText(mUserPost.upvotedTimes + "");
        notifyUserPostStatus();
        updateUpvoteImage();
        Toast.makeText(this, "点赞成功!", Toast.LENGTH_SHORT).show();
    }

    private void upvoteFailed(String error){
        Toast.makeText(this, "点赞失败：" + error, Toast.LENGTH_SHORT).show();
    }

    private void unupvoteSuccess(){
        mIsVoteup = false;
        mUserPost.upvotedTimes --;
        updateUpvoteImage();
        mUpvoteTextView.setText(mUserPost.upvotedTimes + "");
        notifyUserPostStatus();
        Toast.makeText(this, "取消点赞成功!", Toast.LENGTH_SHORT).show();
    }

    private void unupvoteFailed(String error){
        Toast.makeText(this, "取消点赞失败：" + error, Toast.LENGTH_SHORT).show();
    }

    private void comment(){
        Intent intent = new Intent(this,UserPostCommentActivity.class);
        String postId = mUserPost.postId;
        intent.putExtra("POST_ID",postId);
        startActivityForResult(intent, mCommentRequestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == mCommentRequestCode && resultCode == RESULT_OK){
            String comment = data.getStringExtra("COMMENT_CONTENT");
            gatemsg.SComment sComment = new gatemsg.SComment();
            gatemsg.SUserBrief user = new gatemsg.SUserBrief();
            user.userId = LocalInfoManager.getInstance(this).getUserId();
            user.nickname = LocalInfoManager.getInstance(this).getNickName();
            user.avatarUrl = LocalInfoManager.getInstance(this).getAvatarUrl();
            sComment.commentId = UUID.randomUUID().toString();
            sComment.comment = comment;
            sComment.commentDt = new Date();
            sComment.commenterInfo = user;
            mCommentList.add(sComment);

            refreshCommentList();
            mUserPost.commentedTimes ++;
            mCommentCountTextView.setText(mUserPost.commentedTimes + "");
            mCommentTextView.setText(mUserPost.commentedTimes + "");
            notifyUserPostStatus();
        }else if(requestCode == mLoginRequestCode && resultCode == RESULT_OK){
            setFollowStatus();
            queryUserPostUpvoteStatus();
        }

    }


    class UnupvoteUserPostResponse extends ipostoper.IPostOper_unupvoteUserPost_response {

        @Override
        public void onResponse() {
            unupvoteSuccess();
        }

        @Override
        public void onError(String what, int code) {
            unupvoteFailed("Code:" + code + " what:" + what);
        }

        @Override
        public void onTimeout() {
            unupvoteFailed("TimeOut");
        }
    }

    class UpvoteUserPostResponse extends ipostoper.IPostOper_upvoteUserPost_response {
        @Override
        public void onResponse() {
            upvoteSuccess();
        }

        @Override
        public void onError(String what, int code) {
            upvoteFailed("Code:" + code + " what:" + what);
        }

        @Override
        public void onTimeout() {
            upvoteFailed("TimeOut");
        }
    }

    class GetUserPostCommentsResponse extends ipostoper.IPostOper_getUserPostComments_response{

        @Override
        public void onResponse(gatemsg.SeqComment commentList) {
            setCommentListView(commentList);
        }

        @Override
        public void onError(String what, int code) {

        }

        @Override
        public void onTimeout() {

        }
    }
}
