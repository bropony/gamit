package com.guiyi.egui.activity.customize;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.jenwis.android.base.ui.BaseActivity;

/**
 * Created by rentianlong on 2015/9/10.14:35
 * <p/>
 * company GDGY
 */
public class AddTagActivity extends BackNavActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_add_tags);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        super.findActionBarView(this);
    }

    @Override
    public void setView() {
        mTitleTextView.setText(R.string.add_tag);
    }

    @Override
    public void setViewListener() {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v); //

    }
}
