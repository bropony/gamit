package com.guiyi.egui;

import android.app.Application;
import android.content.Context;

import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.util.CommonUtil;
import com.guiyi.egui.util.ResponseErrorUtil;
import com.guiyi.egui.util.RmiSetting;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import message.MessageRegister;
import rmi.RmiManager;


/**
 * Created by C on 2015/8/14.
 */
public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        internet_connect();
        initImageLoader(getApplicationContext());
        ResponseErrorUtil.getInstance(this).initHandler();
        String session_Key = LocalInfoManager.getInstance(this).getSessionKey();
        if (session_Key != null && !session_Key.equals("")){
            CommonUtil.IsLogined=true;
        }
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        RmiManager.instance().stopService();
    }
    private void internet_connect() {
        MessageRegister.regist(); // always run before any settings...
        RmiSetting.initSettings();
        RmiManager.instance().startService();
    }

    public static void initImageLoader(Context context) {

        ImageLoaderConfiguration config = ImageLoaderConfiguration.createDefault(context);
        ImageLoader.getInstance().init(config);

    }
}
