package com.guiyi.egui.WeiXin;

import android.app.Activity;
import android.os.Bundle;

import com.guiyi.egui.R;

/**
 * Created by ForOne on 15/9/9.
 */
public class WXPayActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weixin_pay);
    }
}
