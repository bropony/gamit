package com.guiyi.egui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.guiyi.egui.R;
import com.jenwis.android.base.ui.BaseFragment;


/**
 * Created by C on 2015/8/7.
 */
public class ShoppingCartFragment extends BaseFragment {
    private View mView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mView=inflater.inflate(R.layout.fragment_shop,container,false);
        super.onCreateView(inflater, container, savedInstanceState);
        return mView;
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {

    }

    @Override
    public void setView() {

    }

    @Override
    public void setViewListener() {

    }

    @Override
    public void onPageSelected() {

    }

    @Override
    public void onPageDisSelected() {

    }

    @Override
    public void onDataChange(int type, Object obj) {

    }
}
