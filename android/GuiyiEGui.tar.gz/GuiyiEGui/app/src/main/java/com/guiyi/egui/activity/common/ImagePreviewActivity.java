package com.guiyi.egui.activity.common;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.guiyi.egui.R;
import com.guiyi.egui.util.ImageLoaderUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ForOne on 15/8/22.
 */
public class ImagePreviewActivity extends Activity {

    public static String IMAGE_PREVIEW_URL = "com.guiyi.imagepreview.imagelist";
    public static String IMAGE_PREVIEW_INDEX = "com.guiyi.imagepreview.index";


    private ArrayList<ImageView> mListImageViews = null;
    private ViewPager mViewPager;
    private MyPageAdapter mPageAdapter;

    public List<String> mImageUrlList = new ArrayList<>();

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_preview);

        Intent intent = getIntent();
        mImageUrlList = intent.getStringArrayListExtra(IMAGE_PREVIEW_URL);
        if(mImageUrlList == null || mImageUrlList.size() == 0){
            return;
        }
        
        initListImageViews();

        mViewPager = (ViewPager) findViewById(R.id.viewpager);
        mViewPager.setOnPageChangeListener(pageChangeListener);
        mPageAdapter = new MyPageAdapter(mListImageViews);
        mViewPager.setAdapter(mPageAdapter);

        int index = intent.getIntExtra(IMAGE_PREVIEW_INDEX, 0);
        mViewPager.setCurrentItem(index);
    }

    private void initListImageViews() {
        if (mListImageViews == null){
            mListImageViews = new ArrayList<>();
        }
        for (int i = 0 ;i < mImageUrlList.size();i++){
            ImageView imageView = new ImageView(this);
            imageView.setBackgroundColor(0xff000000);
            imageView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                    ViewGroup.LayoutParams.FILL_PARENT));
            mListImageViews.add(imageView);
        }
    }

    private ViewPager.OnPageChangeListener pageChangeListener = new ViewPager.OnPageChangeListener() {

        public void onPageSelected(int arg0) {// 页面选择响应函数

        }

        public void onPageScrolled(int arg0, float arg1, int arg2) {// 滑动中。。。

        }

        public void onPageScrollStateChanged(int arg0) {// 滑动状态改变

        }
    };

    class MyPageAdapter extends PagerAdapter {

        private ArrayList<ImageView> mListViews;

        private int mPageCount;

        public MyPageAdapter(ArrayList<ImageView> listViews) {
            mListViews = listViews;
            mPageCount = listViews == null ? 0 : listViews.size();
        }

        public int getCount() {
            return mPageCount;
        }

        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        public void destroyItem(View view, int position, Object arg2) {
            if(mPageCount == 0){
                return;
            }
            ((ViewPager) view).removeView(mListViews.get(position % mPageCount));
        }

        public void finishUpdate(View arg0) {
        }

        public Object instantiateItem(View view, int position) {
            try {
                if(mPageCount == 0){
                    return null;
                }
                int index = position % mPageCount;
                ImageView imageView = mListViews.get(index);
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        finish();
                    }
                });
                ImageLoaderUtil.displayImage(mImageUrlList.get(index),imageView);
                ((ViewPager) view).addView(imageView, 0);
            } catch (Exception e) {
            }
            return mListViews.get(position % mPageCount);
        }

        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

    }

}
