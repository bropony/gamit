package com.guiyi.egui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.guiyi.egui.R;
import com.guiyi.egui.util.ImageLoaderUtil;
import com.guiyi.egui.util.QiniuUtil;

import java.util.ArrayList;

/**
 * Created by ForOne on 15/8/22.
 */
public class GridViewAdapter extends BaseAdapter {

    private Context mContext;
    private LayoutInflater mInflater;
    private ArrayList<String> mImageList = new ArrayList<>();

    public GridViewAdapter(Context context, ArrayList<String> imageList) {
        mContext=context;
        mInflater = LayoutInflater.from(context);
        mImageList = imageList;
    }

    @Override
    public int getCount() {
        return mImageList.size();
    }

    @Override
    public Object getItem(int position) {
        return mImageList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.grid_view_item,null);
        }
        imageView = (ImageView) convertView.findViewById(R.id.image_view);
        ImageLoaderUtil.displayImage(mImageList.get(position), imageView);

        return convertView;
    }



}
