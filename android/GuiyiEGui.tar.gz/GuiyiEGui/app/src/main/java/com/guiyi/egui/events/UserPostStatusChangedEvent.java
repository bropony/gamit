package com.guiyi.egui.events;

/**
 * Created by ForOne on 15/8/28.
 * 帖子状态发生改变事件
 */
public class UserPostStatusChangedEvent {
    public String UserPostId;
    public boolean IsFollow;
    public int CommentCount;
    public int UpvoteCount;
    public int ShareCount;
}
