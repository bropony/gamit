package com.guiyi.egui.Listener;

import message.gate.gatemsg;

/**
 * Created by ForOne on 15/9/3.
 */
public interface GetSystemTopicByIdListener {
    void success(gatemsg.SSysTopic systemTopic);
    void failed(String message);
}
