package com.guiyi.egui.util;

import android.graphics.Bitmap;
import android.os.Handler;

import com.qiniu.android.http.ResponseInfo;
import com.qiniu.android.storage.UpCompletionHandler;
import com.qiniu.android.storage.UploadManager;
import com.qiniu.android.storage.UploadOptions;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

import message.gate.gatemsg;

/**
 * Created by ForOne on 15/8/20.
 **/
public class QiniuUtil {

    //通过handle回到UI线程执行
   private static Handler mHandler = new Handler();

    private static String IMAGE_HANDLE_VERSION = "imageView2";

    //锁对象
    private static final ReentrantLock lock = new ReentrantLock();


    private static UploadManager mUploadManager = new UploadManager();

    public static void uploadFile(String filePath,String filename,String token,UpCompletionHandler handler){
        mUploadManager.put(filePath,filename,token,handler,null);
    }

    public static void uploadFile(String filePath,String filename,String token,UpCompletionHandler handler,UploadOptions options){
        mUploadManager.put(filePath,filename,token,handler,options);
    }

    public static void uploadFile(File file,String filename,String token,UpCompletionHandler handler,UploadOptions options){
        mUploadManager.put(file,filename,token,handler,options);
    }

    public static void uploadFile(File file,String filename,String token,UpCompletionHandler handler){
        mUploadManager.put(file,filename,token,handler,null);
    }

    public static void uploadFile(byte[] data,String filename,String token,UpCompletionHandler handler){
        mUploadManager.put(data,filename,token,handler,null);
    }

    public static void uploadFile(byte[] data,String filename,String token,UpCompletionHandler handler,UploadOptions options){
        mUploadManager.put(data, filename, token, handler, options);
    }

    static int imageCount = 0;
    public static void uploadFiles(gatemsg.SImageInfo[] imageInfos,ArrayList<String> images, final UploadFileListListener callback){
        imageCount = imageInfos.length;

        if(imageCount == 0){
            if(callback != null){
                callback.success();
            }
            return;
        }

        if(imageInfos.length != images.size()){
            if(callback != null){
                callback.failed();
            }
            return;
        }

        int index = 0;
        for (gatemsg.SImageInfo imageInfo:imageInfos
             ) {
            String token = imageInfo.token;
            String filepath = images.get(index);
            String filename = imageInfo.imageKey;

            UpCompletionHandler handler = new UpCompletionHandler() {
                @Override
                public void complete(String s, ResponseInfo responseInfo, JSONObject jsonObject) {

                    lock.lock();
                    try {
                        imageCount --;
                        if(imageCount == 0){
                            mHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    if(callback != null){
                                        callback.success();
                                    }
                                }
                            });
                        }
                    }finally {
                        lock.unlock();
                    }
                }
            };

            uploadFile(filepath,filename,token,handler);

            index++;
        }
    }

    //获取图片缩略图format
    public static String DefaultImageThumbnailFormat(){
        return ImageThumbnailFormat(1,100,100,80);
    }

    /*
    * @mode 图片处理方式，范围0 - 5
    * @width 宽度
    * @height 高度
    * @quality 质量，范围0 - 100
    * return 图片处理后的url
    * 更多：http://developer.qiniu.com/docs/v6/api/reference/fop/image/imageview2.html
    * */
    public static String ImageThumbnailFormat(int mode, int width, int height, int quality){
        return IMAGE_HANDLE_VERSION + "/" + mode + "/w/"  + width + "/h/" + height + "/q/" + quality;
    }


    /*
    * @mode 图片处理方式，范围0 - 5
    * @width 宽度
    * @height 高度
    * return 图片处理后的url
    * 更多：http://developer.qiniu.com/docs/v6/api/reference/fop/image/imageview2.html
    * */
    public static String ImageThumbnailFormat(int mode, int width, int height){
        return IMAGE_HANDLE_VERSION + "/" + mode + "/w/"  + width + "/h/" + height;
    }

    public interface UploadFileListListener{
        void success();
        void failed();
    }
}
