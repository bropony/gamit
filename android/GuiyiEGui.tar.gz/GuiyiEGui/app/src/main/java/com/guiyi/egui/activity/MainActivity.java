package com.guiyi.egui.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.R;
import com.guiyi.egui.fragment.ShoppingCartFragment;
import com.guiyi.egui.fragment.CustomizeFragment;
import com.guiyi.egui.fragment.FriendsFragment;
import com.guiyi.egui.fragment.HomeFragment;
import com.guiyi.egui.fragment.PersonalFragment;
import com.jenwis.android.base.ui.BaseActionBarActivity;



public class MainActivity extends BaseActionBarActivity implements View.OnClickListener{


    private RadioGroup mRadioGroup;
    private HomeFragment mHomeFragment;
    private FriendsFragment mFriendsFragment;
    private CustomizeFragment mCustomizeFragment;
    private ShoppingCartFragment mShoppingCartFragment;
    private PersonalFragment mPersonalFragment;
    private FragmentTransaction mTransaction;
    private FragmentManager mFragmentManager;
    private Fragment  currentFragment;
    private TextView mHomeTextView;
    private TextView mSocialTextView;
    private TextView mShopTextView;
    private TextView mPersonalTextView;
    private ImageView mHomeImageView;
    private ImageView mSocialImageView;
    private ImageView mCustomImageView;
    private ImageView mShopImageView;
    private ImageView mPersonalImageView;
    private RelativeLayout mHomeRelativeLayout;
    private RelativeLayout mSocialRelativeLayout;
    private RelativeLayout mCustomRelativeLayout;
    private RelativeLayout mShopRelativeLayout;
    private RelativeLayout mPersonalRelativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setBaseContentView(R.layout.activity_main);
        super.onCreate(savedInstanceState);
        initTab();
    }


    @Override
    public void init() {
        mFragmentManager = getSupportFragmentManager();

    }
    @Override
    public void findView() {
        mRadioGroup=(RadioGroup)findViewById(R.id.tab_radioGroup);
        mHomeRelativeLayout= (RelativeLayout) findViewById(R.id.home_relative_layout);
        mHomeImageView= (ImageView) findViewById(R.id.home_image_view);
        mHomeTextView= (TextView) findViewById(R.id.home_text_view);
        mSocialRelativeLayout= (RelativeLayout) findViewById(R.id.social_relative_layout);
        mSocialImageView= (ImageView) findViewById(R.id.social_image_view);
        mSocialTextView= (TextView) findViewById(R.id.social_text_view);
        mCustomRelativeLayout= (RelativeLayout) findViewById(R.id.custom_relative_layout);
        mCustomImageView= (ImageView) findViewById(R.id.custom_image_view);
        mShopRelativeLayout= (RelativeLayout) findViewById(R.id.shopping_relative_layout);
        mShopImageView= (ImageView) findViewById(R.id.shop_image_view);
        mShopTextView= (TextView) findViewById(R.id.shop_text_view);
        mPersonalRelativeLayout= (RelativeLayout) findViewById(R.id.personal_relative_layout);
        mPersonalImageView= (ImageView) findViewById(R.id.personal_image_view);
        mPersonalTextView= (TextView) findViewById(R.id.personal_text_view);
    }

    @Override
    public void setView() {
        setActionBar();
    }

    @Override
    public void setViewListener() {
        mHomeRelativeLayout.setOnClickListener(this);
        mSocialRelativeLayout.setOnClickListener(this);
        mCustomRelativeLayout.setOnClickListener(this);
        mShopRelativeLayout.setOnClickListener(this);
        mPersonalRelativeLayout.setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    private void setActionBar(){
        mActionBar.setVisibility(View.GONE);
    }
    private void initTab() {
        if (mHomeFragment == null) {
            mHomeFragment = new HomeFragment();
        }

        if (!mHomeFragment.isAdded()) {
            // 提交事务
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragment_container, mHomeFragment).commit();

            // 记录当前Fragment
            currentFragment = mHomeFragment;
            mHomeImageView.setImageResource(R.drawable.home_b);
            mHomeTextView.setTextColor(getResources().getColor(R.color.font_blue));
            mCustomImageView.setImageResource(R.drawable.customization_a);
            mSocialImageView.setImageResource(R.drawable.social_a);
            mSocialTextView.setTextColor(getResources().getColor(R.color.font_black));
            mShopImageView.setImageResource(R.drawable.shop_a);
            mShopTextView.setTextColor(getResources().getColor(R.color.font_black));
            mPersonalImageView.setImageResource(R.drawable.user_a);
            mPersonalTextView.setTextColor(getResources().getColor(R.color.font_black));

        }

    }
    private void clickTabHomeLayout() {
        if (mHomeFragment == null) {
            mHomeFragment = new HomeFragment();
        }
        addOrShowFragment(getSupportFragmentManager().beginTransaction(), mHomeFragment);

        // 设置底部tab变化
        mHomeImageView.setImageResource(R.drawable.home_b);
        mHomeTextView.setTextColor(getResources().getColor(R.color.font_blue));
        mCustomImageView.setImageResource(R.drawable.customization_a);
        mSocialImageView.setImageResource(R.drawable.social_a);
        mSocialTextView.setTextColor(getResources().getColor(R.color.font_black));
        mShopImageView.setImageResource(R.drawable.shop_a);
        mShopTextView.setTextColor(getResources().getColor(R.color.font_black));
        mPersonalImageView.setImageResource(R.drawable.user_a);
        mPersonalTextView.setTextColor(getResources().getColor(R.color.font_black));
    }
    private void clickTabSocialLayout() {
        if (mFriendsFragment == null) {
            mFriendsFragment = new FriendsFragment();
        }
        addOrShowFragment(getSupportFragmentManager().beginTransaction(), mFriendsFragment);

        // 设置底部tab变化
        mHomeImageView.setImageResource(R.drawable.home_a);
        mHomeTextView.setTextColor(getResources().getColor(R.color.font_black));
        mCustomImageView.setImageResource(R.drawable.customization_a);
        mSocialImageView.setImageResource(R.drawable.social_b);
        mSocialTextView.setTextColor(getResources().getColor(R.color.font_blue));
        mShopImageView.setImageResource(R.drawable.shop_a);
        mShopTextView.setTextColor(getResources().getColor(R.color.font_black));
        mPersonalImageView.setImageResource(R.drawable.user_a);
        mPersonalTextView.setTextColor(getResources().getColor(R.color.font_black));
    }
    private void clickTabCustomLayout() {
        if (mCustomizeFragment == null) {
            mCustomizeFragment = new CustomizeFragment();
        }
        addOrShowFragment(getSupportFragmentManager().beginTransaction(), mCustomizeFragment);

        // 设置底部tab变化
        mHomeImageView.setImageResource(R.drawable.home_a);
        mHomeTextView.setTextColor(getResources().getColor(R.color.font_black));
        mCustomImageView.setImageResource(R.drawable.customization_b);
        mSocialImageView.setImageResource(R.drawable.social_a);
        mSocialTextView.setTextColor(getResources().getColor(R.color.font_black));
        mShopImageView.setImageResource(R.drawable.shop_a);
        mShopTextView.setTextColor(getResources().getColor(R.color.font_black));
        mPersonalImageView.setImageResource(R.drawable.user_a);
        mPersonalTextView.setTextColor(getResources().getColor(R.color.font_black));
    }
    private void clickTabShopLayout() {
        if (mShoppingCartFragment == null) {
            mShoppingCartFragment = new ShoppingCartFragment();
        }
        addOrShowFragment(getSupportFragmentManager().beginTransaction(), mShoppingCartFragment);

        // 设置底部tab变化
        mHomeImageView.setImageResource(R.drawable.home_a);
        mHomeTextView.setTextColor(getResources().getColor(R.color.font_black));
        mCustomImageView.setImageResource(R.drawable.customization_a);
        mSocialImageView.setImageResource(R.drawable.social_a);
        mSocialTextView.setTextColor(getResources().getColor(R.color.font_black));
        mShopImageView.setImageResource(R.drawable.shop_b);
        mShopTextView.setTextColor(getResources().getColor(R.color.font_blue));
        mPersonalImageView.setImageResource(R.drawable.user_a);
        mPersonalTextView.setTextColor(getResources().getColor(R.color.font_black));
    }
    private void clickTabPersonalLayout() {
        if (mPersonalFragment == null) {
            mPersonalFragment = new PersonalFragment();
        }
        addOrShowFragment(getSupportFragmentManager().beginTransaction(), mPersonalFragment);

        // 设置底部tab变化
        mHomeImageView.setImageResource(R.drawable.home_a);
        mHomeTextView.setTextColor(getResources().getColor(R.color.font_black));
        mCustomImageView.setImageResource(R.drawable.customization_a);
        mSocialImageView.setImageResource(R.drawable.social_a);
        mSocialTextView.setTextColor(getResources().getColor(R.color.font_black));
        mShopImageView.setImageResource(R.drawable.shop_a);
        mShopTextView.setTextColor(getResources().getColor(R.color.font_black));
        mPersonalImageView.setImageResource(R.drawable.user_b);
        mPersonalTextView.setTextColor(getResources().getColor(R.color.font_blue));
    }

    private void addOrShowFragment(FragmentTransaction transaction, Fragment fragment) {
        if (currentFragment == fragment)
            return;

        if (!fragment.isAdded()) { // 如果当前fragment未被添加，则添加到Fragment管理器中
            transaction.hide(currentFragment)
                    .add(R.id.fragment_container, fragment).commit();
        } else {
            transaction.hide(currentFragment).show(fragment).commit();
        }

        currentFragment = fragment;
    }

    private static final long EXIT_INTERVAL_TIME = 2000;
    private long touchTime = 0;

    /**
     * On key up.
     *
     * @param keyCode
     *            the key code
     * @param event
     *
     */
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            long currentTime = System.currentTimeMillis();

            if ((currentTime - touchTime) >= EXIT_INTERVAL_TIME) {
                Toast.makeText(this,R.string.toast_double_click_to_exit,Toast.LENGTH_SHORT).show();
                touchTime = currentTime;
            } else {
                System.exit(0);
            }

            return false;
        }else {
            return true;
        }
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.home_relative_layout:
                clickTabHomeLayout();
                break;
            case R.id.social_relative_layout:
                clickTabSocialLayout();
                break;
            case R.id.custom_relative_layout:
                clickTabCustomLayout();
                break;
            case R.id.shopping_relative_layout:
                clickTabShopLayout();
                break;
            case R.id.personal_relative_layout:
                clickTabPersonalLayout();
                break;
        }
    }

}