package com.guiyi.egui.adapter;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.guiyi.egui.util.SaveGetFileUtil;

public class MyDragGridViewAdapter extends BaseAdapter implements DragGridBaseAdapter{
	private ArrayList<String> mItems;
	private ArrayList<String> mSelectedItems;//选中的话题位置集合
	private Context mContext;
	private int mHidePosition = -1;
	RelativeLayout layout;
	TextView tv;
	public MyDragGridViewAdapter(ArrayList<String> items, ArrayList<String> selectedItems, Context context) {
		super();
		mItems = items;
		mSelectedItems = selectedItems;
		mContext = context;
	}

	@Override
	public int getCount() {
		return mItems.size();
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View arg1, ViewGroup arg2) {
		View view = View.inflate(mContext, R.layout.drag_grid_view_item,null);
		tv = (TextView) view.findViewById(R.id.textView1);
		layout = (RelativeLayout) view.findViewById(R.id.rl_layout);
		tv.setText(mItems.get(position));

		if(position == mHidePosition){
			view.setVisibility(View.INVISIBLE);
		}
		//选中时，改变背景色,索引要一致
		for (int i = 0; i < mSelectedItems.size(); i++) {
			if(mItems.get(position).equals(mSelectedItems.get(i))){
				layout.setBackgroundResource(R.drawable.drag_grad_view_bg_select);
				tv.setTextColor(0xFFFFFFFF);
			}
		}
		return view;
	}

	@Override
	public void reorderItems(int oldPosition,int newPosition) {
		if(oldPosition < newPosition){

			for(int i=oldPosition; i<newPosition; i++){
				Collections.swap(mItems, i, i+1);
			}
		}else if(oldPosition > newPosition){
			for(int i=oldPosition; i>newPosition; i--){
				Collections.swap(mItems, i, i-1);
			}
		}
	}

	@Override
	public void setHideItem(int hidePosition) {
		this.mHidePosition = hidePosition;
		notifyDataSetChanged();
	}

	public ArrayList<String> getItems(){
		return mItems;
	}

	public ArrayList saveSelectItem(){
		ArrayList currentSelectItem = new ArrayList();
		for (int a=0;a<mItems.size();a++){
			if (mSelectedItems.contains(mItems.get(a))){
				currentSelectItem.add(mItems.get(a));
			}
		}
		return currentSelectItem;
	}

}
