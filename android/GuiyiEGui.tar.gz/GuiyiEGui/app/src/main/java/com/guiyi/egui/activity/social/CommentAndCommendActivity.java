package com.guiyi.egui.activity.social;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.jenwis.android.base.ui.BaseActionBarActivity;

/**
 * Created by Administrator on 2015/8/26.
 */
public class CommentAndCommendActivity extends BaseActionBarActivity implements View.OnClickListener{
    private TextView mBackTextView;
    private TextView mTitleTextView;
    private ListView mMessageListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_comment_commend);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mBackTextView= (TextView) findViewById(R.id.back_tv);
        mTitleTextView= (TextView) findViewById(R.id.title_tv);
        mMessageListView= (ListView) findViewById(R.id.comment_commend_listView);
    }

    @Override
    public void setView() {
        mTitleTextView.setText(R.string.action_bar_title_comment_commend);
    }

    @Override
    public void setViewListener() {
        mBackTextView.setOnClickListener(this);
        mMessageListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //TODO 评论和点赞的消息  点击跳转到该微说详情界面
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back_tv:
                finish();
                break;
            default:
                break;
        }
    }
}
