package com.guiyi.egui.Managers;

import android.content.Context;
import android.util.Log;

import com.guiyi.egui.Listener.GetSystemTopicByIdListener;
import com.guiyi.egui.Listener.GetSystemTopicListener;
import com.guiyi.egui.util.CommonUtil;
import com.guiyi.egui.util.DateUtil;
import com.guiyi.egui.util.QiniuUtil;
import com.guiyi.egui.websocket.RequestWS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import message.common.publicdef;
import message.gate.gatemsg;
import message.gate.ipostoper;

/**
 * Created by ForOne on 15/9/3.
 * 管理用户话题
 */
public class SystemTopicManager {
    private static SystemTopicManager mSystemTopicManager;
    private Context mContext;

    private ArrayList<gatemsg.SSysTopic> mSystemTopics;

    //各类话题请求的状态保存
    List<SystemTopicRequestStatus> mSystemTopicRequestStatus = new ArrayList<>();

    private SystemTopicManager(Context context){
        mContext = context;
        mSystemTopics = new ArrayList<>();
    }

    public static SystemTopicManager getInstance(Context context){
        if(mSystemTopicManager == null){
            mSystemTopicManager = new SystemTopicManager(context);
        }
        return mSystemTopicManager;
    }

    public ArrayList<gatemsg.SSysTopic> getSystemTopics(){
        return mSystemTopics;
    }

    public void addSystemTopic(gatemsg.SSysTopic systemTopic){
        gatemsg.SSysTopic topic = isContainTheTopic(systemTopic.topicId);
        if(topic != null){
            mSystemTopics.remove(topic);
        }
        mSystemTopics.add(systemTopic);
    }

    public void addSystemTopic(gatemsg.SSysTopic systemTopic, int index){
        gatemsg.SSysTopic topic = isContainTheTopic(systemTopic.topicId);
        if(topic != null){
            mSystemTopics.remove(topic);
        }
        mSystemTopics.add(index, topic);
    }

    //根据Topic的ID来确定是否已经存在该话题
    public gatemsg.SSysTopic isContainTheTopic(String topicId){
        gatemsg.SSysTopic systemTopic = null;
        for (gatemsg.SSysTopic topic: mSystemTopics) {
            if(topic.topicId.equals(topicId)){
                systemTopic = topic;
                break;
            }
        }
        return systemTopic;
    }

    public void addSystemTopics(ArrayList<gatemsg.SSysTopic> systemTopicArrayList){
        for (gatemsg.SSysTopic systemTopic : systemTopicArrayList){
            addSystemTopic(systemTopic);
        }
    }

    public void addSystemTopics(gatemsg.SSysTopic[] systemTopics){
        List<gatemsg.SSysTopic> list = Arrays.asList(systemTopics);
        addSystemTopics(new ArrayList<gatemsg.SSysTopic>(list));
    }

    private void sortSystemTopics(){
        Collections.sort(mSystemTopics, new Comparator<gatemsg.SSysTopic>() {
            @Override
            public int compare(gatemsg.SSysTopic lhs, gatemsg.SSysTopic rhs) {
                return DateUtil.compareDate(rhs.createDt, lhs.createDt);
            }
        });
    }

    public void clearUserPosts(){
        mSystemTopics.clear();
        mSystemTopicRequestStatus.clear();
    }

    private Date getSystemTopicLastestRequestDate(String tag){
        SystemTopicRequestStatus topicStatus = getSystemTopicRequestStatus(tag);
        if(topicStatus == null){
            topicStatus = new SystemTopicRequestStatus(tag);
            addSystemTopicRequestStatus(topicStatus);
        }
        return topicStatus.LastestRequestDate;
    }

    private Date getSystemTopicOldestRequestDate(String tag){
        SystemTopicRequestStatus topicStatus = getSystemTopicRequestStatus(tag);
        if(topicStatus == null){
            topicStatus = new SystemTopicRequestStatus(tag);
            addSystemTopicRequestStatus(topicStatus);
        }
        return topicStatus.OldestResquestDate;
    }

    private SystemTopicRequestStatus getSystemTopicRequestStatus(String tag){
        for (SystemTopicRequestStatus topicStatus:mSystemTopicRequestStatus
                ) {
            if(topicStatus.Tag.equals(tag)){
                return topicStatus;
            }
        }
        return null;
    }

    private void addSystemTopicRequestStatus(SystemTopicRequestStatus systemTopicRequestStatus){
        SystemTopicRequestStatus topicRequestStatus = getSystemTopicRequestStatus(systemTopicRequestStatus.Tag);
        if(topicRequestStatus != null){
            mSystemTopicRequestStatus.remove(topicRequestStatus);
        }
        mSystemTopicRequestStatus.add(systemTopicRequestStatus);
    }

    public void getOldestSystemTopics(GetSystemTopicListener callback,String tag,int count){
        Log.v("SystemTopic","getOldestSystemTopics");
        Date date = getSystemTopicOldestRequestDate(tag);
        GetFormerSystemTopicsResponse getSystemTopicsResponse = new GetFormerSystemTopicsResponse(callback,tag);
        RequestWS.getInstance().getPostOperProxy().getFormerSysTopics(getSystemTopicsResponse, CommonUtil.getDeviceCode(mContext), tag, date, count, QiniuUtil.DefaultImageThumbnailFormat());
    }

    public void getLatestSystemTopics(GetSystemTopicListener callback,String tag, int count){
        Log.v("SystemTopic","getLatestSystemTopics");
        Date date = getSystemTopicLastestRequestDate(tag);
        GetLastestSystemTopicsResponse getSystemTopicsResponse = new GetLastestSystemTopicsResponse(callback,tag);
        RequestWS.getInstance().getPostOperProxy().getLatestSysTopics(getSystemTopicsResponse, CommonUtil.getDeviceCode(mContext), tag, date, count, QiniuUtil.DefaultImageThumbnailFormat());
    }

    public void getSystemTopicComments(String topicId,int count){
        RequestWS.getInstance().getPostOperProxy().getSysTopicComments(null, CommonUtil.getDeviceCode(mContext), topicId, publicdef.EInteractiveType.Comment, new Date(), count);

    }

    public void getSystemTopicById(String topicId, Context context, final GetSystemTopicByIdListener callback){
        gatemsg.SSysTopic systemTopic = null;
        systemTopic = isContainTheTopic(topicId);
        if(systemTopic != null){
            if(callback != null){
                callback.success(systemTopic);
            }
            return;
        }

        ipostoper.IPostOper_getSysTopicByTopicId_response response = new ipostoper.IPostOper_getSysTopicByTopicId_response() {

            @Override
            public void onResponse(gatemsg.SSysTopic sysTopic) {
                if(callback != null){
                    callback.success(sysTopic);
                }
            }

            @Override
            public void onError(String what, int code) {
                if(callback != null){
                    callback.failed("Error code :" + code + " what:" + what);
                }
            }

            @Override
            public void onTimeout() {
                if(callback != null) {
                    callback.failed("TimeOut");
                }
            }
        };
        RequestWS.getInstance().getPostOperProxy().getSysTopicByTopicId(response, CommonUtil.getDeviceCode(context), topicId, QiniuUtil.DefaultImageThumbnailFormat());
    }

    public class GetFormerSystemTopicsResponse extends ipostoper.IPostOper_getFormerSysTopics_response {
        GetSystemTopicListener mGetSystemTopicListener;
        String mTag;

        public GetFormerSystemTopicsResponse(GetSystemTopicListener getSystemTopicListener, String tag) {
            mGetSystemTopicListener = getSystemTopicListener;
            mTag = tag;
        }

        @Override
        public void onResponse(gatemsg.SeqSysTopic sysTopicList) {
            gatemsg.SSysTopic[] systemTopics = sysTopicList.getArray();
            addSystemTopics(sysTopicList.getArray());
            sortSystemTopics();
            if (mGetSystemTopicListener != null) {
                mGetSystemTopicListener.getSystemTopicsCallback(getSystemTopicsByTag(mTag));
            }

            if(systemTopics.length > 0){
                gatemsg.SSysTopic lastestSystemTopic = systemTopics[0];
                gatemsg.SSysTopic oldestSystemTopic = systemTopics[systemTopics.length - 1];
                SystemTopicRequestStatus topicrequestStatus = getSystemTopicRequestStatus(mTag);
                if(topicrequestStatus != null){
                    if(DateUtil.compareDate(lastestSystemTopic.createDt,topicrequestStatus.LastestRequestDate) == 1){
                        topicrequestStatus.LastestRequestDate = lastestSystemTopic.createDt;
                    }

                    if(DateUtil.compareDate(topicrequestStatus.OldestResquestDate,oldestSystemTopic.createDt) == 1){
                        topicrequestStatus.OldestResquestDate = oldestSystemTopic.createDt;
                    }
                }
            }
        }

        @Override
        public void onError(String what, int code) {
            if (mGetSystemTopicListener != null) {
                mGetSystemTopicListener.failed("Error code :" + code + " what:" + what);
            }
        }

        @Override
        public void onTimeout() {
            if (mGetSystemTopicListener != null) {
                mGetSystemTopicListener.failed("TimeOut");
            }
        }
    }

    private ArrayList<gatemsg.SSysTopic> getSystemTopicsByTag(String tag){

        if(tag.equals("推荐") || tag.equals("0")){
            return mSystemTopics;
        }

        ArrayList<gatemsg.SSysTopic> topics = new ArrayList<>();
        String tagName;
        try{
            int tagId = Integer.parseInt(tag);//这步转换是必须的，用于验证请求的TagName（“推荐”）还是TagId("0")
            tagName = TopicTagsManager.getInstance(mContext).getTagNameByTagId(tagId+"");
        }catch(Exception ex){
            tagName = tag;
        }
        for (gatemsg.SSysTopic systemTopic : mSystemTopics
             ) {

            if(isContain(systemTopic.tags.getArray(),tagName)){
                topics.add(systemTopic);
            }
        }
        return topics;
    }

    private boolean isContain(String[] arr,String str){
        for(int i = 0; i < arr.length; i ++){
            if(arr[i].equals(str)){
                return true;
            }
        }
        return false;
    }

    public class GetLastestSystemTopicsResponse extends ipostoper.IPostOper_getLatestSysTopics_response {
        GetSystemTopicListener mGetSystemTopicListener;
        String mTag;

        public GetLastestSystemTopicsResponse(GetSystemTopicListener getSystemTopicListener, String tag){
            mGetSystemTopicListener = getSystemTopicListener;
            mTag = tag;
        }

        @Override
        public void onResponse(gatemsg.SeqSysTopic sysTopicList) {
            gatemsg.SSysTopic[] systemTopics = sysTopicList.getArray();
            addSystemTopics(sysTopicList.getArray());
            sortSystemTopics();

            if(mGetSystemTopicListener != null){
                mGetSystemTopicListener.getSystemTopicsCallback(getSystemTopicsByTag(mTag));
            }

            if(systemTopics.length > 0){
                gatemsg.SSysTopic lastestSystemTopic = systemTopics[0];
                gatemsg.SSysTopic oldestSystemTopic = systemTopics[systemTopics.length - 1];
                SystemTopicRequestStatus topicrequestStatus = getSystemTopicRequestStatus(mTag);
                if(topicrequestStatus != null){
                    if(DateUtil.compareDate(lastestSystemTopic.createDt,topicrequestStatus.LastestRequestDate) == 1 || topicrequestStatus.IsFirstRequest){
                        topicrequestStatus.LastestRequestDate = lastestSystemTopic.createDt;
                        topicrequestStatus.IsFirstRequest = false;
                    }

                    if(DateUtil.compareDate(topicrequestStatus.OldestResquestDate,oldestSystemTopic.createDt) == 1){
                        topicrequestStatus.OldestResquestDate = oldestSystemTopic.createDt;
                    }
                }
            }
        }

        @Override
        public void onError(String what, int code) {
            if(mGetSystemTopicListener != null){
                mGetSystemTopicListener.failed("Error code :" + code + " what:" + what);
            }
        }

        @Override
        public void onTimeout() {
            if(mGetSystemTopicListener != null){
                mGetSystemTopicListener.failed("TimeOut");
            }
        }
    }

    class SystemTopicRequestStatus {
        public String Tag;
        public Date LastestRequestDate;
        public Date OldestResquestDate;
        public Boolean IsFirstRequest;

        public SystemTopicRequestStatus(String tag){
            Tag = tag;
            LastestRequestDate = DateUtil.DatePlusDay(new Date(), 1);
            OldestResquestDate = new Date();
            IsFirstRequest = true;
        }
    }
}
