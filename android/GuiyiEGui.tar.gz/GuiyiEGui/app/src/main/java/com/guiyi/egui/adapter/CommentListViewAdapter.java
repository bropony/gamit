package com.guiyi.egui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.guiyi.egui.customwidget.CustomTextView.CustomTextView;

import java.util.ArrayList;

import message.gate.gatemsg;

/**
 * Created by ForOne on 15/8/25.
 */
public class CommentListViewAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private Context mContext;
    private ArrayList<gatemsg.SComment> mCommentList = new ArrayList<>();

    public CommentListViewAdapter(Context context,ArrayList<gatemsg.SComment> commentList){
        mContext = context;
        mInflater = LayoutInflater.from(context);
        mCommentList = commentList;
    }

    @Override
    public int getCount() {
        return mCommentList.size();
    }

    @Override
    public Object getItem(int position) {
        return mCommentList.get(position);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;

        if(view == null){
            view = mInflater.inflate(R.layout.item_comment_list_view,null);
            viewHolder = new ViewHolder();
            viewHolder.CommentatorTextView = (TextView)view.findViewById(R.id.user_post_comment_commentator_text_view);
            viewHolder.ReplyTextView = (TextView)view.findViewById(R.id.user_post_comment_reply_textview);
            viewHolder.CommentedTextView = (TextView)view.findViewById(R.id.user_post_comment_commented_text_view);
            viewHolder.ContentTextView = (CustomTextView)view.findViewById(R.id.user_post_comment_content_text_view);
            view.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)view.getTag();
        }

        gatemsg.SComment comment = mCommentList.get(position);
        if( comment.mentioned.isEmpty()){
            viewHolder.ReplyTextView.setVisibility(View.GONE);
            viewHolder.CommentedTextView.setVisibility(View.GONE);
        }else{
            viewHolder.ReplyTextView.setVisibility(View.VISIBLE);
            viewHolder.CommentedTextView.setVisibility(View.VISIBLE);

            String mentioned = " ";
            int count = comment.mentioned.getSize();
            for (int i = 0; i < count;i ++){
                mentioned += comment.mentioned.getArray()[i].nickName + ",";
            }
            mentioned = mentioned.substring(0,mentioned.length() - 1);
            viewHolder.CommentedTextView.setText(mentioned);
        }
        viewHolder.CommentatorTextView.setText(comment.commenterInfo.nickname);
        viewHolder.ContentTextView.setText("  " + comment.comment);

        return view;
    }

    final class ViewHolder{
        public TextView CommentatorTextView;
        public TextView ReplyTextView;
        public TextView CommentedTextView;
        public CustomTextView ContentTextView;
    }
}
