package com.guiyi.egui.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by ForOne on 15/8/20.
 */
public class UrlLoadUtil {
    private static final String TAG = "UrlLoadUtil";
    private static final int TIMEOUT = 5 * 1000;

    public static Bitmap loadImageByUrl( String url) {
        Bitmap bitmap = null;
        try {
            bitmap = BitmapFactory.decodeStream(getImageStream(url));

        } catch (Exception e) {
            Log.v(TAG,"Load image failed!");
            e.printStackTrace();
        }
        return bitmap;
    }

    public  static HashMap<String,Bitmap> loadImageListByUrlList(ArrayList<String> urlList){
        HashMap<String,Bitmap> bitmapList = new HashMap<>();
        for (String url:urlList) {
            Bitmap bitmap = loadImageByUrl(url);
            bitmapList.put(url,bitmap);
        }
        return bitmapList;
    }

    private static byte[] loadByteByUrl(String path) throws Exception {
        URL url = new URL(path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(TIMEOUT);
        conn.setRequestMethod("GET");
        InputStream inStream = conn.getInputStream();
        if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            return readStream(inStream);
        }
        return null;
    }


    private static byte[] readStream(InputStream inStream) throws Exception {
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int length;
        while ((length = inStream.read(buffer)) != -1) {
            outStream.write(buffer, 0, length);
        }
        outStream.close();
        inStream.close();
        return outStream.toByteArray();
    }


    private static InputStream getImageStream(String path) throws Exception {
        URL url = new URL(path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(TIMEOUT);
        conn.setRequestMethod("GET");
        if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            return conn.getInputStream();
        }
        return null;
    }

}
