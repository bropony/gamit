package com.guiyi.egui.activity.customize;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.Dialog.ExpressionDialog;
import com.guiyi.egui.Listener.ChooseImageOperateListener;
import com.guiyi.egui.Listener.CommonResponseListener;
import com.guiyi.egui.Managers.LocalInfoManager;
import com.guiyi.egui.Managers.TailerOrderManager;
import com.guiyi.egui.R;

import com.guiyi.egui.activity.social.PublishUserPostActivity;
import com.guiyi.egui.customwidget.CustomEditText.CustomEditText;
import com.guiyi.egui.customwidget.CustomProgressLoading.CustomProgress;
import com.guiyi.egui.customwidget.choosePhoto.BimpUtil;
import com.guiyi.egui.customwidget.choosePhoto.ChooseImagePopup;
import com.guiyi.egui.customwidget.choosePhoto.PhotoActivity;
import com.guiyi.egui.customwidget.choosePhoto.PhotoAlbumActivity;
import com.guiyi.egui.util.FileUtils;
import com.guiyi.egui.util.StringUtil;
import com.guiyi.egui.util.T;
import com.guiyi.egui.view.CheckBoxTextView;

import com.jenwis.android.base.ui.BaseActivity;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import message.gate.gateconst;
import message.gate.itaileroper;

import static com.guiyi.egui.activity.social.PublishUserPostActivity.*;

public class PublishDesignActivity extends BaseActivity implements View.OnClickListener {

    private static final int CONTENT_MAX_LENGTH = 500;
    public static final int CHOOSE_IMAMGE_FROM_PHOTO_REQUEST_CODE = 0;

    private TextView mBackTextView;
    private TextView mTitleTextView;
    private ImageView mHelpImageView;
    //

    private CheckBoxTextView cb_request_src_pic;
    private CheckBoxTextView cb_request_da_ban_pic;
    private CheckBoxTextView cb_request_make_clothes;
    private CheckBoxTextView cb_sync_publish_weishuo;
    private CheckBoxTextView cb_remind_me;

    private RelativeLayout rl_add_tag;
    private RelativeLayout rl_choose_cloth;
    private LinearLayout submit_request;
    private LinearLayout ll_request_src_pic;
    private LinearLayout ll_request_da_ban_pic;
    private LinearLayout ll_request_make_clothes;
    private LinearLayout ll_sync_publish_weishuo;
    private LinearLayout ll_remind_me;

    private GridView mImageGridView;
    private ImageGridViewAdapter adapter;
    public static final int CAMERA_REQUEST = 1;
    public static final int REQUEST_CODE = 0x123;
    private String mFilename;
    private String mImagePathDir = "/sdcard/camera/";

    private EditText mTitleEditText;
    private CustomEditText mContentEditText;
    private TextView mPublishTextView;
    private TextView mAddExpressionTextView;
    private TextView mContenLengthTextView;


    //选择布料tip
    private TextView tv_cloth_tip;
    private TextView tv_no_selected;

    //交互数据
    private  Bundle selectChooseClothData;

    private boolean mIsPublishing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_publish_design);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {
    }

    @Override
    public void findView() {
        //actionbar
        mBackTextView = (TextView) findViewById(R.id.back_tv);
        mTitleTextView = (TextView) findViewById(R.id.title_tv);
        mHelpImageView = (ImageView) findViewById(R.id.right_image_view);
        mTitleEditText = (EditText) findViewById(R.id.id_desc_edit_text);
        mContentEditText = (CustomEditText) findViewById(R.id.id_details_edit_text);
        mPublishTextView = (TextView) findViewById(R.id.id_tv_publish_customize);
        mAddExpressionTextView = (TextView) findViewById(R.id.id_tv_face);
        mContenLengthTextView = (TextView) findViewById(R.id.id_content_max_length_text_view);
        //content
        cb_request_src_pic = (CheckBoxTextView) findViewById(R.id.id_cb_request_src_pic);
        cb_request_da_ban_pic = (CheckBoxTextView) findViewById(R.id.id_cb_request_da_ban_pic);
        cb_request_make_clothes = (CheckBoxTextView) findViewById(R.id.id_cb_request_make_clothes);
        cb_sync_publish_weishuo = (CheckBoxTextView) findViewById(R.id.id_cb_sync_publish_weishuo);
        cb_remind_me = (CheckBoxTextView) findViewById(R.id.id_cb_remind_me);

        submit_request = (LinearLayout) findViewById(R.id.id_ll_submit_request);
        rl_add_tag = (RelativeLayout) findViewById(R.id.id_ll_add_tag);
        rl_choose_cloth = (RelativeLayout) findViewById(R.id.id_ll_choose_cloth);

        ll_request_src_pic = (LinearLayout) findViewById(R.id.id_ll_request_src_pic);
        ll_request_da_ban_pic = (LinearLayout) findViewById(R.id.id_ll_request_da_ban_pic);
        ll_request_make_clothes = (LinearLayout) findViewById(R.id.id_ll_request_make_clothes);
        ll_sync_publish_weishuo = (LinearLayout) findViewById(R.id.id_ll_sync_publish_weishuo);
        ll_remind_me = (LinearLayout) findViewById(R.id.id_ll_remind_me);

        mImageGridView = (GridView) findViewById(R.id.image_grid_view);
        tv_cloth_tip = (TextView) findViewById(R.id.id_tv_cloth_tip);
        tv_no_selected = (TextView) findViewById(R.id.tv_no_selected);
    }

    @Override
    public void setView() {
        mHelpImageView.setVisibility(View.VISIBLE);
        mHelpImageView.setImageResource(R.drawable.help);
        mTitleTextView.setText(R.string.str_customize_publish_design);
        mImageGridView.setSelector(new ColorDrawable(Color.TRANSPARENT));
        BimpUtil.Clear();
        updataGridView();

    }

    ChooseImageOperateListener chooseImageOperateListener = new ChooseImageOperateListener() {

        @Override
        public void chooseCamera() {
            String name = UUID.randomUUID().toString();
            mFilename = mImagePathDir + "/" + name + ".png";

            final File file = new File(mFilename);
            if (!file.exists()) {
                File dirPath = file.getParentFile();
                dirPath.mkdirs();
            }
            Uri uri = Uri.fromFile(file);
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);//构造intent
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            startActivityForResult(cameraIntent, CAMERA_REQUEST);//发出intent，并要求返回调用结果

        }

        @Override
        public void choosePhoto() {
            Intent intent = new Intent(PublishDesignActivity.this, PhotoAlbumActivity.class);
            startActivityForResult(intent, CHOOSE_IMAMGE_FROM_PHOTO_REQUEST_CODE);
        }

        @Override
        public void cancel() {

        }
    };

    @Override
    public void setViewListener() {
        mBackTextView.setOnClickListener(this);
        mHelpImageView.setOnClickListener(this);
        mPublishTextView.setOnClickListener(this);
        mAddExpressionTextView.setOnClickListener(this);

        mImageGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                if (arg2 == BimpUtil.bmp.size()) {
                    new ChooseImagePopup(PublishDesignActivity.this, mImageGridView, chooseImageOperateListener);
                } else {
                    Intent intent = new Intent(PublishDesignActivity.this,
                            PhotoActivity.class);
                    intent.putExtra("ID", arg2);
                    startActivity(intent);
                }
            }
        });

        mContentEditText.addTextChangedListener(new TextWatcher() {

            String text = "";

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                Editable editable = mContentEditText.getText();
                String content = editable.toString();

                int length = StringUtil.getLengthOfGb2312(content);
                if (length > CONTENT_MAX_LENGTH) {
                    mContentEditText.setText(text);
                }
                text = mContentEditText.getText().toString();
                mContenLengthTextView.setText(StringUtil.getLengthOfGb2312(text) + "/" + CONTENT_MAX_LENGTH);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        MyOnCheckedStateListener listener = new MyOnCheckedStateListener();
        cb_request_src_pic.setOnCheckedListener(listener);
        cb_request_da_ban_pic.setOnCheckedListener(listener);
        cb_request_make_clothes.setOnCheckedListener(listener);
        cb_sync_publish_weishuo.setOnCheckedListener(listener);
        cb_remind_me.setOnCheckedListener(listener);
        //
        rl_add_tag.setOnClickListener(this);
        rl_choose_cloth.setOnClickListener(this);
        //
        submit_request.setOnClickListener(this);
        //
        ll_request_src_pic.setOnClickListener(this);
        ll_request_da_ban_pic.setOnClickListener(this);
        ll_request_make_clothes.setOnClickListener(this);
        ll_sync_publish_weishuo.setOnClickListener(this);
        ll_remind_me.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()) {
            case R.id.back_tv:
                finish();
                break;
            case R.id.right_image_view:
                intent = new Intent(this, HelpInstructionActivity.class);
                startActivity(intent);
                break;
            //添加标签
            case R.id.id_ll_add_tag:
                //TODO
                intent = new Intent(this, AddTagActivity.class);
                startActivity(intent);
            case R.id.id_tv_publish_customize:
                commitTialerOrder();
                break;

            case R.id.id_tv_face:
                addExpression();
                break;
            //添加布料
            case R.id.id_ll_choose_cloth:
                //TODO
                intent = new Intent(this, AddChooseClothActivity.class);
                startActivityForResult(intent, REQUEST_CODE);
                break;

            case R.id.id_ll_submit_request:
                commitTialerOrder();
                break;

            case R.id.id_ll_request_src_pic:
                changeCheckState(cb_request_src_pic);
                break;
            case R.id.id_ll_request_da_ban_pic:
                changeCheckState(cb_request_da_ban_pic);
                break;
            case R.id.id_ll_request_make_clothes:
                changeCheckState(cb_request_make_clothes);
                break;
            case R.id.id_ll_sync_publish_weishuo:
                changeCheckState(cb_sync_publish_weishuo);
                break;
            case R.id.id_ll_remind_me:
                changeCheckState(cb_remind_me);
                break;

            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST) {
            BimpUtil.ImagePathList.add(mFilename);
        }
        if (requestCode == REQUEST_CODE && resultCode == AddChooseClothActivity.RESULT_CODE) {
            selectChooseClothData = data.getExtras();
            Log.i("TAG", "selectChooseClothData " + selectChooseClothData.toString());
            //
            selectChooseCloth();
        }
    }

    private void selectChooseCloth() {
        String s = "已选择";
        if (selectChooseClothData!=null){
            Map<Integer,String> selectedData = (Map<Integer, String>) selectChooseClothData.getSerializable("selectedData");
            Collection<String> values = selectedData.values();
            for (String ss :values){
                s += " " + ss;
            }
            tv_cloth_tip.setVisibility(View.VISIBLE);
            tv_cloth_tip.setText(s);
            tv_no_selected.setText("");
        }
    }

    protected void onRestart() {
        super.onRestart();
        updataGridView();
    }

    private void updataGridView() {
        adapter = new ImageGridViewAdapter(this);
        adapter.update();
        mImageGridView.setAdapter(adapter);
    }

    ExpressionDialog.ExpressionDialogListener addExpressionCallback = new ExpressionDialog.ExpressionDialogListener() {
        @Override
        public void result(String value) {
            String text = mContentEditText.getText().toString();
            mContentEditText.setText(text + value);
        }
    };

    private void addExpression() {
        ExpressionDialog dialog = new ExpressionDialog(this, addExpressionCallback);
    }

    private void commitTialerOrder() {
        if(mIsPublishing){
            return;
        }
        String title = mTitleEditText.getText().toString();
        String content = mContentEditText.getText().toString();
        if(title.equals("") || content.equals("")){
            Toast.makeText(PublishDesignActivity.this,"标题或者内容不能为空！",Toast.LENGTH_SHORT).show();
            return;
        }
        mIsPublishing = true;
        CustomProgress.getInstance(PublishDesignActivity.this).showProgress("发布需求中...", false, null);

        ArrayList<String> images = BimpUtil.originalPicturesPath;
        itaileroper.SNewOrderParams params = new itaileroper.SNewOrderParams();
        params.title = title;
        params.content = content;
        params.orderType = gateconst.ETailerOrderType.ImageText;
        TailerOrderManager.getInstance(this).commitTailerOrder(commitTailerOrderResponse, LocalInfoManager.getInstance(this).getSessionKey(), params, images, cb_sync_publish_weishuo.isChecked());
    }

    CommonResponseListener commitTailerOrderResponse = new CommonResponseListener() {
        @Override
        public void success() {
           Toast.makeText(PublishDesignActivity.this,"发布需求成功！",Toast.LENGTH_SHORT).show();
           mIsPublishing = false;
           CustomProgress.getInstance(PublishDesignActivity.this).hideProgress();
           finish();
        }

        @Override
        public void failure(String what, int code) {
            mIsPublishing = false;
           CustomProgress.getInstance(PublishDesignActivity.this).hideProgress();
        }
    };


    private void changeCheckState(CheckBoxTextView checkBoxTextView) {
        if (!checkBoxTextView.isChecked()) {
            checkBoxTextView.setChecked(true);
        } else {
            checkBoxTextView.setChecked(false);
        }
    }

    private class MyOnCheckedStateListener implements CheckBoxTextView.CheckStateListener {

        @Override
        public void isChecked(View v) {
        }

        @Override
        public void noChecked(View v) {
        }
    }

    public class ImageGridViewAdapter extends BaseAdapter {
        private LayoutInflater inflater; // 视图容器
        private int selectedPosition = -1;// 选中的位置
        private boolean shape;

        public boolean isShape() {
            return shape;
        }

        public void setShape(boolean shape) {
            this.shape = shape;
        }

        public ImageGridViewAdapter(Context context) {
            inflater = LayoutInflater.from(context);
        }

        public void update() {
            initBitmap();
        }

        public int getCount() {
            return (BimpUtil.bmp.size() + 1);
        }

        public Object getItem(int arg0) {

            return null;
        }

        public long getItemId(int arg0) {

            return 0;
        }

        /**
         * ListView Item设置
         */
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final int coord = position;
            ViewHolder holder = null;
            if (convertView == null) {

                convertView = inflater.inflate(R.layout.item_published_grida,
                        parent, false);
                holder = new ViewHolder();
                holder.image = (ImageView) convertView
                        .findViewById(R.id.item_gride_image);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            if (position == BimpUtil.bmp.size()) {
                holder.image.setImageBitmap(BitmapFactory.decodeResource(
                        getResources(), R.drawable.icon_addpic_unfocused));
                if (position == 9) {
                    holder.image.setVisibility(View.GONE);
                }
            } else if (position < BimpUtil.bmp.size()) {
                holder.image.setImageBitmap(BimpUtil.bmp.get(position));
            }

            return convertView;
        }

        public class ViewHolder {
            public ImageView image;
        }

        Handler handler = new Handler() {
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 1:
                        adapter.notifyDataSetChanged();
                        break;
                }
                super.handleMessage(msg);
            }
        };

        public void initBitmap() {
            new Thread(new Runnable() {
                public void run() {
                    BimpUtil.originalPicturesPath.clear();
                    BimpUtil.bmp.clear();
                    int count = BimpUtil.ImagePathList.size();
                    if (count == 0) {
                        return;
                    }

                    for (int i = 0; i < count; i++) {
                        String path = BimpUtil.ImagePathList.get(i);
                        BimpUtil.originalPicturesPath.add(path);
                        Bitmap bm = null;
                        try {
                            bm = BimpUtil.revitionImageSize(path);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        BimpUtil.bmp.add(bm);
                        String newStr = path.substring(
                                path.lastIndexOf("/") + 1,
                                path.lastIndexOf("."));
                        FileUtils.saveBitmap(bm, "" + newStr);
                        handler.sendEmptyMessage(1);
                        BimpUtil.max++;
                    }
                }
            }).start();
        }
    }


}


