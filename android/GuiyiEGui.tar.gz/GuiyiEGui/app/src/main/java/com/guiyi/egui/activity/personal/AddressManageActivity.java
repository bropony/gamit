package com.guiyi.egui.activity.personal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.jenwis.android.base.ui.BaseActionBarActivity;


/**
 * Created by C on 2015/8/17.
 */
public class AddressManageActivity extends BaseActionBarActivity implements View.OnClickListener{
    private TextView mSetUpAddressTextView;
    private TextView mTitleTextView;
    private TextView mBackTextVIew;
@Override
protected void onCreate(Bundle savedInstanceState) {

    setBaseContentView(R.layout.activity_address_manage);
    super.onCreate(savedInstanceState);

}


    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mTitleTextView= (TextView) findViewById(R.id.title_tv);
        mSetUpAddressTextView= (TextView) findViewById(R.id.set_up_address_tv);
        mBackTextVIew = (TextView) findViewById(R.id.back_tv);
    }

    @Override
    public void setView() {
        mTitleTextView.setText(R.string.action_bar_title_set_up_address);
        mActionBar.setVisibility(View.GONE);
    }

    @Override
    public void setViewListener() {
        mBackTextVIew.setOnClickListener(this);
        mSetUpAddressTextView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.set_up_address_tv:
                Intent intent = new Intent(this,SetUpAddressAcitvity.class);
                startActivityForResult(intent,1);
                break;
            case R.id.back_tv:
                finish();
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==1&&requestCode==RESULT_OK){
            String name = data.getStringExtra("NAME");
            String phone_number = data.getStringExtra("PHONE_NUMBER");
            String area = data.getStringExtra("AREA");
            String address = data.getStringExtra("ADDRESS");

        }
    }
}
