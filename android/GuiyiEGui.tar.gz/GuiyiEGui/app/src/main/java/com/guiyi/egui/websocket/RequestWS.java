package com.guiyi.egui.websocket;

import com.guiyi.egui.logic.config.WSProxy;

import message.gate.ilogin;
import message.gate.ipostoper;
import message.gate.itaileroper;
import message.gate.iuserinfo;
import rmi.ProxyManager;

/**
 * Created by ForOne on 15/8/19.
 */
public class RequestWS {
    private static RequestWS requestWS;
    private iuserinfo.IUserInfoProxy mUserInfoProxy;
    private ilogin.ILoginProxy mLoginProxy;
    private ipostoper.IPostOperProxy mPostOperProxy;
    private itaileroper.ITailerOperProxy mTailerOperProxy;

    private RequestWS(){
        initProxy();
    }

    protected void initProxy() {
        mUserInfoProxy = (iuserinfo.IUserInfoProxy) ProxyManager.instance().getProxy(WSProxy.USERINFO);
        mLoginProxy = (ilogin.ILoginProxy) ProxyManager.instance().getProxy(WSProxy.LOGIN);
        mPostOperProxy = (ipostoper.IPostOperProxy) ProxyManager.instance().getProxy(WSProxy.POSTOPER);
        mTailerOperProxy = (itaileroper.ITailerOperProxy)ProxyManager.instance().getProxy(WSProxy.TAILEROPER);
    }

    public static RequestWS getInstance(){
        if(requestWS == null){
            requestWS = new RequestWS();
        }
        return requestWS;
    }

    public ilogin.ILoginProxy getILoginProxy(){
        return mLoginProxy;
    }
    public iuserinfo.IUserInfoProxy getUserInfoProxy(){
        return mUserInfoProxy;
    }

    public ipostoper.IPostOperProxy getPostOperProxy(){
        return mPostOperProxy;
    }
    public itaileroper.ITailerOperProxy getTailerOperProxy(){
        return mTailerOperProxy;
    }

}
