package com.guiyi.egui.Managers;

import android.content.Context;

import com.guiyi.egui.websocket.RequestWS;

import java.util.ArrayList;

import message.gate.gatemsg;
import message.gate.ipostoper;

/**
 * Created by ForOne on 15/8/27.
 */
public class UserFollowManager {

    private static UserFollowManager mUserFollowManager;

    private ArrayList<gatemsg.SMyFocus> mMyFocusList = new ArrayList<>();

    private UserFollowManager(Context context){
        if(LocalInfoManager.getInstance(context).getSessionKey() != null && LocalInfoManager.getInstance(context).getSessionKey().length() > 0){
            getMyAllFollows(LocalInfoManager.getInstance(context).getSessionKey());
        }
    }

    public static UserFollowManager getInstance(Context context){
        if(mUserFollowManager == null){
            mUserFollowManager = new UserFollowManager(context);
        }
        return mUserFollowManager;
    }

    public ArrayList<gatemsg.SMyFocus> getUserFollows(){
        return mMyFocusList;
    }

    public void addAFollow(gatemsg.SMyFocus focus){
        if(!isContain(focus)){
            mMyFocusList.add(focus);
        }
    }

    public void removeAFollow(gatemsg.SMyFocus focus){
        removeAFollowByUserId(focus.userInfo.userId);
    }

    public void removeAFollowByUserId(String userId){
        for (gatemsg.SMyFocus myFocus:mMyFocusList
                ) {
            if(myFocus.userInfo.userId.equals(userId)){
                mMyFocusList.remove(myFocus);
                return;
            }
        }
    }

    public boolean isFollow(String userId){
        return isContain(userId);
    }

    private boolean isContain(gatemsg.SMyFocus focus){
       return isContain(focus.userInfo.userId);
    }

    private boolean isContain(String userId){
        for (gatemsg.SMyFocus myFocus:mMyFocusList
                ) {
            if(myFocus.userInfo.userId.equals(userId)){
                return true;
            }
        }
        return false;
    }

    public void getMyAllFollows(String sessionKey){
        ipostoper.IPostOper_getAllMyFocuses_response response = new ipostoper.IPostOper_getAllMyFocuses_response() {
            @Override
            public void onResponse(gatemsg.SeqMyFocus myFocusList) {
                if(!myFocusList.isEmpty()){
                    gatemsg.SMyFocus[] focusArray = myFocusList.getArray();
                    mMyFocusList.clear();
                    for (int i = 0;i < focusArray.length;i++){
                        mMyFocusList.add(focusArray[i]);
                    }
                }
            }

            @Override
            public void onError(String what, int code) {

            }

            @Override
            public void onTimeout() {

            }
        };
        RequestWS.getInstance().getPostOperProxy().getAllMyFocuses(response,sessionKey);
    }

    public void followUser(final FollowOrNotUserListener callback,String sessionKey,String userId){
        ipostoper.IPostOper_followAUser_response followUserResponse = new ipostoper.IPostOper_followAUser_response() {
            @Override
            public void onResponse(gatemsg.SMyFocus newFocus) {
                if(callback != null){
                    callback.success(newFocus);
                }
                addAFollow(newFocus);
            }

            @Override
            public void onError(String what, int code) {
                if(callback != null){
                    callback.failed("Code " + code +":" + what);
                }
            }

            @Override
            public void onTimeout() {
                if(callback != null){
                    callback.failed("TimeOut");
                }
            }
        };
        RequestWS.getInstance().getPostOperProxy().followAUser(followUserResponse, sessionKey, userId);
    }

    public void unfollowUser(final FollowOrNotUserListener callback,String sessionKey, final String userId){
        ipostoper.IPostOper_unfollowAUser_response unfollowUserResponse = new ipostoper.IPostOper_unfollowAUser_response() {
            @Override
            public void onResponse() {
                if(callback != null){
                    callback.success(null);
                }
                removeAFollowByUserId(userId);
            }

            @Override
            public void onError(String what, int code) {
                if(callback != null){
                    callback.failed("Code " + code +":" + what);
                }
            }

            @Override
            public void onTimeout() {
                if(callback != null){
                    callback.failed("TimeOut");
                }
            }
        };
        RequestWS.getInstance().getPostOperProxy().unfollowAUser(unfollowUserResponse, sessionKey, userId);
    }



    public interface FollowOrNotUserListener {
        void success(gatemsg.SMyFocus newFocus);
        void failed(String error);
    }
}
