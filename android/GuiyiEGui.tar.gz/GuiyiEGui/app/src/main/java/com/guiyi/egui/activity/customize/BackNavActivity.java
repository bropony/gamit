package com.guiyi.egui.activity.customize;

import android.view.View;
import android.widget.TextView;
import com.guiyi.egui.R;
import com.jenwis.android.base.ui.BaseActivity;

/**
 * Created by rentianlong on 2015/9/10.15:43
 * <p/>
 * company GDGY
 *
 * @desc:title back
 */
public abstract class BackNavActivity extends BaseActivity implements View.OnClickListener {
    protected TextView mBackTextView;
    protected TextView mTitleTextView;
    private BackNavActivity activity;


    protected void findActionBarView(BackNavActivity activity) {
        this.activity = activity;
        mBackTextView = (TextView) activity.findViewById(R.id.back_tv);
        mTitleTextView = (TextView) activity.findViewById(R.id.title_tv);

        //
        mBackTextView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == mBackTextView.getId()) {
            activity.finish();
        }
    }
}
