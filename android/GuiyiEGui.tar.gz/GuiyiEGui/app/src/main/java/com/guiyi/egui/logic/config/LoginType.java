package com.guiyi.egui.logic.config;

/**
 * Created by zhengyuji on 15/8/4.
 */
public class LoginType {
    public static final int MobilePhoneNum = 1;
    public static final int TencentQQ = 2;
    public static final int WeChat = 3;
}
