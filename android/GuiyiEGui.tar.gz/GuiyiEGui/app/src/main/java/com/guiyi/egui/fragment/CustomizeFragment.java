package com.guiyi.egui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.guiyi.egui.activity.customize.CustomizeActivity;
import com.jenwis.android.base.ui.BaseFragment;


/**
 * Created by C on 2015/8/7.
 */
public class CustomizeFragment extends BaseFragment implements View.OnClickListener {
    private View mView;
    private TextView mBackTextView;
    private TextView mTitleTextView;
    private TextView mNeedsMarketsTextView;
    private TextView mMakerPiazzaTextView;
    private TextView mMyNeedsTextView;
    private TextView mMyDesignTextView;
    private RelativeLayout mPublishCustomization;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_custonzie, container, false);
        super.onCreateView(inflater, container, savedInstanceState);
        return mView;
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mBackTextView = (TextView) mView.findViewById(R.id.back_tv);
        mTitleTextView = (TextView) mView.findViewById(R.id.title_tv);
        mNeedsMarketsTextView = (TextView) mView.findViewById(R.id.need_markets_text_view);
        mMakerPiazzaTextView = (TextView) mView.findViewById(R.id.maker_piazza_text_view);
        mMyNeedsTextView = (TextView) mView.findViewById(R.id.my_needs_text_view);
        mMyDesignTextView = (TextView) mView.findViewById(R.id.my_design_text_view);
        mPublishCustomization = (RelativeLayout) mView.findViewById(R.id.pub_customization_relative_layout);
    }

    @Override
    public void setView() {
        mBackTextView.setVisibility(View.INVISIBLE);
        mTitleTextView.setText(R.string.customization);
    }

    @Override
    public void setViewListener() {
        mNeedsMarketsTextView.setOnClickListener(this);
        mMyDesignTextView.setOnClickListener(this);
        mPublishCustomization.setOnClickListener(this);
        mMyNeedsTextView.setOnClickListener(this);
        mMakerPiazzaTextView.setOnClickListener(this);
    }

    @Override
    public void onPageSelected() {

    }

    @Override
    public void onPageDisSelected() {

    }

    @Override
    public void onDataChange(int type, Object obj) {

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.need_markets_text_view:
                //TODO 需求市场跳转
                break;
            case R.id.maker_piazza_text_view:
                //TODO 创客广场跳转
                break;
            case R.id.my_needs_text_view:
                //TODO 我的需求跳转
                break;
            case R.id.my_design_text_view:
                //TODO 我的设计跳转
                break;
            case R.id.pub_customization_relative_layout:
                Intent intent = new Intent(getActivity(), CustomizeActivity.class);
                startActivity(intent);
                break;
        }
    }
}
