package com.guiyi.egui.activity.personal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.guiyi.egui.R;
import com.jenwis.android.base.ui.BaseActionBarActivity;

/**
 * Created by Administrator on 2015/8/25.
 */
public class SetUpAddressAcitvity extends BaseActionBarActivity implements View.OnClickListener{
    private EditText mNameEditText;
    private EditText mPhoneNumEditText;
    private EditText mAreaEditText;
    private EditText mAddressEditText;
    private TextView mBackTextView;
    private TextView mTitleTextView;
    private Button mSaveButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setBaseContentView(R.layout.activity_setting_address);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mBackTextView= (TextView) findViewById(R.id.back_tv);
        mTitleTextView= (TextView) findViewById(R.id.title_tv);
        mNameEditText= (EditText) findViewById(R.id.name_edit_text);
        mPhoneNumEditText= (EditText) findViewById(R.id.phone_edit_text);
        mAreaEditText= (EditText) findViewById(R.id.area_edit_text);
        mAddressEditText= (EditText) findViewById(R.id.address_edit_text);
        mSaveButton= (Button) findViewById(R.id.save_button);
    }

    @Override
    public void setView() {
        mTitleTextView.setText(R.string.action_bar_title_set_up_address);
        mActionBar.setVisibility(View.GONE);
    }

    @Override
    public void setViewListener() {
        mSaveButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.save_button:
                setUpAddress();
                break;
        }
    }

    private void setUpAddress() {
        String name=mNameEditText.getText().toString().trim();
        String phoneNum=mPhoneNumEditText.getText().toString().trim();
        String area=mAreaEditText.getText().toString().trim();
        String address=mAddressEditText.getText().toString().trim();
        if (name==null||name.isEmpty()){
            Toast.makeText(this,R.string.name_can_not_be_empty,Toast.LENGTH_SHORT).show();
            return;
        }
        if (phoneNum==null||phoneNum.isEmpty()){
            Toast.makeText(this,R.string.phone_num_not_be_empty,Toast.LENGTH_SHORT).show();
            return;
        }
        if (address==null||address.isEmpty()){
            Toast.makeText(this,R.string.address_not_be_empty,Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent();
        intent.putExtra("NAME",name);
        intent.putExtra("PHONE_NUMBER",phoneNum);
        intent.putExtra("AREA",area);
        intent.putExtra("ADDRESS",address);
        setResult(RESULT_OK,intent);

    }
}
