package com.guiyi.egui.activity.customize;

import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.guiyi.egui.R;
import com.guiyi.egui.util.T;
import com.jenwis.android.base.ui.BaseActivity;

/**
 * Created by rentianlong on 2015/9/9.17:39
 * <p/>
 * company GDGY
 */
public class HelpInstructionActivity extends BaseActivity implements View.OnClickListener {

    private TextView mBackTextView;
    private TextView mTitleTextView;
    private RelativeLayout contact_ESQ_relative_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_help_introductions);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {

    }

    @Override
    public void findView() {
        mBackTextView = (TextView) findViewById(R.id.back_tv);
        mTitleTextView = (TextView) findViewById(R.id.title_tv);
        contact_ESQ_relative_layout = (RelativeLayout) findViewById(R.id.contact_ESQ_relative_layout);
    }

    @Override
    public void setView() {
        mTitleTextView.setText(R.string.help_introductions);
    }

    @Override
    public void setViewListener() {
        mBackTextView.setOnClickListener(this);
        contact_ESQ_relative_layout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_tv:
                finish();
            case R.id.contact_ESQ_relative_layout:
                T.showShort(this, "");
            default:
                break;
        }
    }
}
