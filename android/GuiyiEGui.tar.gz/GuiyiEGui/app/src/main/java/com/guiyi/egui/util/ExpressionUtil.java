package com.guiyi.egui.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.Log;

import com.guiyi.egui.R;

import java.lang.reflect.Field;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by ForOne on 15/8/26.
 */
public class ExpressionUtil {

    private static ExpressionUtil mExpressionUtil;
     public static ExpressionUtil getInstance(){
         if(mExpressionUtil == null){
             mExpressionUtil = new ExpressionUtil();
         }
         return mExpressionUtil;
     }

   public static String EXPRESSION_REGEX = "f0[0-9]{2}|f10[0-7]";	//正则表达式，用来判断消息内是否有表情
    /**
     * 对spanableString进行正则判断，如果符合要求，则以表情图片代替
     * @param context
     * @param spannableString
     * @param patten
     * @param start
     * @throws SecurityException
     * @throws NoSuchFieldException
     * @throws NumberFormatException
     * @throws IllegalArgumentException
     * @throws IllegalAccessException
     */
    public int dealExpression(Context context,SpannableString spannableString, Pattern patten, int start) throws SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        if(patten == null) return 0;
        Matcher matcher = patten.matcher(spannableString);
        int count = 0;
        while (matcher.find()) {
            String key = matcher.group();
            if (matcher.start() < start) {
                continue;
            }
            Field field = R.drawable.class.getDeclaredField(key);
            int resId = Integer.parseInt(field.get(null).toString());		//通过上面匹配得到的字符串来生成图片资源id
            if (resId != 0) {
                Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), resId);
                ImageSpan imageSpan = new ImageSpan(zoomImage(bitmap,80,80));				//通过图片资源id来得到bitmap，用一个ImageSpan来包装

                int end = matcher.start() + key.length();					//计算该图片名字的长度，也就是要替换的字符串的长度
                spannableString.setSpan(imageSpan, matcher.start(), end, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);	//将该图片替换字符串中规定的位置中
                count ++;
                if (end < spannableString.length()) {						//如果整个字符串还未验证完，则继续。。
                   count += dealExpression(context,spannableString,  patten, end);
                }
                break;
            }
        }
        return count;
    }


    public ExpressionResult getExpressionString(Context context,String str){
        SpannableString spannableString = new SpannableString(str);
        Pattern sinaPatten = Pattern.compile(EXPRESSION_REGEX, Pattern.CASE_INSENSITIVE);		//通过传入的正则表达式来生成一个pattern
        int count =0;
        try {
           count = dealExpression(context,spannableString, sinaPatten, 0);
        } catch (Exception e) {
            Log.e("dealExpression", e.getMessage());
        }
        ExpressionResult expressionResult = new ExpressionResult();
        expressionResult.MatchCount = count;
        expressionResult.SpannableString = spannableString;
        return expressionResult;
    }

    public class ExpressionResult{
        public SpannableString SpannableString;
        public int MatchCount;
    }

    /***
     * 图片的缩放方法
     *
     * @param bgimage
     *            ：源图片资源
     * @param newWidth
     *            ：缩放后宽度
     * @param newHeight
     *            ：缩放后高度
     * @return
     */
    public static Bitmap zoomImage(Bitmap bgimage, double newWidth,
                                   double newHeight) {
        // 获取这个图片的宽和高
        float width = bgimage.getWidth();
        float height = bgimage.getHeight();
        // 创建操作图片用的matrix对象
        Matrix matrix = new Matrix();
        // 计算宽高缩放率
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // 缩放图片动作
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap bitmap = Bitmap.createBitmap(bgimage, 0, 0, (int) width,
                (int) height, matrix, true);
        return bitmap;
    }

}
