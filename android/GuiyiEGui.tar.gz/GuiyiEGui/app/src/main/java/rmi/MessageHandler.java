package rmi;

public abstract class MessageHandler {
	public abstract void onMessage(MessageBlock msgBlock);
}
