/*
* @filename ilogin.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package com.guiyi.lib.ws.message.gate;


import com.guiyi.lib.ws.rmi.MessageBlock;
import com.guiyi.lib.ws.rmi.ProxyManager;
import com.guiyi.lib.ws.rmi.RmiCore;
import com.guiyi.lib.ws.rmi.Serializer;


public class ilogin {
    // Reponse ILogin_getPhoneSignupValidationCode_response
    public static abstract class ILogin_getPhoneSignupValidationCode_response extends RmiCore.RmiResponseBase {
        public ILogin_getPhoneSignupValidationCode_response() {
            super();
        }

        @Override
        public void __onResponse(Serializer __is) {
            onCommonResponse();
            onResponse();
        }

        @Override
        public void __onError(String what, int code) {
            onCommonResponse();
            onError(what, code);
        }

        @Override
        public void __onTimeout() {
            onCommonResponse();
            onTimeout();
        }

        public abstract void onResponse();

        public abstract void onError(String what, int code);

        public abstract void onTimeout();

        public abstract void onCommonResponse();
    }

    // Reponse ILogin_login_response
    public static abstract class ILogin_login_response extends RmiCore.RmiResponseBase {
        public ILogin_login_response() {
            super();
        }

        @Override
        public void __onResponse(Serializer __is) {
            gatemsg.SLoginReturn loginRes = new gatemsg.SLoginReturn();
            loginRes.__read(__is);
            onCommonResponse();
            onResponse(loginRes);
        }

        @Override
        public void __onError(String what, int code) {
            onCommonResponse();
            onError(what, code);
        }

        @Override
        public void __onTimeout() {
            onCommonResponse();
            onTimeout();
        }

        public abstract void onResponse(gatemsg.SLoginReturn loginRes);

        public abstract void onError(String what, int code);

        public abstract void onTimeout();

        public abstract void onCommonResponse();
    }

    // Reponse ILogin_signup_response
    public static abstract class ILogin_signup_response extends RmiCore.RmiResponseBase {
        public ILogin_signup_response() {
            super();
        }

        @Override
        public void __onResponse(Serializer __is) {
            gatemsg.SLoginReturn signupRes = new gatemsg.SLoginReturn();
            signupRes.__read(__is);
            onCommonResponse();
            onResponse(signupRes);
        }

        @Override
        public void __onError(String what, int code) {
            onCommonResponse();
            onError(what, code);
        }

        @Override
        public void __onTimeout() {
            onCommonResponse();
            onTimeout();
        }

        public abstract void onResponse(gatemsg.SLoginReturn signupRes);

        public abstract void onError(String what, int code);

        public abstract void onTimeout();

        public abstract void onCommonResponse();
    }

    // Reponse ILogin_getPasswordResetValidationCode_response
    public static abstract class ILogin_getPasswordResetValidationCode_response extends RmiCore.RmiResponseBase {
        public ILogin_getPasswordResetValidationCode_response() {
            super();
        }

        @Override
        public void __onResponse(Serializer __is) {
            onResponse();
        }

        @Override
        public void __onError(String what, int code) {
            onError(what, code);
        }

        @Override
        public void __onTimeout() {
            onTimeout();
        }

        public abstract void onResponse();

        public abstract void onError(String what, int code);

        public abstract void onTimeout();
    }

    // Reponse ILogin_resetPhoneUserPassword_response
    public static abstract class ILogin_resetPhoneUserPassword_response extends RmiCore.RmiResponseBase {
        public ILogin_resetPhoneUserPassword_response() {
            super();
        }

        @Override
        public void __onResponse(Serializer __is) {
            onResponse();
        }

        @Override
        public void __onError(String what, int code) {
            onError(what, code);
        }

        @Override
        public void __onTimeout() {
            onTimeout();
        }

        public abstract void onResponse();

        public abstract void onError(String what, int code);

        public abstract void onTimeout();
    }

    // Proxy ILoginProxy
    public static class ILoginProxy extends RmiCore.RmiProxyBase {
        public static void __regist() {
            // regist proxy at startup...
            ProxyManager.instance().addProxy(new ILoginProxy());
        }

        public ILoginProxy() {
            super("ILogin");
        }

        public void getPhoneSignupValidationCode(ILogin_getPhoneSignupValidationCode_response __response, String deviceCode, String phoneNum) {
            Serializer __os = new Serializer();
            __os.startToWrite();
            __os.write(Serializer.RmiDataCall);
            __os.write(getName());
            __os.write(new String("getPhoneSignupValidationCode"));

            int __msgId = MessageBlock.getMsgId();
            __response.setMsgId(__msgId);
            __os.write(__msgId);

            __os.write(deviceCode);
            __os.write(phoneNum);

            this.call(__os, __response);
        }

        public void login(ILogin_login_response __response, gatemsg.SLogin loginInfo) {
            Serializer __os = new Serializer();
            __os.startToWrite();
            __os.write(Serializer.RmiDataCall);
            __os.write(getName());
            __os.write(new String("login"));

            int __msgId = MessageBlock.getMsgId();
            __response.setMsgId(__msgId);
            __os.write(__msgId);

            loginInfo.__write(__os);

            this.call(__os, __response);
        }

        public void signup(ILogin_signup_response __response, gatemsg.SSignup signupInfo) {
            Serializer __os = new Serializer();
            __os.startToWrite();
            __os.write(Serializer.RmiDataCall);
            __os.write(getName());
            __os.write(new String("signup"));

            int __msgId = MessageBlock.getMsgId();
            __response.setMsgId(__msgId);
            __os.write(__msgId);

            signupInfo.__write(__os);

            this.call(__os, __response);
        }

        public void getPasswordResetValidationCode(ILogin_getPasswordResetValidationCode_response __response, String deviceCode, String phoneNum) {
            Serializer __os = new Serializer();
            __os.startToWrite();
            __os.write(Serializer.RmiDataCall);
            __os.write(getName());
            __os.write(new String("getPasswordResetValidationCode"));

            int __msgId = MessageBlock.getMsgId();
            __response.setMsgId(__msgId);
            __os.write(__msgId);

            __os.write(deviceCode);
            __os.write(phoneNum);

            this.call(__os, __response);
        }

        public void resetPhoneUserPassword(ILogin_resetPhoneUserPassword_response __response, String phoneNum, String validationCode, String newPassword) {
            Serializer __os = new Serializer();
            __os.startToWrite();
            __os.write(Serializer.RmiDataCall);
            __os.write(getName());
            __os.write(new String("resetPhoneUserPassword"));

            int __msgId = MessageBlock.getMsgId();
            __response.setMsgId(__msgId);
            __os.write(__msgId);

            __os.write(phoneNum);
            __os.write(validationCode);
            __os.write(newPassword);

            this.call(__os, __response);
        }

    }

}

