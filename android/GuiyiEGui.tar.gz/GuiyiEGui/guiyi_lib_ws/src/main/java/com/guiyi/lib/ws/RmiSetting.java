package com.guiyi.lib.ws;

import java.net.URI;

import com.guiyi.lib.ws.message.gate.*;
import com.guiyi.lib.ws.rmi.RmiClient;
import com.guiyi.lib.ws.rmi.RmiManager;

public class RmiSetting {
    private static RmiClient client;
    public static void initSettings() {
        client = RmiSetting.createGateServiceClient();
        RmiSetting.registMessageHandlers();
    }

    public static void closeClient() {
        if (client != null) {
            client.closeConnection();
        }
    }

    private static RmiClient createGateServiceClient() {
        URI serverURI = null;

        try {
            serverURI = new URI("ws://192.168.0.168:8001");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        RmiClient client = new RmiClient(serverURI);

        RmiManager.instance().addRmiClient(RmiManager.ClientType_GateServer, client);
        RmiSetting.bindGateServiceProxies(client);

        return client;
    }

    private static void bindGateServiceProxies(RmiClient client) {
        client.bindProxy("ILogin");

        // list more proxy bindings blow...
        // to do
    }

    private static void registMessageHandlers() {
        //MessageManager.instance().registMessageHandler(command.ETestCommand.FirstMessage, new FirstMessageHandler());

        // list more handler registering blow...
        // to do
    }
}
