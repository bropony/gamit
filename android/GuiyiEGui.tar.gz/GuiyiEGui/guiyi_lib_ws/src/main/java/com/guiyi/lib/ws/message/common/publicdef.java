/*
* @filename publicdef.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package com.guiyi.lib.ws.message.common;


import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.guiyi.lib.ws.rmi.Serializer;


public class publicdef
{
    // List SeqInt
    public static class SeqInt
    {
        private int[] __array;

        public SeqInt()
        {
            __array = null;
        }

        public int[] getArray()
        {
            return __array;
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            __array = new int[__dataSize];
            for (int i = 0; i < __dataSize; ++i)
            {
                int __val = 0;
                __val = __is.read(__val);
                __array[i] = __val;
            }
        }

        public void __write(Serializer __os)
        {
            int __dataSize = (__array != null) ? __array.length : 0;
            __os.write(__dataSize);
            for (int i = 0; i < __dataSize; ++i)
            {
                __os.write(__array[i]);
            }
        }

    }

    // List SeqLong
    public static class SeqLong
    {
        private long[] __array;

        public SeqLong()
        {
            __array = null;
        }

        public long[] getArray()
        {
            return __array;
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            __array = new long[__dataSize];
            for (int i = 0; i < __dataSize; ++i)
            {
                long __val = 0;
                __val = __is.read(__val);
                __array[i] = __val;
            }
        }

        public void __write(Serializer __os)
        {
            int __dataSize = (__array != null) ? __array.length : 0;
            __os.write(__dataSize);
            for (int i = 0; i < __dataSize; ++i)
            {
                __os.write(__array[i]);
            }
        }

    }

    // List SeqByte
    public static class SeqByte
    {
        private byte[] __array;

        public SeqByte()
        {
            __array = null;
        }

        public byte[] getArray()
        {
            return __array;
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            __array = new byte[__dataSize];
            for (int i = 0; i < __dataSize; ++i)
            {
                byte __val = 0;
                __val = __is.read(__val);
                __array[i] = __val;
            }
        }

        public void __write(Serializer __os)
        {
            int __dataSize = (__array != null) ? __array.length : 0;
            __os.write(__dataSize);
            for (int i = 0; i < __dataSize; ++i)
            {
                __os.write(__array[i]);
            }
        }

    }

    // List SeqString
    public static class SeqString
    {
        private String[] __array;

        public SeqString()
        {
            __array = null;
        }

        public String[] getArray()
        {
            return __array;
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            __array = new String[__dataSize];
            for (int i = 0; i < __dataSize; ++i)
            {
                String __val = "";
                __val = __is.read(__val);
                __array[i] = __val;
            }
        }

        public void __write(Serializer __os)
        {
            int __dataSize = (__array != null) ? __array.length : 0;
            __os.write(__dataSize);
            for (int i = 0; i < __dataSize; ++i)
            {
                __os.write(__array[i]);
            }
        }

    }

    // List SeqDate
    public static class SeqDate
    {
        private Date[] __array;

        public SeqDate()
        {
            __array = null;
        }

        public Date[] getArray()
        {
            return __array;
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            __array = new Date[__dataSize];
            for (int i = 0; i < __dataSize; ++i)
            {
                Date __val = new Date();
                __val = __is.read(__val);
                __array[i] = __val;
            }
        }

        public void __write(Serializer __os)
        {
            int __dataSize = (__array != null) ? __array.length : 0;
            __os.write(__dataSize);
            for (int i = 0; i < __dataSize; ++i)
            {
                __os.write(__array[i]);
            }
        }

    }

    // Dict DictIntBool
    public static class DictIntBool
    {
        private Map<Integer, Boolean> __map;

        public DictIntBool()
        {
            __map = new HashMap<Integer, Boolean>();
        }

        public Map<Integer, Boolean> getMap()
        {
            return __map;
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            for (int i = 0; i < __dataSize; ++i)
            {
                Integer __key = new Integer(__is.readInt());
                Boolean __val = new Boolean(__is.readBool());
                __map.put(__key, __val);
            }
        }

        public void __write(Serializer __os)
        {
            __os.write(__map.size());

            Set<Integer> __keySet = __map.keySet();
            Iterator<Integer> __it = __keySet.iterator();
            while (__it.hasNext())
            {
                Integer __key = __it.next();
                __os.write(__key.intValue());
                Boolean __val = __map.get(__key);
                __os.write(__val.booleanValue());
            }
        }

    }

    // Dict DictIntInt
    public static class DictIntInt
    {
        private Map<Integer, Integer> __map;

        public DictIntInt()
        {
            __map = new HashMap<Integer, Integer>();
        }

        public Map<Integer, Integer> getMap()
        {
            return __map;
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            for (int i = 0; i < __dataSize; ++i)
            {
                Integer __key = new Integer(__is.readInt());
                Integer __val = new Integer(__is.readInt());
                __map.put(__key, __val);
            }
        }

        public void __write(Serializer __os)
        {
            __os.write(__map.size());

            Set<Integer> __keySet = __map.keySet();
            Iterator<Integer> __it = __keySet.iterator();
            while (__it.hasNext())
            {
                Integer __key = __it.next();
                __os.write(__key.intValue());
                Integer __val = __map.get(__key);
                __os.write(__val.intValue());
            }
        }

    }

    // Dict DictStringString
    public static class DictStringString
    {
        private Map<String, String> __map;

        public DictStringString()
        {
            __map = new HashMap<String, String>();
        }

        public Map<String, String> getMap()
        {
            return __map;
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            for (int i = 0; i < __dataSize; ++i)
            {
                String __key = __is.readString();
                String __val = "";
                __val = __is.read(__val);
                __map.put(__key, __val);
            }
        }

        public void __write(Serializer __os)
        {
            __os.write(__map.size());

            Set<String> __keySet = __map.keySet();
            Iterator<String> __it = __keySet.iterator();
            while (__it.hasNext())
            {
                String __key = __it.next();
                __os.write(__key);
                String __val = __map.get(__key);
                __os.write(__val);
            }
        }

    }

    // Dict DictStringInt
    public static class DictStringInt
    {
        private Map<String, Integer> __map;

        public DictStringInt()
        {
            __map = new HashMap<String, Integer>();
        }

        public Map<String, Integer> getMap()
        {
            return __map;
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            for (int i = 0; i < __dataSize; ++i)
            {
                String __key = __is.readString();
                Integer __val = new Integer(__is.readInt());
                __map.put(__key, __val);
            }
        }

        public void __write(Serializer __os)
        {
            __os.write(__map.size());

            Set<String> __keySet = __map.keySet();
            Iterator<String> __it = __keySet.iterator();
            while (__it.hasNext())
            {
                String __key = __it.next();
                __os.write(__key);
                Integer __val = __map.get(__key);
                __os.write(__val.intValue());
            }
        }

    }

    // Dict DictIntString
    public static class DictIntString
    {
        private Map<Integer, String> __map;

        public DictIntString()
        {
            __map = new HashMap<Integer, String>();
        }

        public Map<Integer, String> getMap()
        {
            return __map;
        }

        public void __read(Serializer __is)
        {
            int __dataSize = __is.readInt();
            for (int i = 0; i < __dataSize; ++i)
            {
                Integer __key = new Integer(__is.readInt());
                String __val = "";
                __val = __is.read(__val);
                __map.put(__key, __val);
            }
        }

        public void __write(Serializer __os)
        {
            __os.write(__map.size());

            Set<Integer> __keySet = __map.keySet();
            Iterator<Integer> __it = __keySet.iterator();
            while (__it.hasNext())
            {
                Integer __key = __it.next();
                __os.write(__key.intValue());
                String __val = __map.get(__key);
                __os.write(__val);
            }
        }

    }

    // enum ELoginType
    public static class ELoginType
    {
        final public static int MobilePhoneNum = 1;
        final public static int TencentQQ = 2;
        final public static int WeChat = 3;

    }

    // enum EGender
    public static class EGender
    {
        final public static int Unknown = 0;
        final public static int Male = 1;
        final public static int Female = 2;

    }

}

