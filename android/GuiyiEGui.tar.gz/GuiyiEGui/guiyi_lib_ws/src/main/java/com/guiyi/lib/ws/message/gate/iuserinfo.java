/*
* @filename iuserinfo.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package com.guiyi.lib.ws.message.gate;


import com.guiyi.lib.ws.message.common.publicdef;
import com.guiyi.lib.ws.rmi.MessageBlock;
import com.guiyi.lib.ws.rmi.ProxyManager;
import com.guiyi.lib.ws.rmi.RmiCore;
import com.guiyi.lib.ws.rmi.Serializer;


public class iuserinfo
{
    // Reponse IUserInfo_changeNickname_response
    public static abstract class IUserInfo_changeNickname_response extends RmiCore.RmiResponseBase
    {
        public IUserInfo_changeNickname_response()
        {
            super();
        }

        @Override
        public void __onResponse(Serializer __is)
        {
            onResponse();
        }

        @Override
        public void __onError(String what, int code)
        {
            onError(what, code);
        }

        @Override
        public void __onTimeout()
        {
            onTimeout();
        }

        public abstract void onResponse();
        public abstract void onError(String what, int code);
        public abstract void onTimeout();
    }

    // Reponse IUserInfo_changeAvatar_response
    public static abstract class IUserInfo_changeAvatar_response extends RmiCore.RmiResponseBase
    {
        public IUserInfo_changeAvatar_response()
        {
            super();
        }

        @Override
        public void __onResponse(Serializer __is)
        {
            onResponse();
        }

        @Override
        public void __onError(String what, int code)
        {
            onError(what, code);
        }

        @Override
        public void __onTimeout()
        {
            onTimeout();
        }

        public abstract void onResponse();
        public abstract void onError(String what, int code);
        public abstract void onTimeout();
    }

    // Reponse IUserInfo_updateFamilyMembers_response
    public static abstract class IUserInfo_updateFamilyMembers_response extends RmiCore.RmiResponseBase
    {
        public IUserInfo_updateFamilyMembers_response()
        {
            super();
        }

        @Override
        public void __onResponse(Serializer __is)
        {
            onResponse();
        }

        @Override
        public void __onError(String what, int code)
        {
            onError(what, code);
        }

        @Override
        public void __onTimeout()
        {
            onTimeout();
        }

        public abstract void onResponse();
        public abstract void onError(String what, int code);
        public abstract void onTimeout();
    }

    // Reponse IUserInfo_removeFamilyMember_response
    public static abstract class IUserInfo_removeFamilyMember_response extends RmiCore.RmiResponseBase
    {
        public IUserInfo_removeFamilyMember_response()
        {
            super();
        }

        @Override
        public void __onResponse(Serializer __is)
        {
            onResponse();
        }

        @Override
        public void __onError(String what, int code)
        {
            onError(what, code);
        }

        @Override
        public void __onTimeout()
        {
            onTimeout();
        }

        public abstract void onResponse();
        public abstract void onError(String what, int code);
        public abstract void onTimeout();
    }

    // Proxy IUserInfoProxy
    public static class IUserInfoProxy extends RmiCore.RmiProxyBase
    {
        public static void __regist(){
            // regist proxy at startup...
            ProxyManager.instance().addProxy(new IUserInfoProxy());
        }

        public IUserInfoProxy()
        {
            super("IUserInfo");
        }

        public void changeNickname(IUserInfo_changeNickname_response __response, String sessionKey, String newNickname)        {
            Serializer __os = new Serializer();
            __os.startToWrite();
            __os.write(Serializer.RmiDataCall);
            __os.write(getName());
            __os.write(new String("changeNickname"));

            int __msgId = MessageBlock.getMsgId();
            __response.setMsgId(__msgId);
            __os.write(__msgId);

            __os.write(sessionKey);
            __os.write(newNickname);

            this.call(__os, __response);
        }

        public void changeAvatar(IUserInfo_changeAvatar_response __response, String sessionKey, byte[] newAvatar)        {
            Serializer __os = new Serializer();
            __os.startToWrite();
            __os.write(Serializer.RmiDataCall);
            __os.write(getName());
            __os.write(new String("changeAvatar"));

            int __msgId = MessageBlock.getMsgId();
            __response.setMsgId(__msgId);
            __os.write(__msgId);

            __os.write(sessionKey);
            __os.write(newAvatar);

            this.call(__os, __response);
        }

        public void updateFamilyMembers(IUserInfo_updateFamilyMembers_response __response, String sessionKey, gatemsg.SeqFamilyMember familyMembers)        {
            Serializer __os = new Serializer();
            __os.startToWrite();
            __os.write(Serializer.RmiDataCall);
            __os.write(getName());
            __os.write(new String("updateFamilyMembers"));

            int __msgId = MessageBlock.getMsgId();
            __response.setMsgId(__msgId);
            __os.write(__msgId);

            __os.write(sessionKey);
            familyMembers.__write(__os);

            this.call(__os, __response);
        }

        public void removeFamilyMember(IUserInfo_removeFamilyMember_response __response, String sessionKey, publicdef.SeqInt indexes)        {
            Serializer __os = new Serializer();
            __os.startToWrite();
            __os.write(Serializer.RmiDataCall);
            __os.write(getName());
            __os.write(new String("removeFamilyMember"));

            int __msgId = MessageBlock.getMsgId();
            __response.setMsgId(__msgId);
            __os.write(__msgId);

            __os.write(sessionKey);
            indexes.__write(__os);

            this.call(__os, __response);
        }

    }

}

