/*
* @filename publicmsg.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package com.guiyi.lib.ws.message.common;


import com.guiyi.lib.ws.rmi.MessageBlock;
import com.guiyi.lib.ws.rmi.Serializer;


public class publicmsg
{
    // class SAddress
    public static class SAddress extends MessageBlock.MessageBase
    {
        public static class AutoRegist extends MessageBlock.AutoRegist
        {
            @Override
            public MessageBlock.MessageBase create()
            {
                return new SAddress();
            }
        }

        public static void __regist(){
            MessageBlock.regist("SAddress", new AutoRegist());
        }

        public String countryCode;
        public String country;
        public String province;
        public String city;
        public String district;
        public String details;
        public double altitude;
        public double longitude;

        public SAddress()
        {
            countryCode = "";
            country = "";
            province = "";
            city = "";
            district = "";
            details = "";
            altitude = 0;
            longitude = 0;
        }

        @Override
        public void __read(Serializer __is)
        {
            countryCode = __is.read(countryCode);
            country = __is.read(country);
            province = __is.read(province);
            city = __is.read(city);
            district = __is.read(district);
            details = __is.read(details);
            altitude = __is.read(altitude);
            longitude = __is.read(longitude);
        }

        @Override
        public void __write(Serializer __os)
        {
            __os.write(countryCode);
            __os.write(country);
            __os.write(province);
            __os.write(city);
            __os.write(district);
            __os.write(details);
            __os.write(altitude);
            __os.write(longitude);
        }
    } // end of class SAddress

}

