/*
* @filename gateconst.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package com.guiyi.lib.ws.message.gate;


public class gateconst
{
}

