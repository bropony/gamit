package com.guiyi.lib.ws.java_websocket.exceptions;

public class WebsocketNotConnectedException extends RuntimeException {

}
