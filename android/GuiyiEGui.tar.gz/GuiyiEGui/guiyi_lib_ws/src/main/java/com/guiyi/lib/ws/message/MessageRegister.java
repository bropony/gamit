package com.guiyi.lib.ws.message;

import com.guiyi.lib.ws.message.common.publicmsg.SAddress;
import com.guiyi.lib.ws.message.gate.gatemsg.SFamilyMember;
import com.guiyi.lib.ws.message.gate.gatemsg.SLogin;
import com.guiyi.lib.ws.message.gate.gatemsg.SLoginReturn;
import com.guiyi.lib.ws.message.gate.gatemsg.SSignup;
import com.guiyi.lib.ws.message.gate.gatemsg.SUserBrief;
import com.guiyi.lib.ws.message.gate.ilogin.ILoginProxy;
import com.guiyi.lib.ws.message.gate.iuserinfo.IUserInfoProxy;

public class MessageRegister {
    public static void regist() {
        SFamilyMember.__regist();
        SAddress.__regist();
        SSignup.__regist();
        IUserInfoProxy.__regist();
        ILoginProxy.__regist();
        SLogin.__regist();
        SLoginReturn.__regist();
        SUserBrief.__regist();
    }
}

