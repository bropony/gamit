/*
* @filename gatemsg.java
*
* @author ahda86@gmail.com
*
* @brief This files is Auto-Generated. Please DON'T modify it EVEN if
*        you know what you are doing.
*/

package com.guiyi.lib.ws.message.gate;


import java.util.Date;

import com.guiyi.lib.ws.message.common.publicdef;
import com.guiyi.lib.ws.rmi.MessageBlock;
import com.guiyi.lib.ws.rmi.Serializer;


public class gatemsg {
    // class SUserBrief
    public static class SUserBrief extends MessageBlock.MessageBase {
        public static class AutoRegist extends MessageBlock.AutoRegist {
            @Override
            public MessageBlock.MessageBase create() {
                return new SUserBrief();
            }
        }

        public static void __regist() {
            MessageBlock.regist("SUserBrief", new AutoRegist());
        }

        public String userId;
        public String nickname;

        public SUserBrief() {
            userId = "";
            nickname = "";
        }

        @Override
        public void __read(Serializer __is) {
            userId = __is.read(userId);
            nickname = __is.read(nickname);
        }

        @Override
        public void __write(Serializer __os) {
            __os.write(userId);
            __os.write(nickname);
        }
    } // end of class SUserBrief

    // class SLogin
    public static class SLogin extends MessageBlock.MessageBase {
        public static class AutoRegist extends MessageBlock.AutoRegist {
            @Override
            public MessageBlock.MessageBase create() {
                return new SLogin();
            }
        }

        public static void __regist() {
            MessageBlock.regist("SLogin", new AutoRegist());
        }

        public String deviceCode;
        public int loginType;
        public String account;
        public String password;

        public SLogin() {
            deviceCode = "";
            loginType = publicdef.ELoginType.MobilePhoneNum;
            account = "";
            password = "";
        }

        @Override
        public void __read(Serializer __is) {
            deviceCode = __is.read(deviceCode);
            loginType = __is.readInt();
            account = __is.read(account);
            password = __is.read(password);
        }

        @Override
        public void __write(Serializer __os) {
            __os.write(deviceCode);
            __os.write(loginType);
            __os.write(account);
            __os.write(password);
        }
    } // end of class SLogin

    // class SSignup
    public static class SSignup extends MessageBlock.MessageBase {
        public static class AutoRegist extends MessageBlock.AutoRegist {
            @Override
            public MessageBlock.MessageBase create() {
                return new SSignup();
            }
        }

        public static void __regist() {
            MessageBlock.regist("SSignup", new AutoRegist());
        }

        public String deviceCode;
        public int loginType;
        public String account;
        public String password;
        public String nickname;
        public String validationCode;
        public String invitationCode;

        public SSignup() {
            deviceCode = "";
            loginType = publicdef.ELoginType.MobilePhoneNum;
            account = "";
            password = "";
            nickname = "";
            validationCode = "";
            invitationCode = "";
        }

        @Override
        public void __read(Serializer __is) {
            deviceCode = __is.read(deviceCode);
            loginType = __is.readInt();
            account = __is.read(account);
            password = __is.read(password);
            nickname = __is.read(nickname);
            validationCode = __is.read(validationCode);
            invitationCode = __is.read(invitationCode);
        }

        @Override
        public void __write(Serializer __os) {
            __os.write(deviceCode);
            __os.write(loginType);
            __os.write(account);
            __os.write(password);
            __os.write(nickname);
            __os.write(validationCode);
            __os.write(invitationCode);
        }
    } // end of class SSignup

    // class SLoginReturn
    public static class SLoginReturn extends MessageBlock.MessageBase {
        public static class AutoRegist extends MessageBlock.AutoRegist {
            @Override
            public MessageBlock.MessageBase create() {
                return new SLoginReturn();
            }
        }

        public static void __regist() {
            MessageBlock.regist("SLoginReturn", new AutoRegist());
        }

        public String sessionKey;
        public String userId;
        public String nickname;
        public byte[] avatar;

        public SLoginReturn() {
            sessionKey = "";
            userId = "";
            nickname = "";
            avatar = new byte[0];
        }

        @Override
        public void __read(Serializer __is) {
            sessionKey = __is.read(sessionKey);
            userId = __is.read(userId);
            nickname = __is.read(nickname);
            avatar = __is.read(avatar);
        }

        @Override
        public void __write(Serializer __os) {
            __os.write(sessionKey);
            __os.write(userId);
            __os.write(nickname);
            __os.write(avatar);
        }
    } // end of class SLoginReturn

    // class SFamilyMember
    public static class SFamilyMember extends MessageBlock.MessageBase {
        public static class AutoRegist extends MessageBlock.AutoRegist {
            @Override
            public MessageBlock.MessageBase create() {
                return new SFamilyMember();
            }
        }

        public static void __regist() {
            MessageBlock.regist("SFamilyMember", new AutoRegist());
        }

        public int index;
        public String member;
        public String name;
        public int gender;
        public Date birthday;
        public float height;
        public float weight;
        public float bust;
        public float waistline;
        public float hipline;
        public float brachium;
        public float leglength;
        public float shoulder;

        public SFamilyMember() {
            index = 0;
            member = "";
            name = "";
            gender = 0;
            birthday = new Date();
            height = 0;
            weight = 0;
            bust = 0;
            waistline = 0;
            hipline = 0;
            brachium = 0;
            leglength = 0;
            shoulder = 0;
        }

        @Override
        public void __read(Serializer __is) {
            index = __is.read(index);
            member = __is.read(member);
            name = __is.read(name);
            gender = __is.read(gender);
            birthday = __is.read(birthday);
            height = __is.read(height);
            weight = __is.read(weight);
            bust = __is.read(bust);
            waistline = __is.read(waistline);
            hipline = __is.read(hipline);
            brachium = __is.read(brachium);
            leglength = __is.read(leglength);
            shoulder = __is.read(shoulder);
        }

        @Override
        public void __write(Serializer __os) {
            __os.write(index);
            __os.write(member);
            __os.write(name);
            __os.write(gender);
            __os.write(birthday);
            __os.write(height);
            __os.write(weight);
            __os.write(bust);
            __os.write(waistline);
            __os.write(hipline);
            __os.write(brachium);
            __os.write(leglength);
            __os.write(shoulder);
        }
    } // end of class SFamilyMember

    // List SeqFamilyMember
    public static class SeqFamilyMember {
        private SFamilyMember[] __array;

        public SeqFamilyMember() {
            __array = null;
        }

        public SFamilyMember[] getArray() {
            return __array;
        }

        public void __read(Serializer __is) {
            int __dataSize = __is.readInt();
            __array = new SFamilyMember[__dataSize];
            for (int i = 0; i < __dataSize; ++i) {
                SFamilyMember __val = new SFamilyMember();
                __val.__read(__is);
                __array[i] = __val;
            }
        }

        public void __write(Serializer __os) {
            int __dataSize = (__array != null) ? __array.length : 0;
            __os.write(__dataSize);
            for (int i = 0; i < __dataSize; ++i) {
                __array[i].__write(__os);
            }
        }

    }

}

