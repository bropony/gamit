package com.guiyi.lib.ws.rmi;

public abstract class MessageHandler {
	public abstract void onMessage(MessageBlock msgBlock);
}
