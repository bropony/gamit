package com.jenwis.android.base.base.util;

import android.content.Context;
import android.telephony.TelephonyManager;

/**
 * Created by zhengyuji on 15/8/4.
 */
public class DeviceUtil {
    public static String getDeviceId(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

        return tm.getDeviceId();
    }
}
